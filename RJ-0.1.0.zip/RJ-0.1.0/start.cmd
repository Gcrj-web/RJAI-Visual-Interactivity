@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set HF_HOME=%~dp0data\hf-cache
if not defined HF_ENDPOINT set HF_ENDPOINT=https://hf-mirror.com
if not defined RJ_ASR_LANGUAGE set RJ_ASR_LANGUAGE=auto
python -c "import requests" >nul 2>nul
if errorlevel 1 (
  echo Installing dependencies...
  python -m pip install -r requirements.txt
)
echo Starting RJ local server...
python -m rj.cli serve --port 8765
pause
