from __future__ import annotations

import os
import shutil
import unittest
from pathlib import Path
from unittest.mock import patch

from rj.analyze import analyze_video, attach_visual_analysis, flag_unverified_repos
from rj.asr import (
    ASRConfig,
    ASRDependencyError,
    ASRError,
    _normalize_segments,
    _strip_prompt_echo,
    _transcribe_with_fallback,
    transcribe_bilibili,
    transcribe_file,
)
from rj.asr_norm import normalize_text
from rj.bilibili import (
    BilibiliClient,
    evidence_from_payload,
    hydrate_evidence,
    parse_bvid,
    pick_audio_url,
    pick_audio_urls,
)
from rj.brief import (
    build_fallback_brief,
    build_game_brief,
    build_game_review_agent_prompt,
    build_game_review_brief,
    build_science_agent_prompt,
    build_science_brief,
    build_llm_messages,
    build_media_brief,
    build_nonsoftware_brief,
    build_software_questions,
    build_usage_brief,
)
from rj.classify import classify_video
from rj.codehost import parse_dependencies
from rj.douyin import hydrate_evidence as hydrate_douyin
from rj.douyin import media_host_allowed
from rj.extract import build_queries, clean_title, extract_signals, find_repo_mentions
from rj.frames import ExtractedFrame, extract_frames
from rj.llm import LLMError
from rj.models import (
    AnalysisResult,
    Chapter,
    Comment,
    ExtractedSignals,
    RepoCandidate,
    SubtitleSegment,
    VideoEvidence,
)
from rj.qa import answer_question, retrieve_sources
from rj.score import score_candidates
from rj.store import ProjectStore
from rj.vision import (
    VisionConfig,
    merge_vision_results,
    normalize_vision_result,
    parse_vision_json,
)


def make_video(**overrides) -> VideoEvidence:
    base = dict(
        platform="bilibili",
        video_id="BV1TEST000001",
        url="https://www.bilibili.com/video/BV1TEST000001/",
        title="我用 Python 做了个本地 AI 语音助手",
        description="开源地址：https://github.com/foo/bar",
        author="测试作者",
        tags=["Python", "AI", "语音助手"],
        duration=300,
    )
    base.update(overrides)
    return VideoEvidence(**base)


def legado_video() -> VideoEvidence:
    return make_video(
        video_id="BV1iWiWBDEbS",
        url="https://www.bilibili.com/video/BV1iWiWBDEbS/",
        title="【开源阅读0基础小白向教程】【第1期】软件的下载与书源导入",
        description="下载地址（长按可以复制）∶\nhttps://pan.quark.cn/s/f30765ba3ad7",
        author="piaomiao之旅",
        tags=["开源阅读", "教程", "书源"],
        duration=180,
        aid=1,
        cid=2,
        subtitles=[
            SubtitleSegment(0, 3, "如你所见,这期是开源阅读的零基础教程"),
            SubtitleSegment(3, 7, "主要面向刚开始接触阅读这款软件的小白"),
            SubtitleSegment(11, 14, "现在是下载教程"),
            SubtitleSegment(15, 18, "第一种方法"),
            SubtitleSegment(29, 32, "即用github下载"),
            SubtitleSegment(41, 44, "OK等了许久也是进去了"),
            SubtitleSegment(52, 55, "那么也是开始下载了"),
            SubtitleSegment(64, 68, "随便附近一个地址后就是json"),
            SubtitleSegment(76, 79, "点击网络导入"),
            SubtitleSegment(87, 90, "搜索自己想看的书就行"),
            SubtitleSegment(101, 104, "点击使用说明"),
            SubtitleSegment(111, 114, "进来之后"),
        ],
        comments=[
            Comment(
                "囡垰",
                "下载地址\n【盘】https://pan.quark.cn/s/5b99184d5efa\n"
                "【github】https://github.com/gedoor/legado",
                123,
            ),
            Comment("观众", "网络导入失败了怎么办", 5),
        ],
    )


def embedded_video() -> VideoEvidence:
    return make_video(
        video_id="BV1EMBEDDED1",
        url="https://www.bilibili.com/video/BV1EMBEDDED1/",
        title="ESP32 桌面机器人：接线、烧录固件和调试",
        description=(
            "开源地址：https://github.com/demo/esp32-robot\n"
            "使用 ESP32-S3、SG90 舵机、锂电池供电"
        ),
        tags=["ESP32", "机器人", "固件", "硬件"],
        duration=600,
        aid=1,
        cid=2,
        subtitles=[
            SubtitleSegment(0, 5, "先确认 esp32 开发板和舵机的接线"),
            SubtitleSegment(5, 10, "舵机单独用锂电池供电"),
            SubtitleSegment(10, 15, "打开 PlatformIO 烧录固件"),
            SubtitleSegment(15, 20, "第一次上电先空载测试"),
            SubtitleSegment(20, 25, "串口输出正常后再装结构件"),
        ],
        comments=[
            Comment("观众A", "舵机和开发板要共地", 8),
            Comment("观众B", "烧录时别接电机电源", 3),
        ],
    )


def anime_video() -> VideoEvidence:
    return make_video(
        title="“全都是借口”",
        description="视频素材来自MHRAP和少年jump周刊，已取得原作者同意",
        tags=["动漫", "剪辑", "MAD"],
        duration=102,
        subtitles=[],
        comments=[
            Comment("闪光无限回旋三式之主", "宁次终于活下来了😭😭", 235),
            Comment("74是五彩碎片", "先把绮罗罗的术式说出来再论战", 2),
            Comment("大木二世", "听心似烟火感觉整个人都通透了", 266),
        ],
    )


def game_video() -> VideoEvidence:
    return make_video(
        video_id="BV1GAME00001",
        url="https://www.bilibili.com/video/BV1GAME00001/",
        title="【棕色尘埃2】半周年之前必备抽数, 阿奇拉要技能前瞻",
        description="老M的小窝，欢迎讨论游戏最新资讯",
        tags=["手机游戏", "棕色尘埃2", "阿奇拉", "教程攻略", "商店"],
        duration=338,
        chapters=[
            Chapter("引言", 0),
            Chapter("阿奇拉技能&点评", 52),
            Chapter("半周年&抽卡规划&总结", 296),
        ],
        subtitles=[
            SubtitleSegment(0, 3, "哈喽大家好，我是老M", "asr"),
            SubtitleSegment(6, 9, "阿奇拉这个肯定是必抽的", "asr"),
            SubtitleSegment(58, 62, "技能消耗95的生命", "asr"),
            SubtitleSegment(64, 68, "换来100%的属性伤害增加", "asr"),
            SubtitleSegment(136, 140, "这是属性伤害增益", "asr"),
            SubtitleSegment(298, 302, "保底抽数是200到300发", "asr"),
            SubtitleSegment(305, 309, "预留600抽左右就可以拿下", "asr"),
        ],
        comments=[
            Comment("测试作者", "有缘之客肯定得抽啊\n群号：123456", 99),
            Comment("观众A", "阿奇拉必抽吗", 30),
            Comment("观众B", "我只有300抽，够不够", 20),
            Comment("观众C", "先开图鉴再说", 10),
            Comment("观众D", "半周年快到了", 5),
        ],
    )


def review_video() -> VideoEvidence:
    return make_video(
        video_id="BV1REVIEW001",
        url="https://www.bilibili.com/video/BV1REVIEW001/",
        title="【HLTV】从夯到拉排行棕色尘埃2有缘之客",
        description="纯主观",
        tags=["二游", "棕色尘埃2", "有缘之客", "鉴赏"],
        duration=652,
        chapters=[
            Chapter("引言", 0),
            Chapter("本期三个角色", 52),
            Chapter("墨菲亚", 117),
            Chapter("内布里斯", 310),
            Chapter("泰瑞斯", 426),
            Chapter("结尾（剪辑失误忘记把背景音调小了", 595),
        ],
        subtitles=[
            SubtitleSegment(3, 6, "历经两个月两个星期啊", "cc"),
            SubtitleSegment(16, 20, "这个从航到达排名有缘之客的视频啊", "cc"),
            SubtitleSegment(102, 105, "就是一共就录3分钟", "cc"),
            SubtitleSegment(124, 128, "本期视频全程由我主观来评价", "cc"),
            SubtitleSegment(182, 186, "这个傲和娇的平衡得就得平衡点", "cc"),
            SubtitleSegment(294, 298, "只能说没有现在那么开放啊", "cc"),
            SubtitleSegment(297, 300, "可玩点也不多", "cc"),
            SubtitleSegment(299, 302, "但是我觉得做的已经很不错了啊", "cc"),
            SubtitleSegment(301, 305, "所以呢我决定给他排到一个不上不下", "cc"),
            SubtitleSegment(307, 310, "排到中间的一个位置啊", "cc"),
            SubtitleSegment(308, 311, "人上人好", "cc"),
            SubtitleSegment(315, 319, "只能说这个皮肤真的一般啊", "cc"),
            SubtitleSegment(359, 363, "没有完全发挥好", "cc"),
            SubtitleSegment(406, 410, "真的做的有点垃圾了", "cc"),
            SubtitleSegment(418, 422, "就连mod都救不了", "cc"),
            SubtitleSegment(419, 423, "所以呢我只能给到一个拉完", "cc"),
            SubtitleSegment(473, 477, "泰瑞斯这张脸我就不是很敢", "cc"),
            SubtitleSegment(477, 481, "所以我对他的评价就会比较低", "cc"),
            SubtitleSegment(546, 550, "堆堆袜我喜欢 我挺喜欢", "cc"),
            SubtitleSegment(558, 562, "背德感没有体现出来", "cc"),
            SubtitleSegment(582, 586, "我只能给他这个拍到这个人上人和拉完了的中间NPC", "cc"),
            SubtitleSegment(595, 599, "不知道你们对的是把这三个皮肤在评原", "cc"),
            SubtitleSegment(629, 633, "求个关注", "cc"),
        ],
        comments=[
            Comment("观众A", "黑天帝这个属实是吃了太早的亏", 20),
            Comment("观众B", "左上角的圆环能量条怎么满啊", 10),
            Comment("观众C", "纯主观排名，别当真", 5),
            Comment("观众D", "低赞评论", 1),
        ],
    )


def science_video() -> VideoEvidence:
    return make_video(
        video_id="BV1SCIENCE01",
        url="https://www.bilibili.com/video/BV1SCIENCE01/",
        title="满屏医学生减肥？到底什么方法才最适合我们普通人？",
        description="大家一定擦亮眼睛，去药店或者医院认准OTC才是正经方法",
        tags=["减脂", "瘦身", "生活", "日常", "穿搭", "健身", "减肥", "身材", "记录", "减重"],
        duration=250,
        subtitles=[
            SubtitleSegment(0, 3, "现在做个减肥全他妈蹦出来的是医学生", "cc"),
            SubtitleSegment(21, 25, "我是正儿八经的医学院的学生", "cc"),
            SubtitleSegment(35, 39, "我是那种平时完全没有精力去运动或者节食", "cc"),
            SubtitleSegment(43, 47, "原话是国内唯一批准上市的口服减肥产品", "cc"),
            SubtitleSegment(46, 49, "就只有奥利斯塔", "cc"),
            SubtitleSegment(58, 62, "医院或者药店都有", "cc"),
            SubtitleSegment(65, 69, "他合葬是有这个OTC药品的标识", "cc"),
            SubtitleSegment(116, 120, "然后我现在体重啊是181斤", "cc"),
            SubtitleSegment(146, 150, "这次可是实打实瘦了四斤多", "cc"),
            SubtitleSegment(146, 150, "期间保持跟之前一样的饮食和生活规律", "cc"),
            SubtitleSegment(151, 155, "会拉肚子或者漏油之类的", "cc"),
            SubtitleSegment(232, 236, "发现我去这次整整掉了十来斤", "cc"),
            SubtitleSegment(251, 255, "原来这奥利斯它就是一种专业的脂肪阻断剂", "cc"),
            SubtitleSegment(325, 329, "我也把我当时回购的那个网上药店的链接", "cc"),
            SubtitleSegment(327, 331, "放在评论区了", "cc"),
            SubtitleSegment(331, 335, "还可以领一个专项的优惠", "cc"),
            SubtitleSegment(341, 345, "千万不要病急乱投医", "cc"),
            SubtitleSegment(346, 350, "去医院里买正规的药品产品", "cc"),
        ],
        comments=[
            Comment("观众A", "站内全是医学生在推保健品", 100),
            Comment("观众B", "OTC奥利司他才卖30一盒", 80),
            Comment("观众C", "先亮学生卡和毕业证", 60),
            Comment("观众D", "低赞评论", 1),
        ],
    )


class ExtractTests(unittest.TestCase):
    def test_find_repo_mentions(self):
        text = (
            "源码 https://github.com/foo/bar/tree/main?tab=readme "
            "备用 gitee.com/foo/bar 以及 github.com/foo/baz.git"
        )
        mentions = find_repo_mentions(text, "description")
        self.assertEqual(
            [(m.host, m.full_name) for m in mentions],
            [("github", "foo/bar"), ("gitee", "foo/bar"), ("github", "foo/baz")],
        )
        self.assertEqual(mentions[0].host, "github")
        self.assertEqual(mentions[1].host, "gitee")

    def test_subtitle_mention_keeps_timestamp(self):
        video = make_video(
            description="",
            subtitles=[SubtitleSegment(start=12, end=15, text="仓库是 github.com/foo/bar")],
        )
        signals = extract_signals(video)
        self.assertEqual(len(signals.repo_mentions), 1)
        self.assertEqual(signals.repo_mentions[0].start, 12)
        self.assertEqual(signals.repo_mentions[0].source, "subtitle")

    def test_explicit_repo_becomes_query(self):
        video = make_video()
        signals = extract_signals(video)
        self.assertEqual(signals.queries[0], "foo/bar")

    def test_title_query_is_cleaned(self):
        video = make_video(description="")
        queries = build_queries(video, [])
        self.assertIn("Python", queries[0])
        self.assertNotIn("我用", queries[0])
        self.assertNotIn("做了", queries[0])

    def test_clean_title_handles_emoji_and_brackets(self):
        value = clean_title("【开源】我用 Python 做了个机器人 🤖")
        self.assertIn("Python", value)
        self.assertNotIn("【", value)


class ScoreTests(unittest.TestCase):
    def test_explicit_repo_ranks_first(self):
        video = make_video()
        signals = extract_signals(video)
        candidates = [
            RepoCandidate(
                host="github",
                full_name="other/assistant",
                html_url="https://github.com/other/assistant",
                description="voice assistant",
                stars=9000,
                language="Python",
                license="MIT",
            ),
            RepoCandidate(
                host="github",
                full_name="foo/bar",
                html_url="https://github.com/foo/bar",
                description="local voice assistant",
                stars=10,
                language="Python",
                license="MIT",
            ),
        ]
        scored = score_candidates(candidates, signals, video)
        self.assertEqual(scored[0].full_name, "foo/bar")
        self.assertEqual(scored[0].score, 100.0)

    def test_generic_awesome_list_is_penalized(self):
        video = make_video(description="")
        signals = extract_signals(video)
        candidates = [
            RepoCandidate(
                host="github",
                full_name="someone/awesome-llm-apps",
                html_url="https://github.com/someone/awesome-llm-apps",
                description="A list of LLM apps and voice assistants",
                stars=50000,
                language="Python",
                license="Apache-2.0",
            )
        ]
        scored = score_candidates(candidates, signals, video)
        self.assertLess(scored[0].score, 60)


class ClassifyTests(unittest.TestCase):
    def test_anime_video_is_media_content(self):
        video = anime_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "media_content")

    def test_media_brief_states_visual_limitation(self):
        video = anime_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_media_brief(video, signals, classification)
        self.assertIn("动漫/影视内容简报", brief)
        self.assertIn("没有接入视觉模型", brief)
        self.assertIn("画面人物", brief)
        self.assertIn("宁次", brief)
        self.assertNotIn("克隆", brief)

    def test_embedded_video_is_mixed(self):
        video = embedded_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "hardware_software_mixed")

    def test_mixed_brief_has_hardware_and_software_questions(self):
        video = embedded_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_nonsoftware_brief(video, signals, classification)
        self.assertIn("硬件 + 软件混合简报", brief)
        self.assertIn("软件 / 固件线索", brief)
        self.assertIn("ESP32", brief)
        self.assertIn("开发板", brief)
        self.assertIn("烧录", brief)
        self.assertNotIn("安卓还是 iOS", brief)
        self.assertNotIn("Python/Node", brief)

    def test_mixed_video_keeps_explicit_repo_link(self):
        result = analyze_video(embedded_video(), offline=True)
        self.assertEqual(result.kind, "hardware_software_mixed")
        self.assertIsNotNone(result.selected)
        self.assertEqual(
            result.selected.html_url, "https://github.com/demo/esp32-robot"
        )
        self.assertEqual(result.selected.source, "explicit")

    def test_laptop_questions_do_not_use_mobile_software_template(self):
        video = make_video(
            title="联想拯救者R9000P清灰换相变片",
            description="",
            tags=["笔记本"],
            subtitles=[],
        )
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_nonsoftware_brief(video, signals, classification)
        self.assertEqual(classification.kind, "hardware_tutorial")
        self.assertNotIn("安卓还是 iOS", brief)
        self.assertNotIn("Python/Node", brief)
        self.assertIn("具体型号", brief)

    def test_laptop_price_commentary_is_not_software_project(self):
        video = make_video(
            title="吓哭了！最近一年笔记本电脑涨了多少？！",
            description="涨疯了，都涨疯了",
            tags=["科技猎手", "笔记本电脑", "涨价"],
            comments=[Comment("观众", "这个脚本写得不错", 3)],
            subtitles=[],
        )
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertNotEqual(classification.kind, "software_project")
        self.assertEqual(classification.kind, "hardware_topic")

    def test_hardware_topic_brief_does_not_become_repair_manual(self):
        video = make_video(
            title="吓哭了！最近一年笔记本电脑涨了多少？！",
            description="涨疯了，都涨疯了",
            tags=["科技猎手", "笔记本电脑", "涨价"],
            subtitles=[
                SubtitleSegment(0, 5, "现在一台主流游戏本要一万元", "asr"),
                SubtitleSegment(5, 10, "去年同配置只要六千多", "asr"),
            ],
        )
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_nonsoftware_brief(video, signals, classification)
        self.assertIn("硬件资讯/评测简报", brief)
        self.assertNotIn("硬件维修简报", brief)
        self.assertNotIn("拆机前断电", brief)
        self.assertNotIn("克隆", brief)

    def test_hardware_video_is_routed_to_hardware(self):
        video = make_video(
            title="联想拯救者R9000P Y9000P，25、26款，清灰换相变片，超详细教程",
            description="",
            tags=["笔记本", "清灰"],
            subtitles=[],
        )
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "hardware_tutorial")
        self.assertGreater(classification.hardware_score, classification.software_score)

    def test_software_video_is_routed_to_software(self):
        video = make_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "software_project")

    def test_hardware_brief_does_not_talk_about_cloning(self):
        video = make_video(
            title="联想拯救者R9000P清灰换相变片",
            description="",
            tags=["笔记本"],
            subtitles=[],
        )
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_nonsoftware_brief(video, signals, classification)
        self.assertIn("硬件维修简报", brief)
        self.assertIn("未检索代码仓库", brief)
        self.assertNotIn("克隆", brief)

    def test_hardware_brief_marks_asr_timeline(self):
        video = make_video(
            title="联想拯救者R9000P清灰换相变片",
            description="",
            tags=["笔记本"],
            subtitles=[SubtitleSegment(1, 3, "第一步，先拆后盖", "asr")],
        )
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_nonsoftware_brief(video, signals, classification)
        self.assertIn("本地 ASR", brief)
        self.assertIn("ASR 字幕", brief)

    def test_game_video_is_routed_to_game_guide(self):
        video = game_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "game_guide")
        self.assertGreater(classification.game_score, classification.media_score)

    def test_game_brief_prioritizes_creator_and_limits_comments(self):
        video = game_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_game_brief(video, signals, classification)
        self.assertIn("游戏攻略简报", brief)
        self.assertIn("博主观点", brief)
        self.assertIn("保底抽数", brief)
        self.assertNotIn("你希望我分析什么", brief)
        self.assertNotIn("UP自评", brief)
        self.assertNotIn("群号：123456", brief)
        audience = brief.split("## 4. 观众反馈", 1)[1].split("## 5.", 1)[0]
        self.assertIn("观众A", audience)
        self.assertIn("观众C", audience)
        self.assertNotIn("观众D", audience)

    def test_review_video_is_routed_to_game_review(self):
        video = review_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "game_review")
        self.assertGreater(classification.review_score, 0)

    def test_game_review_brief_extracts_tiers_and_reasons(self):
        video = review_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_game_review_brief(video, signals, classification)
        self.assertIn("游戏测评/排行简报", brief)
        self.assertIn("排行 / 档位结论", brief)
        self.assertIn("墨菲亚", brief)
        self.assertIn("内布里斯", brief)
        self.assertIn("泰瑞斯", brief)
        self.assertIn("人上人", brief)
        self.assertIn("拉完", brief)
        self.assertIn("中间NPC", brief)
        self.assertIn("偏负面", brief)
        body = brief.split("## 2.", 1)[1].split("## 5.", 1)[0]
        self.assertNotIn("录3分钟", body)
        self.assertNotIn("求个关注", body)
        self.assertNotIn("胸", brief)
        self.assertNotIn("屁股", brief)
        self.assertIn("没有给出明确的抽卡", brief)

    def test_game_review_agent_prompt_is_review_specific(self):
        video = review_video()
        prompt = build_game_review_agent_prompt("# 简报", video)
        self.assertIn("游戏测评/排行内容整理助手", prompt)
        self.assertIn("博主观点", prompt)
        self.assertIn("不输出露骨互动细节", prompt)

    def test_science_video_is_not_software_project(self):
        video = science_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "science_content")
        self.assertGreater(classification.science_score, 0)

    def test_science_brief_layers_claims_and_safety(self):
        video = science_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_science_brief(video, signals, classification)
        self.assertIn("科普/健康简报", brief)
        self.assertIn("博主的主要主张", brief)
        self.assertIn("待核实", brief)
        self.assertIn("个人体验", brief)
        self.assertIn("商业推广提示", brief)
        self.assertIn("奥利司他", brief)
        self.assertIn("不是医疗建议", brief)
        self.assertIn("评论区", brief)
        self.assertNotIn("## 5. 复刻路径", brief)
        self.assertNotIn("克隆", brief)
        self.assertNotIn("工具链", brief)
        self.assertNotIn("观众D", brief)

    def test_science_agent_prompt_is_medical_safe(self):
        video = science_video()
        prompt = build_science_agent_prompt("# 简报", video)
        self.assertIn("科普/健康内容整理助手", prompt)
        self.assertIn("不是医疗建议", prompt)
        self.assertIn("商业推广", prompt)
        self.assertIn("[待核实]", prompt)


class UsageTests(unittest.TestCase):
    def test_usage_video_is_classified(self):
        video = legado_video()
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        self.assertEqual(classification.kind, "software_usage")
        self.assertGreater(classification.usage_score, classification.development_score)

    def test_usage_brief_contains_blogger_steps_and_mobile_questions(self):
        video = legado_video()
        signals = extract_signals(video)
        selected = RepoCandidate(
            host="github",
            full_name="gedoor/legado",
            html_url="https://github.com/gedoor/legado",
            language="Kotlin",
            stars=47122,
            license="",
            source="explicit",
        )
        brief = build_usage_brief(video, signals, selected)
        self.assertIn("软件使用简报", brief)
        self.assertIn("博主的步骤", brief)
        self.assertIn("00:15", brief)
        self.assertIn("pan.quark.cn", brief)
        self.assertIn("gedoor/legado", brief)
        self.assertIn("网络导入失败", brief)
        self.assertIn("安卓还是 iOS", brief)
        self.assertNotIn("克隆", brief)
        self.assertNotIn("Python/Node", brief)

    def test_android_project_questions_use_android_toolchain(self):
        selected = RepoCandidate(
            host="github",
            full_name="gedoor/legado",
            html_url="https://github.com/gedoor/legado",
            language="Kotlin",
        )
        questions = " ".join(build_software_questions(legado_video(), selected))
        self.assertIn("Android Studio", questions)
        self.assertNotIn("GPU", questions)
        self.assertNotIn("Node", questions)


class UsageAnalyzeTests(unittest.TestCase):
    class FakeGitHub:
        def get_repo(self, full_name):
            return RepoCandidate(
                host="github",
                full_name=full_name,
                html_url=f"https://github.com/{full_name}",
                language="Kotlin",
                stars=47122,
                license="",
            )

        def search(self, *args, **kwargs):
            raise AssertionError("software usage must not search GitHub")

    class FakeGitee:
        def search(self, *args, **kwargs):
            raise AssertionError("software usage must not search Gitee")

    def test_usage_analysis_skips_repo_search(self):
        result = analyze_video(
            legado_video(),
            github=self.FakeGitHub(),
            gitee=self.FakeGitee(),
        )
        self.assertEqual(result.kind, "software_usage")
        self.assertIsNotNone(result.selected)
        self.assertEqual(result.selected.full_name, "gedoor/legado")
        self.assertIn("软件使用简报", result.brief_md)
        self.assertNotIn("克隆", result.brief_md)


class ASRTests(unittest.TestCase):
    def test_get_audio_url_reads_dash(self):
        client = BilibiliClient()
        response = {
            "code": 0,
            "data": {
                "dash": {
                    "audio": [
                        {"bandwidth": 64000, "baseUrl": "https://cdn/a.m4s"}
                    ]
                }
            },
        }
        with patch.object(client, "_sign", side_effect=lambda params: params), patch.object(
            client, "_get", return_value=response
        ):
            url = client.get_audio_url(1, 2, "BV1TEST")
        self.assertEqual(url, "https://cdn/a.m4s")

    def test_pick_audio_url_prefers_highest_bandwidth(self):
        data = {
            "dash": {
                "audio": [
                    {"bandwidth": 64000, "baseUrl": "https://cdn/64.m4s"},
                    {"bandwidth": 128000, "baseUrl": "https://cdn/128.m4s"},
                ]
            }
        }
        self.assertEqual(pick_audio_url(data), "https://cdn/128.m4s")

    def test_pick_audio_url_ignores_durl_video_fallback(self):
        data = {
            "dash": {
                "audio": [
                    {"bandwidth": 64000, "backupUrl": ["//cdn/backup.m4s"]}
                ]
            }
        }
        self.assertEqual(pick_audio_url(data), "https://cdn/backup.m4s")
        self.assertEqual(
            pick_audio_url({"durl": [{"url": "http://cdn/video.flv"}]}),
            "",
        )

    def test_pick_audio_urls_prefers_main_cdn(self):
        data = {
            "dash": {
                "audio": [
                    {
                        "bandwidth": 170000,
                        "baseUrl": "https://edge.mountaintoys.cn:4483/a.m4s",
                    },
                    {
                        "bandwidth": 65000,
                        "baseUrl": "https://cn.bilivideo.com/a.m4s",
                    },
                ]
            }
        }
        urls = pick_audio_urls(data)
        self.assertIn("bilivideo.com", urls[0])
        self.assertEqual(len(urls), 2)

    def test_client_bypasses_env_proxy_by_default(self):
        with patch.dict(
            os.environ,
            {"HTTPS_PROXY": "http://127.0.0.1:9"},
            clear=False,
        ):
            client = BilibiliClient()
            self.assertFalse(client.session.trust_env)
        with patch.dict(
            os.environ,
            {"RJ_USE_SYSTEM_PROXY": "1"},
            clear=False,
        ):
            client = BilibiliClient()
            self.assertTrue(client.session.trust_env)

    def test_asr_config_from_env(self):
        with patch.dict(
            os.environ,
            {
                "RJ_ASR_MODEL": "base",
                "RJ_ASR_DEVICE": "cuda",
                "RJ_ASR_ENABLED": "0",
            },
            clear=False,
        ):
            config = ASRConfig.from_env()
        self.assertEqual(config.model, "base")
        self.assertEqual(config.device, "cuda")
        self.assertFalse(config.enabled)

    def test_transcribe_file_maps_segments(self):
        class FakeSegment:
            start = 1.0
            end = 2.5
            text = " hello "

        class FakeModel:
            def transcribe(self, *args, **kwargs):
                return iter([FakeSegment()]), None

        with patch("rj.asr._get_model", return_value=FakeModel()):
            segments = transcribe_file(Path("dummy.bin"), ASRConfig())
        self.assertEqual(len(segments), 1)
        self.assertEqual(segments[0].text, "hello")
        self.assertEqual(segments[0].source, "asr")

    def test_empty_chinese_retries_with_auto_language(self):
        calls = []

        def fake(path, config, progress=None, hints=None):
            calls.append(config.language)
            if len(calls) == 1:
                raise ASRError("empty")
            return [SubtitleSegment(0, 1, "テスト", "asr")]

        with patch("rj.asr.transcribe_file", side_effect=fake):
            segments = _transcribe_with_fallback(
                Path("dummy.bin"), ASRConfig(language="zh")
            )
        self.assertEqual(calls, ["zh", "auto"])
        self.assertEqual(segments[0].text, "テスト")

    def test_transcribe_bilibili_requires_dependency(self):
        with patch("rj.asr.asr_available", return_value=False), patch(
            "rj.asr._load_cache", return_value=[]
        ):
            with self.assertRaises(ASRDependencyError):
                transcribe_bilibili("BV1TEST", 1, 2, config=ASRConfig())

    def test_hydrate_uses_asr_when_no_subtitles(self):
        class FakeClient:
            def __init__(self, cookie=""):
                pass

            def get_subtitles(self, *args):
                return []

            def get_chapters(self, *args):
                return []

            def get_comments(self, *args):
                return []

        video = make_video(subtitles=[], aid=1, cid=2)
        with patch("rj.bilibili.BilibiliClient", FakeClient), patch(
            "rj.asr.asr_available", return_value=True
        ), patch(
            "rj.asr.transcribe_bilibili",
            return_value=[SubtitleSegment(1, 2, "ASR", "asr")],
        ):
            result = hydrate_evidence(video, {})
        self.assertEqual(result.subtitles[0].text, "ASR")
        self.assertEqual(result.subtitles[0].source, "asr")

    def test_hydrate_reports_missing_asr(self):
        class FakeClient:
            def __init__(self, cookie=""):
                pass

            def get_subtitles(self, *args):
                return []

            def get_chapters(self, *args):
                return []

            def get_comments(self, *args):
                return []

        video = make_video(subtitles=[], aid=1, cid=2)
        with patch("rj.bilibili.BilibiliClient", FakeClient), patch(
            "rj.asr.asr_available", return_value=False
        ):
            result = hydrate_evidence(video, {})
        self.assertTrue(
            any("faster-whisper" in warning for warning in result.warnings)
        )


class ASRNormTests(unittest.TestCase):
    def test_traditional_and_game_terms_are_normalized(self):
        text = normalize_text(
            "因為他是有源自課的，屬性傷害爭議，消耗95的生命",
            "老M 阿奇拉 图鉴",
        )
        self.assertIn("因为他是有缘之客的", text)
        self.assertIn("属性伤害增益", text)
        self.assertIn("消耗95%的生命", text)

    def test_author_name_is_context_corrected(self):
        self.assertEqual(normalize_text("我是老N", "老M 棕色尘埃2"), "我是老M")
        self.assertEqual(normalize_text("我是老N", "其他视频"), "我是老N")

    def test_japanese_text_keeps_kanji(self):
        self.assertEqual(
            normalize_text("龍の涙", "アニメ", chinese=False),
            "龍の涙",
        )
        segments = _normalize_segments(
            [SubtitleSegment(0, 1, "龍の涙", "asr")],
            {"title": "アニメ"},
        )
        self.assertIn("龍", segments[0].text)

    def test_review_terms_are_normalized(self):
        text = normalize_text(
            "从航到达排名，内部历史、泰律诗，有源制科技",
            "棕色尘埃2 有缘之客 墨菲亚",
        )
        self.assertIn("从夯到拉", text)
        self.assertIn("内布里斯", text)
        self.assertIn("泰瑞斯", text)
        self.assertIn("有缘之客", text)

    def test_prompt_echo_is_removed(self):
        segments = [
            SubtitleSegment(0, 1, "请用简体中文转写，", "asr"),
            SubtitleSegment(1, 2, "标题引言、墨菲亚、内布里斯", "asr"),
            SubtitleSegment(3, 4, "正文评价", "asr"),
        ]
        result = _strip_prompt_echo(
            segments,
            {
                "title": "标题",
                "chapters": ["引言", "墨菲亚", "内布里斯"],
            },
        )
        self.assertEqual([seg.text for seg in result], ["正文评价"])

    def test_orlistat_variants_are_normalized(self):
        text = normalize_text(
            "奥利斯塔、奥迪斯达、奥利斯它都是奥利司他的误识别",
            "减肥 医学生",
        )
        self.assertIn("奥利司他", text)
        self.assertNotIn("奥利斯塔", text)
        self.assertNotIn("奥迪斯达", text)


class QATests(unittest.TestCase):
    def analysis(self):
        return {
            "video": {
                "title": "开源阅读教程",
                "description": "下载地址在简介",
                "subtitles": [
                    {
                        "start": 0,
                        "end": 3,
                        "text": "这期是开源阅读教程",
                        "source": "cc",
                    },
                    {
                        "start": 76,
                        "end": 79,
                        "text": "点击网络导入",
                        "source": "cc",
                    },
                    {
                        "start": 80,
                        "end": 83,
                        "text": "把书源地址粘贴进去",
                        "source": "cc",
                    },
                ],
                "comments": [],
                "chapters": [],
            },
            "candidates": [
                {
                    "full_name": "gedoor/legado",
                    "readme": "阅读是一款开源阅读软件。支持导入书源。",
                    "dependencies": [],
                }
            ],
            "brief_md": "# 软件使用简报\n\n## 3. 博主的步骤\n点击网络导入。",
        }

    def test_retrieve_sources_finds_timestamp(self):
        sources = retrieve_sources(self.analysis(), "书源怎么导入？")
        self.assertTrue(any("网络导入" in source["text"] for source in sources))
        self.assertTrue(any(source.get("start") == 76 for source in sources))

    def test_answer_without_llm_returns_extractive(self):
        class NoLLM:
            def available(self):
                return False

        result = answer_question(
            self.analysis(),
            "书源怎么导入？",
            llm=NoLLM(),
        )
        self.assertFalse(result["llm_used"])
        self.assertIn("网络导入", result["answer"])
        self.assertIn("01:16", result["answer"])

    def test_answer_with_fake_llm(self):
        class FakeLLM:
            def available(self):
                return True

            def complete(self, system, user, **kwargs):
                return "按视频 [01:16] 点击网络导入。"

        result = answer_question(
            self.analysis(),
            "书源怎么导入？",
            llm=FakeLLM(),
        )
        self.assertTrue(result["llm_used"])
        self.assertIn("01:16", result["answer"])

    def test_empty_question_is_rejected(self):
        with self.assertRaises(ValueError):
            answer_question(self.analysis(), "   ")


class MediaAnalyzeTests(unittest.TestCase):
    class ExplodingGitHub:
        def search(self, *args, **kwargs):
            raise AssertionError("media content must not search GitHub")

    class ExplodingGitee:
        def search(self, *args, **kwargs):
            raise AssertionError("media content must not search Gitee")

    def test_media_analysis_skips_repo_search(self):
        result = analyze_video(
            anime_video(),
            github=self.ExplodingGitHub(),
            gitee=self.ExplodingGitee(),
        )
        self.assertEqual(result.kind, "media_content")
        self.assertEqual(result.candidates, [])
        self.assertIn("动漫/影视内容简报", result.brief_md)
        self.assertNotIn("克隆", result.brief_md)


class BriefTests(unittest.TestCase):
    def test_fallback_brief_includes_readme_commands(self):
        video = make_video()
        signals = extract_signals(video)
        selected = RepoCandidate(
            host="github",
            full_name="foo/bar",
            html_url="https://github.com/foo/bar",
            language="Python",
            score=100,
            readme=(
                "# App\n\n## Quick start\n\n"
                "```bash\npip install -r requirements.txt\n"
                "python -m app.main\n```\n"
            ),
        )
        brief = build_fallback_brief(video, signals, [selected], selected)
        self.assertIn("从 README 提取", brief)
        self.assertIn("pip install -r requirements.txt", brief)
        self.assertIn("python -m app.main", brief)

    def test_fallback_brief_uses_full_repo_host(self):
        video = make_video()
        signals = extract_signals(video)
        brief = build_fallback_brief(video, signals, [], None)
        self.assertIn("github.com/foo/bar", brief)

    def test_fallback_brief_states_unknowns(self):
        video = make_video(description="")
        signals = extract_signals(video)
        brief = build_fallback_brief(video, signals, [], None, "测试")
        self.assertIn("# 复刻简报", brief)
        self.assertIn("[未知]", brief)
        self.assertIn("还没有定位到可信的仓库", brief)

    def test_llm_prompt_contains_timestamps_and_candidates(self):
        video = make_video(
            subtitles=[
                SubtitleSegment(start=12, end=15, text="先看效果"),
                SubtitleSegment(start=65, end=70, text="识别用 faster-whisper"),
            ]
        )
        signals = extract_signals(video)
        candidates = [
            RepoCandidate(
                host="github",
                full_name="foo/bar",
                html_url="https://github.com/foo/bar",
                description="voice assistant",
                stars=100,
                language="Python",
                license="MIT",
                readme="# Foo\n\nA local voice assistant.",
            )
        ]
        scored = score_candidates(candidates, signals, video)
        system, user = build_llm_messages(video, signals, scored)
        self.assertIn("不得编造", system)
        self.assertIn("[00:12]", user)
        self.assertIn("候选 1", user)
        self.assertIn("A local voice assistant", user)

    def test_unverified_repo_url_is_flagged(self):
        warnings: list[str] = []
        candidates = [
            RepoCandidate(
                host="github",
                full_name="foo/bar",
                html_url="https://github.com/foo/bar",
            )
        ]
        flag_unverified_repos(
            "仓库是 https://github.com/foo/bar ，另外还看到 github.com/evil/fake",
            candidates,
            warnings,
        )
        self.assertEqual(len(warnings), 1)
        self.assertIn("evil/fake", warnings[0])


class PayloadTests(unittest.TestCase):
    def test_evidence_from_payload(self):
        payload = {
            "video_id": "BV1TEST000002",
            "url": "https://www.bilibili.com/video/BV1TEST000002/",
            "title": "测试视频",
            "description": "desc",
            "tags": ["a", "b"],
            "subtitles": [{"start": 1, "end": 2, "text": "hello"}],
            "comments": [{"author": "u", "text": "c", "likes": 3}],
        }
        video = evidence_from_payload(payload)
        self.assertEqual(video.video_id, "BV1TEST000002")
        self.assertEqual(video.subtitles[0].text, "hello")
        self.assertEqual(video.comments[0].likes, 3)
        self.assertFalse(video.warnings)

    def test_parse_bvid(self):
        self.assertEqual(
            parse_bvid("https://www.bilibili.com/video/BV1xx411c7mD/?spm=1"),
            "BV1xx411c7mD",
        )

    def test_parse_package_json(self):
        deps = parse_dependencies(
            "package.json",
            '{"dependencies":{"react":"18"},"devDependencies":{"vite":"5"}}',
        )
        self.assertIn("react", deps)
        self.assertIn("vite", deps)

    def test_parse_requirements(self):
        deps = parse_dependencies(
            "requirements.txt",
            "# comment\nfastapi==0.1\nrequests>=2\n-r other.txt\n",
        )
        self.assertEqual(deps, ["fastapi", "requests"])

    def test_cookie_is_not_written_to_payload(self):
        tmp = Path("tests/_tmp_cookie_store")
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)
        try:
            store = ProjectStore(tmp)
            result = AnalysisResult(
                video=make_video(),
                signals=ExtractedSignals(),
                candidates=[],
                selected=None,
                brief_md="brief",
                agent_prompt_md="prompt",
            )
            store.save(
                result,
                {"title": "测试", "cookie": "SESSDATA=secret-value"},
            )
            payload = (
                Path(tmp) / "BV1TEST000001" / "payload.json"
            ).read_text(encoding="utf-8")
            self.assertNotIn("secret-value", payload)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_hydrate_passes_cookie_to_client(self):
        seen = {}

        class FakeClient:
            def __init__(self, cookie=""):
                seen["cookie"] = cookie

            def get_subtitles(self, *args):
                return []

            def get_chapters(self, *args):
                return []

            def get_comments(self, *args):
                return []

        video = make_video(subtitles=[], aid=1, cid=2)
        with patch("rj.bilibili.BilibiliClient", FakeClient), patch(
            "rj.asr.asr_available", return_value=False
        ):
            hydrate_evidence(video, {}, cookie="SESSDATA=abc")
        self.assertEqual(seen["cookie"], "SESSDATA=abc")

    def test_media_url_is_not_written_to_payload(self):
        tmp = Path("tests/_tmp_media_store")
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True, exist_ok=True)
        try:
            store = ProjectStore(tmp)
            result = AnalysisResult(
                video=make_video(),
                signals=ExtractedSignals(),
                candidates=[],
                selected=None,
                brief_md="brief",
                agent_prompt_md="prompt",
            )
            store.save(
                result,
                {
                    "title": "测试",
                    "media_url": "https://v26-web.douyinvod.com/signed-secret",
                },
            )
            payload = (
                Path(tmp) / "BV1TEST000001" / "payload.json"
            ).read_text(encoding="utf-8")
            self.assertNotIn("signed-secret", payload)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_video_stream_prefers_low_resolution(self):
        client = BilibiliClient()
        payload = {
            "code": 0,
            "data": {
                "dash": {
                    "video": [
                        {
                            "height": 720,
                            "bandwidth": 2400,
                            "baseUrl": "https://cdn.example/high.mp4",
                        },
                        {
                            "height": 360,
                            "bandwidth": 700,
                            "baseUrl": "https://cdn.example/low.mp4",
                        },
                    ]
                }
            },
        }
        with patch.object(client, "_sign", side_effect=lambda params: params), patch.object(
            client, "_get", return_value=payload
        ):
            urls = client.get_video_urls(1, 2, "BV1xx411c7mD", max_height=480)
        self.assertEqual(urls[0], "https://cdn.example/low.mp4")


class DouyinTests(unittest.TestCase):
    def douyin_video(self) -> VideoEvidence:
        return make_video(
            platform="douyin",
            video_id="7312345678901234567",
            url="https://www.douyin.com/video/7312345678901234567",
            title="ESP32 机器人接线和固件教程",
            description=(
                "开源地址：https://github.com/demo/esp32-robot\n"
                "#ESP32 #机器人 #固件"
            ),
            author="测试作者",
            author_id="sec_uid",
            tags=["ESP32", "机器人", "固件"],
            duration=45,
            subtitles=[],
            comments=[],
        )

    def test_payload_preserves_douyin_platform_and_url(self):
        video = evidence_from_payload(
            {
                "platform": "douyin",
                "video_id": "7312345678901234567",
                "url": "https://www.douyin.com/video/7312345678901234567",
                "title": "抖音机器人",
                "description": "desc",
                "tags": ["机器人"],
            }
        )
        self.assertEqual(video.platform, "douyin")
        self.assertEqual(
            video.url, "https://www.douyin.com/video/7312345678901234567"
        )
        self.assertEqual(video.video_id, "7312345678901234567")

    def test_brief_uses_douyin_labels(self):
        result = analyze_video(self.douyin_video(), offline=True)
        self.assertIn("抖音页面", result.brief_md)
        self.assertIn("作者", result.brief_md)
        self.assertNotIn("B 站页面", result.brief_md)
        self.assertNotIn("UP 主", result.brief_md)

    def test_without_media_url_adds_warning(self):
        result = hydrate_evidence(self.douyin_video(), {}, enable_asr=False)
        joined = "\n".join(result.warnings)
        self.assertIn("抖音没有公开字幕", joined)

    def test_media_host_allowlist(self):
        self.assertTrue(
            media_host_allowed("https://v26-web.douyinvod.com/abc/video.mp4")
        )
        self.assertFalse(media_host_allowed("http://127.0.0.1/private"))
        self.assertFalse(media_host_allowed("https://example.com/video.mp4"))

    def test_media_url_triggers_asr_and_deletes_temp_file(self):
        video = self.douyin_video()
        video.warnings = [
            "没有拿到抖音视频直链，无法做本地语音识别；本次只整理标题、简介和标签。"
        ]
        tmp = Path("tests/_tmp_douyin_media.mp4")
        tmp.write_bytes(b"x" * 12000)
        try:
            with patch(
                "rj.douyin.ASRConfig.from_env", return_value=ASRConfig(enabled=True)
            ), patch("rj.douyin.asr_available", return_value=True), patch(
                "rj.douyin.download_media", return_value=tmp
            ), patch(
                "rj.douyin.transcribe_media_file",
                return_value=[SubtitleSegment(0, 2, "测试转写", source="asr")],
            ):
                result = hydrate_douyin(
                    video, {"media_url": "https://v26-web.douyinvod.com/x.mp4"}
                )
            self.assertEqual(result.subtitles[0].text, "测试转写")
            self.assertFalse(
                any("没有拿到抖音视频直链" in warning for warning in result.warnings)
            )
            self.assertFalse(tmp.exists())
        finally:
            tmp.unlink(missing_ok=True)


class VisionTests(unittest.TestCase):
    def test_parse_vision_json_accepts_code_fence(self):
        data = parse_vision_json(
            '```json\n{"summary":"画面","people":["未知"]}\n```'
        )
        self.assertEqual(data["summary"], "画面")
        self.assertEqual(data["people"], ["未知"])

    def test_normalize_vision_result_keeps_timestamps(self):
        frames = [
            ExtractedFrame(1.5, Path("a.jpg"), 100, 60),
            ExtractedFrame(4.0, Path("b.jpg"), 100, 60),
        ]
        config = VisionConfig(enabled=True, model="demo")
        result = normalize_vision_result(
            {
                "summary": "角色站在窗前",
                "emotion": ["低头，氛围压抑"],
                "scene_notes": [
                    {
                        "time": 1.5,
                        "observation": "角色低头",
                        "confidence": "visible",
                    }
                ],
            },
            frames,
            config,
        )
        self.assertEqual(result["scene_notes"][0]["time"], 1.5)
        self.assertEqual(result["scene_notes"][0]["confidence"], "visible")
        self.assertEqual(result["model"], "demo")

    def test_attach_visual_analysis_replaces_no_vision_disclaimer(self):
        video = anime_video()
        video.visual_analysis = {
            "summary": "角色站在窗前，低头沉默",
            "people": ["一名黑发角色（身份未知）"],
            "emotion": ["压低视线，氛围压抑"],
            "scene_notes": [
                {
                    "time": 12,
                    "observation": "角色低头站在窗前",
                    "confidence": "visible",
                }
            ],
            "frames": [{"time": 12}],
            "model": "demo-vl",
        }
        signals = extract_signals(video)
        classification = classify_video(video, signals)
        brief = build_media_brief(video, signals, classification)
        brief = attach_visual_analysis(brief, video)
        self.assertIn("## 画面证据（AI）", brief)
        self.assertIn("[00:12] 角色低头站在窗前（画面）", brief)
        self.assertIn("已使用视觉模型分析少量关键帧", brief)
        self.assertNotIn("当前没有接入视觉模型", brief)
        self.assertNotIn("画面表情、演出和氛围需要视觉模型分析", brief)

    def test_merge_vision_results_combines_single_image_batches(self):
        frames = [
            ExtractedFrame(1.0, Path("a.jpg"), 100, 60),
            ExtractedFrame(3.0, Path("b.jpg"), 100, 60),
        ]
        config = VisionConfig(enabled=True, model="glm-4v-flash", max_images=1)
        merged = merge_vision_results(
            [
                {
                    "summary": "第一帧",
                    "people": ["角色A"],
                    "scene_notes": [
                        {"time": 1.0, "observation": "角色A抬头", "confidence": "visible"}
                    ],
                },
                {
                    "summary": "第二帧",
                    "people": ["角色A", "角色B"],
                    "scene_notes": [
                        {"time": 3.0, "observation": "角色B转身", "confidence": "inferred"}
                    ],
                },
            ],
            frames,
            config,
        )
        self.assertEqual(merged["summary"], "第一帧；第二帧")
        self.assertEqual(merged["people"], ["角色A", "角色B"])
        self.assertEqual([note["time"] for note in merged["scene_notes"]], [1.0, 3.0])
        self.assertEqual(merged["model"], "glm-4v-flash")

    def test_extract_frames_from_generated_video(self):
        output = Path("tests/_tmp_frame_test")
        shutil.rmtree(output, ignore_errors=True)
        output.mkdir(parents=True, exist_ok=True)
        video_path = output / "source.mp4"
        try:
            import av
            import numpy as np

            container = av.open(str(video_path), mode="w")
            stream = container.add_stream("mpeg4", rate=5)
            stream.width = 96
            stream.height = 64
            stream.pix_fmt = "yuv420p"
            for index in range(10):
                array = np.zeros((64, 96, 3), dtype=np.uint8)
                array[:, :, index % 3] = 40 + index * 12
                array[:, index * 7 : index * 7 + 10, :] = 220
                frame = av.VideoFrame.from_ndarray(array, format="rgb24")
                for packet in stream.encode(frame):
                    container.mux(packet)
            for packet in stream.encode():
                container.mux(packet)
            container.close()

            frames = extract_frames(
                video_path,
                duration=2,
                count=3,
                max_width=80,
                output_dir=output / "frames",
            )
            self.assertGreaterEqual(len(frames), 1)
            self.assertTrue(all(frame.path.exists() for frame in frames))
        finally:
            shutil.rmtree(output, ignore_errors=True)


class AnalyzeTests(unittest.TestCase):
    class EmptyGitHub:
        def search(self, query, per_page=6):
            return []

    class EmptyGitee:
        def search(self, query, per_page=6):
            return []

    class FakeLLM:
        def available(self):
            return True

        def complete(self, system, user, **kwargs):
            return "# 复刻简报：测试项目\n\n## 0. 一句话结论\n[推断] 这是一个测试。"

    class BrokenLLM:
        def available(self):
            return True

        def complete(self, system, user, **kwargs):
            raise LLMError("模拟失败")

    class ExplodingGitHub:
        def search(self, *args, **kwargs):
            raise AssertionError("hardware video must not search GitHub")

    class ExplodingGitee:
        def search(self, *args, **kwargs):
            raise AssertionError("hardware video must not search Gitee")

    def test_llm_success_path(self):
        video = make_video(description="", subtitles=[])
        result = analyze_video(
            video,
            llm=self.FakeLLM(),
            github=self.EmptyGitHub(),
            gitee=self.EmptyGitee(),
        )
        self.assertTrue(result.llm_used)
        self.assertIn("测试项目", result.brief_md)

    def test_llm_failure_falls_back(self):
        video = make_video(description="", subtitles=[])
        result = analyze_video(
            video,
            llm=self.BrokenLLM(),
            github=self.EmptyGitHub(),
            gitee=self.EmptyGitee(),
        )
        self.assertFalse(result.llm_used)
        self.assertIn("本地规则生成", result.brief_md)
        self.assertTrue(any("模拟失败" in warning for warning in result.warnings))

    def test_hardware_analysis_skips_repo_search(self):
        video = make_video(
            title="联想拯救者R9000P Y9000P，清灰换相变片，超详细教程",
            description="",
            tags=["笔记本", "清灰"],
            subtitles=[],
        )
        result = analyze_video(
            video,
            github=self.ExplodingGitHub(),
            gitee=self.ExplodingGitee(),
        )
        self.assertEqual(result.kind, "hardware_tutorial")
        self.assertEqual(result.candidates, [])
        self.assertIn("硬件维修简报", result.brief_md)
        self.assertIn("未检索代码仓库", result.brief_md)

    def test_general_video_skips_repo_search(self):
        video = make_video(
            title="周末去爬山",
            description="记录一次徒步",
            tags=["vlog"],
            subtitles=[],
        )
        result = analyze_video(
            video,
            github=self.ExplodingGitHub(),
            gitee=self.ExplodingGitee(),
        )
        self.assertEqual(result.kind, "general")
        self.assertEqual(result.candidates, [])
        self.assertIn("视频内容简报", result.brief_md)

    def test_immaterial_software_brief_is_short(self):
        video = make_video(description="", subtitles=[])
        signals = extract_signals(video)
        brief = build_fallback_brief(video, signals, [], None)
        self.assertIn("材料不足", brief)
        self.assertNotIn("克隆", brief)


if __name__ == "__main__":
    unittest.main()
