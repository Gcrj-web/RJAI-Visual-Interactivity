param(
    [string]$Version = "0.1.0",
    [string]$OutputRoot = ".."
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $projectRoot

$outputFull = [IO.Path]::GetFullPath((Join-Path $projectRoot $OutputRoot))
New-Item -ItemType Directory -Path $outputFull -Force | Out-Null

$name = "RJ-$Version"
$target = Join-Path $outputFull $name
$targetFull = [IO.Path]::GetFullPath($target)
if ($targetFull.TrimEnd([IO.Path]::DirectorySeparatorChar) -eq $projectRoot.TrimEnd([IO.Path]::DirectorySeparatorChar)) {
    throw "Target directory cannot be the source directory. Use a different -Version or an external staging folder."
}
$prefix = $outputFull.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if (-not $targetFull.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Target directory is outside the output root: $targetFull"
}

if (Test-Path -LiteralPath $targetFull) {
    Remove-Item -LiteralPath $targetFull -Recurse -Force
}
New-Item -ItemType Directory -Path $targetFull -Force | Out-Null

# Package source, extension, samples, tests, and launchers; exclude runtime data and caches.
$excludeDirs = @(
    "__pycache__", "data", "dist", ".git", ".venv", "venv",
    ".pytest_cache", ".idea", ".vscode", "tmp*", "legacy-panel"
)
$robocopyArgs = @(
    $projectRoot, $targetFull, "/E", "/NFL", "/NDL", "/NJH", "/NJS", "/NP",
    "/XF", "*.pyc"
)
foreach ($dir in $excludeDirs) {
    $robocopyArgs += "/XD"
    $robocopyArgs += $dir
}

& robocopy @robocopyArgs | Out-Null
if ($LASTEXITCODE -ge 8) {
    throw "robocopy failed with exit code $LASTEXITCODE"
}

$buildTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$versionPath = Join-Path $targetFull "VERSION.txt"
if (-not (Test-Path -LiteralPath $versionPath)) {
    "RJ $Version" | Set-Content -LiteralPath $versionPath -Encoding UTF8
}
Add-Content -LiteralPath $versionPath -Value "Packaged: $buildTime as RJ $Version" -Encoding UTF8

$zipPath = Join-Path $outputFull "$name.zip"
if (Test-Path -LiteralPath $zipPath) {
    Remove-Item -LiteralPath $zipPath -Force
}
Compress-Archive -Path $targetFull -DestinationPath $zipPath -CompressionLevel Optimal

Write-Host "Package created: $targetFull"
Write-Host "Archive: $zipPath"
