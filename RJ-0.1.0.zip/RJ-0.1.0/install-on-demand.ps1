$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$native = Join-Path $root "native"
$source = Join-Path $native "rj_native_host.cs"
$exe = Join-Path $native "rj_native_host.exe"
$manifest = Join-Path $native "com.rj.local.json"
$csc = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if (-not (Test-Path -LiteralPath $csc)) {
    throw "csc.exe not found; cannot compile native host."
}

New-Item -ItemType Directory -Path $native -Force | Out-Null
& $csc /nologo /target:exe /out:$exe $source
if ($LASTEXITCODE -ne 0) {
    throw "native host compilation failed."
}

$edgeKey = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.rj.local"
$chromeKey = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.rj.local"
New-Item -Path $edgeKey -Force | Out-Null
Set-ItemProperty -Path $edgeKey -Name "(default)" -Value $manifest
New-Item -Path $chromeKey -Force | Out-Null
Set-ItemProperty -Path $chromeKey -Name "(default)" -Value $manifest

Write-Host "Native Messaging host installed."
Write-Host "Edge registry: $edgeKey"
Write-Host "Host executable: $exe"
