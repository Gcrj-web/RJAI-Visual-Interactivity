@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set HF_HOME=%~dp0data\hf-cache
if not defined HF_ENDPOINT set HF_ENDPOINT=https://hf-mirror.com
if not defined RJ_ASR_LANGUAGE set RJ_ASR_LANGUAGE=auto
"D:\Anaconda3\pythonw.exe" -m rj.cli serve --port 8765 >> "%~dp0data\server.log" 2>&1
