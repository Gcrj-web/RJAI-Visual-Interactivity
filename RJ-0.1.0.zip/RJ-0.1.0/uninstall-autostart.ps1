$shortcutPath = Join-Path ([Environment]::GetFolderPath("Startup")) "RJ Local Server.lnk"
if (Test-Path -LiteralPath $shortcutPath) {
    Remove-Item -LiteralPath $shortcutPath -Force
    Write-Host "已移除 RJ 开机启动项：$shortcutPath"
} else {
    Write-Host "没有找到 RJ 开机启动项。"
}
Write-Host "当前正在运行的服务不会被停止。"
