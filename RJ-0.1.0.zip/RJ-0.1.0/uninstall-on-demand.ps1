$edgeKey = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.rj.local"
$chromeKey = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.rj.local"
foreach ($key in @($edgeKey, $chromeKey)) {
    if (Test-Path -LiteralPath $key) {
        Remove-Item -LiteralPath $key -Recurse -Force
    }
}
Write-Host "Removed RJ Native Messaging registry entries."
Write-Host "The running server is not stopped automatically."
