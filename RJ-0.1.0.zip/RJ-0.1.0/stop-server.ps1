$stopped = @()
$lines = netstat -ano | Select-String ":8765"
foreach ($line in $lines) {
    if ($line.Line -match "LISTENING\s+(\d+)\s*$") {
        $serverPid = [int]$matches[1]
        if ($serverPid -gt 0) {
            Stop-Process -Id $serverPid -Force -ErrorAction SilentlyContinue
            $stopped += $serverPid
        }
    }
}

$wrappers = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object {
    $_.CommandLine -and $_.CommandLine -like "*start-ondemand.*"
}
foreach ($wrapper in $wrappers) {
    Stop-Process -Id $wrapper.ProcessId -Force -ErrorAction SilentlyContinue
}

if ($stopped.Count -eq 0) {
    Write-Host "No running RJ server found."
} else {
    Write-Host ("Stopped RJ server PID: " + ($stopped -join ", "))
}
