$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
$env:PYTHONIOENCODING = "utf-8"
$env:HF_HOME = Join-Path $PSScriptRoot "data\hf-cache"
if (-not $env:HF_ENDPOINT) {
    $env:HF_ENDPOINT = "https://hf-mirror.com"
}
if (-not $env:RJ_ASR_LANGUAGE) {
    $env:RJ_ASR_LANGUAGE = "auto"
}
python -c "import requests" 2>$null
if ($LASTEXITCODE -ne 0) {
    python -m pip install -r requirements.txt
}
python -m rj.cli serve --port 8765
