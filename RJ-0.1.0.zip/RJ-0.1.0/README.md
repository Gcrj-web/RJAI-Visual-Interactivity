# RJ 复刻情报

把 B 站 / 抖音视频变成一份可以直接交给编码 Agent 的**项目复刻简报**。

它解决的不是"总结视频"，而是：你看到一个陌生项目，知道它很酷，但不知道从哪开始、该问 AI 什么、哪些信息视频里根本没给。RJ 会先找到项目在 GitHub/Gitee 上的权威源，再对照视频内容生成"已确认 / 推断 / 未知 / 需要你决策"的结构化情报。

当前版本覆盖 **B 站与抖音的软件项目、软件使用教程、硬件教程、游戏攻略和影视/动漫内容**。软件项目会检索代码仓库；其余类型只整理视频证据，不会硬套“克隆仓库、编译运行”的模板。

## 工作方式

```text
B 站 / 抖音视频页
   │  Edge 扩展读取标题、简介、标签、评论和页面数据；B 站额外带上登录 Cookie
   ▼
本地服务 127.0.0.1:8765
   │  1. 提取仓库地址、技术词、可检索线索
   │  2. B 站补取官方/AI 字幕；抖音有直链时临时下载并做本地 ASR
   │  3. 检索 GitHub/Gitee，打分排序
   │  4. 读取 README、依赖清单、许可证
   │  5. LLM 综合（可选）或本地规则生成
   ▼
data/projects/<BV号>/
   ├── brief.md          复刻简报
   ├── agent_prompt.md   可直接粘贴给 Codex/Claude Code 的任务包
   ├── analysis.json     结构化结果
   └── evidence.json     视频证据
```

核心原则：**视频只是线索，仓库和文档才是事实源。** 简报里每一条关键信息都要求标注证据和 `[确认]/[推断]/[未知]`，避免把视频口播或模型猜测当成事实。

## 抖音支持与限制

打开 `https://www.douyin.com/video/...`、`/note/...`，或在用户页的视频弹窗里点右下角 RJ，就可以提取：

- 标题、简介、作者、话题标签、时长和页面文字。
- 用户主页打开视频弹窗时，以当前正在播放的 `video` 为中心提取文案和作者，不会拿主页简介或列表里其他视频的文案。
- 页面数据中自带的高赞评论（如果存在）。
- 拿到抖音直链时，会临时下载媒体并做本地语音识别；转写完成后删除临时文件。

抖音没有像 B 站那样公开的字幕接口，评论区也需要登录态和签名参数。当前版本不会伪造评论或字幕：如果页面数据里没有评论，或没有拿到可转写的直链，简报会明确写出限制并只整理已有文字。私密、付费、DRM 或需要验证码的视频不支持。抖音是单页应用，切换视频后建议刷新页面再点 RJ。

## AI 画面分析（可选）

默认关闭。启用后，RJ 会补上“画面里有什么”的证据：

1. 服务端把低码率视频临时下载到 `data/cache/vision/`。
2. 用 PyAV 抽取 6-10 个关键帧，跳过全黑帧和高度重复帧。
3. 调用视觉模型，输出可见人物/物体、动作、屏幕文字、表情/氛围线索和逐帧时间戳。
4. 结果写入简报的“画面证据（AI）”一节，并标注 `[画面]`、`[画面推断]`、`[未知]`。
5. 分析结束后删除临时视频和关键帧，只保留文本结论。

### 云端模型（OpenAI-compatible）

当前默认配置使用智谱 **GLM-4V-Flash**。复制 `samples/vision.example.json` 到 `data/vision.json`，填入 Key：

```json
{
  "enabled": true,
  "provider": "openai",
  "base_url": "https://open.bigmodel.cn/api/paas/v4",
  "api_key": "YOUR_ZHIPU_KEY",
  "model": "glm-4v-flash",
  "max_frames": 8,
  "max_images": 1
}
```

GLM-4V-Flash 目前按单图请求处理，RJ 会把 8 个关键帧分成 8 次调用，再把结果合并；如果模型支持多图，可把 `max_images` 调大。

默认用 `image_format: "data_url"` 发送图片。如果智谱接口返回图片格式错误，把它改成 `"base64"` 再试一次。

也可以直接用环境变量：`RJ_VISION_ENABLED=1`、`RJ_VISION_PROVIDER=openai`、`RJ_VISION_BASE_URL`、`RJ_VISION_API_KEY`、`RJ_VISION_MODEL`、`RJ_VISION_MAX_IMAGES`。`data/vision.json` 不进入压缩包，API Key 是明文保存的，请不要提交到公开仓库。

最简单的方法：进入项目目录，双击 `configure-vision.cmd`，按窗口提示粘贴 Key。脚本会自动写配置、用示例图片测试一次模型并重启本地服务。

也可以在项目目录运行：

```powershell
.\configure-vision.ps1
```

它会提示你粘贴 Key（输入不会显示），自动写入 `data/vision.json`、检查配置并重启本地服务。若 PowerShell 阻止脚本运行，改用：

```powershell
powershell -ExecutionPolicy Bypass -File .\configure-vision.ps1
```

其他 OpenAI-compatible 服务也可以直接替换地址和模型。例如阿里云百炼 Qwen-VL：

```json
{
  "enabled": true,
  "provider": "openai",
  "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
  "api_key": "YOUR_DASHSCOPE_KEY",
  "model": "qwen-vl-max",
  "max_frames": 8,
  "max_images": 4
}
```

如果本机需要走代理访问云端接口，在启动服务的环境里设置 `RJ_USE_SYSTEM_PROXY=1`；默认为了避开失效代理会直连。

### 本地 Ollama

```powershell
ollama pull qwen2.5vl:7b
```

然后在 `data/vision.json` 中设置：

```json
{
  "enabled": true,
  "provider": "ollama",
  "base_url": "http://127.0.0.1:11434",
  "model": "qwen2.5vl:7b",
  "max_frames": 8
}
```

本地模式不上传画面，但需要下载数 GB 模型；CPU 推理会明显慢于云端。

### 检查配置

```powershell
python -m rj.cli vision
python -m rj.cli vision --image samples\frame.jpg
```

第一条只打印配置状态，第二条会用一张本地图片实际调用模型。浏览器扩展弹窗和 `/api/health` 也会显示视觉模型是否可用。

没有配置视觉模型时，RJ 不会伪造画面结论，只会在简报里明确写出“文字证据的边界”。云端模式会把关键帧发送给模型服务并产生调用费用；本地 Ollama 不会上传画面。

## 视频类型路由

同一套入口会先判断视频类型，再决定要不要找仓库：

- **软件项目**：检索 GitHub/Gitee，生成复刻简报和编码 Agent 任务包。
- **软件使用/安装教程**：不生成源码构建路径，按字幕抽出博主自己的下载、安装、导入步骤，并给出手机/桌面平台相关问题。
- **硬件维修/拆机教程**：不检索代码仓库，生成硬件维修简报，整理型号、操作、工具、耗材、时间线和风险；没有画面 OCR/BOM 时会明确标注。
- **硬件资讯/评测/价格讨论**：不检索仓库，按通用内容简报整理；只有出现明确的拆机、清灰、换硅脂等维修信号时才走硬件教程。
- **硬件 + 软件混合教程**：同时整理硬件型号/组件/接线和软件/固件/代码步骤，问题会同时覆盖开发板、供电、烧录和软件版本。
- **游戏攻略/抽卡规划**：优先整理博主的章节和字幕原话，单独列出抽卡/资源要点，只保留 3 条高赞观众评论作旁证。
- **游戏测评/主观排行**：提取博主的档位、逐项评价、优缺点和倾向；排名只作为“博主观点”，不写成客观强度榜，也不强行生成抽卡规划。
- **科普/健康**：分层整理博主主张、个人体验、机制解释和待核实说法；标出购买链接/优惠，不给医疗建议，也不生成仓库或代码复刻步骤。
- **动漫/影视内容**：只整理标题、简介、字幕和观众反馈；没有视觉模型时不判断人物表情、关系或画面情绪，也不生成“你希望我分析什么”的提问清单。
- **通用内容**：生成内容简报，不生成代码复刻路径。

这样硬件教程不会再被套上“克隆仓库、跑示例”的模板，也不会拿一堆无关的 GitHub 仓库凑候选列表。

## 快速开始

需要 Python 3.10+、Microsoft Edge 111+。Chrome 111+ 也能直接用同一份代码。

```powershell
cd D:\自己的项目\RJ
python -m pip install -r requirements.txt
python -m rj.cli serve
```

如果用的是 cmd，而不是 PowerShell，跨盘符要加 `/d`：

```cmd
cd /d "D:\自己的项目\RJ"
python -m pip install -r requirements.txt
python -m rj.cli serve
```

也可以直接双击项目根目录的 `start.cmd`，它会自动切到项目目录并启动服务。PowerShell 用户可以运行 `.\start.ps1`。

### 按需启动（推荐）

浏览器扩展不能直接启动本地 exe，这是浏览器的安全限制。本项目使用 Native Messaging 宿主实现按需启动，不创建开机启动项：

- 打开扩展弹窗或点击页面右下角 RJ 时，扩展调用 `native\rj_native_host.exe`。
- 宿主检查 8765 端口；未运行就启动 `start-ondemand.vbs`，等待健康检查通过。
- 不使用时不会在后台占用资源；服务不会开机启动。

首次安装，或移动了扩展目录后，运行：

```powershell
.\install-on-demand.ps1
```

然后到 `edge://extensions` 重新加载 RJ 扩展；如果 Native Messaging 不生效，重启一次 Edge。

停止当前服务：

```powershell
.\stop-server.ps1
```

也可以直接点扩展弹窗里的“停止服务”。

取消 Native Messaging 注册：

```powershell
.\uninstall-on-demand.ps1
```

日志在 `data\server.log` 和 `data\native_host.log`。

如果扩展提示 `native messaging host not found`，先在 `edge://extensions` 重新加载扩展；仍然不行就重启一次 Edge。移动 `extension` 目录后扩展 ID 会变化，需要按新 ID 更新 `native\com.rj.local.json` 的 `allowed_origins`，再运行 `install-on-demand.ps1`。

然后：

1. 打开 `edge://extensions`，在左侧开启"开发人员模式"。
2. 点"加载解压缩的扩展"，选择本项目的 `extension/` 目录。
3. 打开任意 B 站视频页，点右下角紫色的 **RJ** 按钮。
4. 等状态变成"完成"，在"简报 / 任务包 / 追问 / 候选仓库"之间切换。
5. 面板默认停靠在页面右侧，不挡页面操作；点顶部的布局按钮可以在“侧边 / 居中”之间切换。
6. 面板顶部可以复制当前 Tab、打开视频里给出的仓库，或用右上角按钮关闭面板。
7. 也可以点 Edge 工具栏里的 RJ 图标，检查本地服务是否已启动、修改服务地址。

面板使用暗色卡片布局：标题、表格、引用块、列表、行内代码和代码块都会按 Markdown 渲染，不再显示 `##`、`-` 这类原始符号。侧边模式没有遮罩，页面可以继续点击和滚动；居中模式适合专注阅读。布局选择会保存在本机，下次打开沿用。窄屏下会自动改为上下布局。

Edge 和 Chrome 共用同一份 Manifest V3 代码，不需要维护两个版本。扩展用到的 `world: "MAIN"` 需要 Chromium 111+；本机 Edge 155 已满足。

### Edge 加载失败怎么办

- 提示"清单文件缺失或不可读取"：你选的是项目根目录，应该选 `D:\自己的项目\RJ\extension`。
- 工具栏找不到 RJ：点地址栏右侧的拼图图标，把 RJ 固定到工具栏；页面右下角的 RJ 按钮不受影响。
- 视频页右下角没有 RJ：确认地址是 `https://www.bilibili.com/video/...`，然后刷新页面；Edge 需要 111 以上。
- 重新加载扩展后旧标签页里没有 RJ：点工具栏 RJ 图标，再点“在当前页显示 RJ”，会手动补注入，不需要刷新。
- 提示连接不上本地服务：先在项目目录运行 `python -m rj.cli serve`，再点工具栏的 RJ 图标检查状态。
- 弹窗提示连接不上，但服务窗口里 `GET /api/health` 是 200、`OPTIONS /api/ingest` 是 403：旧版本的来源校验问题，关掉当前服务窗口后重新双击 `start.cmd` 即可。

## 打包

以后新增小项目时，默认把源码、扩展、样例、测试和启动脚本一起打成带目录结构的文件夹，而不是只给散文件。

```powershell
.\package.ps1
# 自定义版本号
.\package.ps1 -Version 0.2.0
```

产物：

```text
dist\RJ-0.1.0\
├── rj\
├── extension\
├── samples\
├── tests\
├── README.md
├── requirements.txt
├── start.cmd
├── start.ps1
└── VERSION.txt

dist\RJ-0.1.0.zip
```

打包会自动排除 `data/`、`__pycache__`、虚拟环境和缓存。解压后直接双击 `start.cmd` 就能启动。

不想先开浏览器的话，可以跑离线样例：

```powershell
python -m rj.cli demo
Get-Content data\projects\BV1RJ411A1DEMO\brief.md -Encoding UTF8
```

## 配置

### 1. LLM（可选，但推荐）

不配置也能用，会回退到本地规则生成的简报。配置后，综合分析、视频时间线、复刻路径和问题清单会明显更好。

支持任何 OpenAI-compatible `/chat/completions` 接口。

```powershell
$env:RJ_LLM_BASE_URL = "https://api.deepseek.com/v1"
$env:RJ_LLM_API_KEY  = "sk-..."
$env:RJ_LLM_MODEL    = "deepseek-chat"
python -m rj.cli serve
```

其他例子：

```powershell
# 阿里云百炼 / Qwen
$env:RJ_LLM_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
$env:RJ_LLM_MODEL    = "qwen-plus"

# 本地 Ollama（需要支持 OpenAI 兼容接口）
$env:RJ_LLM_BASE_URL = "http://127.0.0.1:11434/v1"
$env:RJ_LLM_API_KEY  = "ollama"
$env:RJ_LLM_MODEL    = "qwen2.5:7b"
```

### 2. B 站 Cookie（可选，补字幕用）

扩展会在你点击“提取当前视频”时读取 Edge 中 `bilibili.com` 的登录 Cookie（主要是 `SESSDATA`、`bili_jct`、`buvid3`），只发送给 `127.0.0.1` 本地服务，不写入磁盘。本地服务用 WBI 签名调播放器接口获取官方/AI 字幕。部分视频（尤其是 AI 字幕）需要登录态。

如果你不想让扩展读取 Cookie，也可以在 `data/bilibili_cookie.txt` 里手动放：

```text
SESSDATA=xxxxxx; bili_jct=xxxxxx; buvid3=xxxxxx
```

也可以设置环境变量 `BILIBILI_COOKIE`。没有 Cookie 时仍会尝试本地 ASR；简介、标签、评论仍然可用，简报会明确标注“字幕缺失”或“ASR 可能有误”。

设置后可以用 `python -m rj.cli subs BV1xxxxxxxxx` 验证：返回“字幕段落：N”说明后端能取到字幕；返回 0 说明视频没有字幕、AI 字幕还没生成，或 Cookie 无效。

### 3. GitHub Token（可选）

未登录的 GitHub API 搜索额度较低。配置后更稳定：

```powershell
$env:GITHUB_TOKEN = "ghp_..."
```

Gitee 检索不需要 Token。

### 4. 网络与代理

后端默认直连 B 站，不读取 `HTTP_PROXY`、`HTTPS_PROXY`、`ALL_PROXY`。这样可以避免 Clash 等代理关闭后，后台还继承一个失效代理，导致 `SSL: UNEXPECTED_EOF_WHILE_READING` 或 `ProxyError`。

确实需要代理才能访问 B 站时：

```powershell
$env:RJ_USE_SYSTEM_PROXY = "1"
```

音频下载会尝试主 CDN 和 `backupUrl` 里的备用地址；第三方 PCDN 节点 TLS 中断时会自动换下一个候选，不会在第一个地址上直接放弃。

### 5. 本地语音识别（ASR）

没有 B 站字幕时，后端会下载音频并用 faster-whisper 本地转写。默认不强制安装；没装时会跳过并给出提示。

```powershell
python -m pip install -r requirements-asr.txt
```

首次运行会下载模型（默认 `small`，约 500MB）。国内网络可以先设置镜像：

```powershell
$env:HF_ENDPOINT = "https://hf-mirror.com"
```

常用配置：

```powershell
$env:RJ_ASR_MODEL = "small"        # base / small / medium
$env:RJ_ASR_DEVICE = "cpu"         # 有 NVIDIA GPU 可改 cuda
$env:RJ_ASR_COMPUTE_TYPE = "int8"  # cuda 一般用 float16
$env:RJ_ASR_LANGUAGE = "zh"
$env:RJ_ASR_ENABLED = "1"
```

按需启动脚本默认使用 `RJ_ASR_LANGUAGE=auto`，适合中英日混合视频；只做中文视频可以改成 `zh`，动漫日文内容可以改成 `ja`。`small` 是默认模型，`tiny` 只是测试模型；可以在 `start-ondemand.cmd` 里覆盖 `RJ_ASR_MODEL`。如果 `small` 仍不够，可以改成 `medium`（约 1.5GB，CPU 上明显更慢）。

转写时会用视频标题、简介、标签和章节标题生成术语提示（Whisper 的 `initial_prompt` / `hotwords`），并在输出后做繁转简和常见误词修正，例如“有缘之客”“图鉴”“属性伤害增益”。术语提示会进入缓存文件名；升级提示后旧缓存不会挡住新转写。转写后还会过滤 Whisper 偶尔复读的提示词、标题和章节列表，避免把提示词当成正文。

测试某个视频：

```powershell
python -m rj.cli asr BV1xxxxxxxxx
```

转写结果缓存在 `data/cache/asr/`，同一视频不会重复识别。音频只临时下载，转写完成后删除。CPU 上 6 分钟视频通常需要几分钟，首次运行还要加上模型下载时间。B 站官方/AI 字幕优先于本地 ASR；只有拿不到字幕时才走转写。

`ffmpeg` 是可选的：有就用它统一转成 16k 单声道 wav，没有就交给 faster-whisper 的 PyAV 直接解码。

下载位置都在 D 盘：

- Python 包：`D:\Anaconda3\Lib\site-packages`
- 模型：`<项目目录>\data\models\faster-whisper`
- 转写缓存：`<项目目录>\data\cache\asr`
- 临时音频：`<项目目录>\data\cache\audio`
- Hugging Face 其他缓存：`<项目目录>\data\hf-cache`（`start.cmd` 已设置 `HF_HOME`）

`requirements-asr.txt` 锁定了 `huggingface-hub<1`、`protobuf<7`、`h11<0.15`，避免和现有的 `httpcore`、Streamlit 冲突。不要单独把 `huggingface-hub` 升到 2.x。

本机已经预装 `faster-whisper 1.2.1`、`av 15.1.0`，并下载了 `tiny` 和 `small` 两个模型。`small` 是默认模型，可以直接使用；`tiny` 只用于快速测试。`av` 必须保持在 16 以下，否则 `faster-whisper` 的音频解码会报 `metadata_errors` 参数错误。

## CLI

```powershell
# 启动本地服务（扩展依赖它）
python -m rj.cli serve --port 8765

# 直接从 B 站抓取并分析
python -m rj.cli fetch BV1xxxxxxxxx

# 检查某个视频能否取到字幕（AI 字幕也走这里）
python -m rj.cli subs BV1xxxxxxxxx

# 本地语音识别（需要 requirements-asr.txt）
python -m rj.cli asr BV1xxxxxxxxx

# 对已分析项目追问
python -m rj.cli ask BV1xxxxxxxxx "书源怎么导入？"

# 分析扩展导出的页面 JSON
python -m rj.cli analyze samples\sample_payload.json

# 离线样例，不访问网络
python -m rj.cli demo

# 查看历史
python -m rj.cli list
python -m rj.cli show BV1xxxxxxxxx
```

## 追问

分析完成后，扩展里会多一个“追问”标签。输入问题后会先在已保存的字幕、评论和 README 里检索证据：

- 没有配置 LLM：返回带时间戳的原文片段，明确标注“不是综合结论”。
- 配置了 LLM：基于检索到的证据做综合回答，并要求标注来源。
- 时间戳按钮可以直接跳转到 B 站视频对应位置。

接口：`POST /api/projects/{video_id}/ask`，请求体 `{"question": "..."}`。返回 `answer`、`sources` 和 `llm_used`。

## 评论使用策略

- 简报正文优先使用标题、简介、章节和字幕；评论只放在“观众反馈”或“证据索引”里。
- 类型判断只把点赞最高的 5 条评论当作弱信号；单纯评论区出现“脚本”两个字，不会再把一个硬件资讯视频判成软件项目。
- 默认只取 3 条点赞最高的评论；游戏/影视/通用内容的“观众反馈”会排除 UP 主自己的评论，软件教程的证据索引仍可能保留 UP 的置顶说明。
- 评论只代表观众反应，不能当作角色强度、抽卡数量、剧情或版本事实；问答检索里评论权重也低于字幕和 README。

## 产物说明

`brief.md` 的结构：

- 一句话结论：项目是什么、值不值得复刻、最大风险
- 项目身份：仓库、许可证、语言、最后更新，逐条带证据
- 视频演示了什么：带 `mm:ss` 时间戳
- 技术栈与项目结构
- 从 README 摘录的安装/运行命令（明确标注未执行）
- 分阶段复刻路径：每阶段有验收标准、常见坑、回滚点
- 未知与风险
- 需要你回答的问题
- 给编码 Agent 的任务包

`agent_prompt.md` 是单独抽出来的版本，直接复制给 Codex/Claude Code/Cursor。它的关键约束是：先读仓库再动手、一次只做一个阶段、不得编造接口和路径、遇到 `[未知]` 先提问。

## 当前限制

- OCR 还没接入。没有 B 站字幕时会尝试本地 ASR（需安装 faster-whisper）；没装 ASR 时只能靠简介、字幕和标题。
- 游戏攻略和影视内容只做文字证据整理，不做画面人物识别、表情判断或剧情推断。
- 只支持 B 站单 P；分 P/合集还没合并分析。
- 仓库检索会出现误匹配。界面里可以手动选"用这个仓库重算"，把它变成权威源。
- 依赖清单只读根目录的常见文件，不拉完整文件树。
- 不做代码执行，也不会自动 clone 仓库；这一步交给编码 Agent。
- 硬件类目前只做文字证据简报，不做 BOM、接线图、螺丝/排线画面识别；不能替代官方维修手册。

## 下一阶段

1. 给 ASR 加说话人分离，并在 CPU 允许时提供 `medium` / `large-v3-turbo` 的一键模型切换。
2. 关键帧 OCR，专门抓视频里的 IDE、终端、GitHub 页面和代码。
3. 分 P 与合集聚合，一个项目跨多期时合并证据。
4. 把结果做成 MCP 工具，让 Codex 直接调用 `extract_project(url)`，省掉复制粘贴。
5. 硬件项目：BOM schema、型号置信度、接线图风险提示。

视觉模型与人物情感分析已经记录在 `FUTURE_UPGRADES.md`，当前暂缓；等核心功能稳定后再决定本地 Qwen-VL 还是云端视觉 API。

## 缓存策略

本项目不缓存视频文件。

- 视频画面和视频流不会写入 `data/`。
- 没有字幕时，ASR 只临时下载独立的 DASH 音频，转写完成后立即删除。
- 如果视频没有独立音频流，会跳过 ASR，不会回退下载 durl 整段视频。
- 异常中断留下的临时音频会在下次转写前清理（超过 1 小时）。
- 会保留字幕/评论/README 文本、ASR 转写 JSON、简报和模型，用于快速追问与离线复查。

## 隐私与边界

服务只监听 `127.0.0.1`，数据默认存在本地 `data/`。只有启用 LLM 时，视频文本和仓库 README 摘要会发给你配置的模型服务。

请勿把 `data/bilibili_cookie.txt` 或 `data/` 提交到公开仓库。这个工具面向个人研究用途；抓取和复用代码时请遵守平台条款与仓库许可证。
