param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot "data\vision.json"),
    [switch]$NoRestart,
    [switch]$NoSelfTest
)

$ErrorActionPreference = "Stop"
$configFull = [IO.Path]::GetFullPath($ConfigPath)
if (-not (Test-Path -LiteralPath $configFull)) {
    throw "Configuration file not found: $configFull"
}

Write-Host ""
Write-Host "Get a Zhipu API key at:" -ForegroundColor Cyan
Write-Host "  https://open.bigmodel.cn/  ->  Console / API Keys"
Write-Host ""
Write-Host "Paste the API key and press Enter (input is hidden):" -ForegroundColor Cyan
$secure = Read-Host -AsSecureString
$bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try {
    $key = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr).Trim()
}
finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
}

if ([string]::IsNullOrWhiteSpace($key)) {
    throw "Empty key; configuration was not changed."
}

$config = Get-Content -LiteralPath $configFull -Raw | ConvertFrom-Json
$config.api_key = $key
$config.enabled = $true
$json = $config | ConvertTo-Json -Depth 8
[IO.File]::WriteAllText(
    $configFull,
    $json + [Environment]::NewLine,
    [Text.UTF8Encoding]::new($false)
)
Write-Host "Saved: $configFull" -ForegroundColor Green

$python = "python"
if (Test-Path -LiteralPath "D:\Anaconda3\python.exe") {
    $python = "D:\Anaconda3\python.exe"
}

if (-not $NoSelfTest) {
    Write-Host ""
    Write-Host "Checking vision configuration..." -ForegroundColor Cyan
    Push-Location -LiteralPath $PSScriptRoot
    try {
        & $python -m rj.cli vision
        $image = Join-Path $PSScriptRoot "samples\panel-docked-preview.png"
        if (Test-Path -LiteralPath $image) {
            Write-Host ""
            Write-Host "Testing GLM-4V-Flash with the sample image..." -ForegroundColor Cyan
            & $python -m rj.cli vision --image $image
            if ($LASTEXITCODE -ne 0) {
                Write-Host "Model call failed. Check the key, network and model name. The key was saved." -ForegroundColor Yellow
            }
        }
    }
    finally {
        Pop-Location
    }
}

if (-not $NoRestart) {
    Write-Host ""
    Write-Host "Restarting local service..." -ForegroundColor Cyan
    & (Join-Path $PSScriptRoot "stop-server.ps1")
    Start-Sleep -Seconds 1
    $env:PYTHONIOENCODING = "utf-8"
    $env:HF_HOME = Join-Path $PSScriptRoot "data\hf-cache"
    if (-not $env:HF_ENDPOINT) {
        $env:HF_ENDPOINT = "https://hf-mirror.com"
    }
    if (-not $env:RJ_ASR_LANGUAGE) {
        $env:RJ_ASR_LANGUAGE = "auto"
    }
    Start-Process -FilePath $python -ArgumentList @(
        "-m", "rj.cli", "serve", "--port", "8765"
    ) -WorkingDirectory $PSScriptRoot -WindowStyle Hidden
    Start-Sleep -Seconds 2
    try {
        $health = Invoke-WebRequest -UseBasicParsing `
            -Uri "http://127.0.0.1:8765/api/health" -TimeoutSec 5
        Write-Host "Local service started: $($health.StatusCode)" -ForegroundColor Green
    }
    catch {
        Write-Host "Local service did not respond yet; use the extension popup to restart it." -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Done. Open a video and click RJ." -ForegroundColor Green
