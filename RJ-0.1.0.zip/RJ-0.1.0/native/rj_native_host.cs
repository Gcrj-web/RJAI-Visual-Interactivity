using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

class RjNativeHost
{
    static readonly string Root = @"D:\自己的项目\RJ\dist\RJ-0.1.0";
    static readonly string Python = @"D:\Anaconda3\pythonw.exe";
    static readonly string LogPath = Path.Combine(Root, "data", "native_host.log");

    static void ReadExact(Stream stream, byte[] buffer, int count)
    {
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(buffer, offset, count - offset);
            if (read <= 0) throw new EndOfStreamException();
            offset += read;
        }
    }

    static string ReadMessage()
    {
        var stdin = Console.OpenStandardInput();
        var lengthBytes = new byte[4];
        ReadExact(stdin, lengthBytes, 4);
        int length = BitConverter.ToInt32(lengthBytes, 0);
        if (length <= 0 || length > 1000000) throw new Exception("bad message length");
        var buffer = new byte[length];
        ReadExact(stdin, buffer, length);
        return Encoding.UTF8.GetString(buffer);
    }

    static void WriteMessage(string text)
    {
        var bytes = Encoding.UTF8.GetBytes(text);
        var stdout = Console.OpenStandardOutput();
        var length = BitConverter.GetBytes(bytes.Length);
        stdout.Write(length, 0, length.Length);
        stdout.Write(bytes, 0, bytes.Length);
        stdout.Flush();
    }

    static bool Healthy()
    {
        try
        {
            var request = (HttpWebRequest)WebRequest.Create("http://127.0.0.1:8765/api/health");
            request.Timeout = 1500;
            request.ReadWriteTimeout = 1500;
            using (var response = (HttpWebResponse)request.GetResponse())
            using (var reader = new StreamReader(response.GetResponseStream()))
            {
                string body = reader.ReadToEnd();
                return body.Contains("\"ok\":true") || body.Contains("\"ok\": true");
            }
        }
        catch
        {
            return false;
        }
    }

    static void Log(string message)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogPath));
            File.AppendAllText(
                LogPath,
                DateTime.Now.ToString("o") + " " + message + Environment.NewLine,
                Encoding.UTF8
            );
        }
        catch
        {
        }
    }

    static void StartServer()
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = Path.Combine(Environment.SystemDirectory, "wscript.exe"),
            Arguments = "\"" + Path.Combine(Root, "start-ondemand.vbs") + "\"",
            WorkingDirectory = Root,
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden
        };
        var process = Process.Start(startInfo);
        Log("launched wscript pid=" + (process == null ? 0 : process.Id));
    }

    static void StopServer()
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = "powershell.exe",
            Arguments = "-NoProfile -ExecutionPolicy Bypass -File \"" +
                Path.Combine(Root, "stop-server.ps1") + "\"",
            UseShellExecute = false,
            CreateNoWindow = true,
            WindowStyle = ProcessWindowStyle.Hidden
        };
        var process = Process.Start(startInfo);
        if (process != null) process.WaitForExit(15000);
        Log("stop requested");
    }

    static string Escape(string value)
    {
        return (value ?? string.Empty)
            .Replace("\\", "\\\\")
            .Replace("\"", "\\\"")
            .Replace("\r", string.Empty)
            .Replace("\n", "\\n");
    }

    static void Main()
    {
        string response;
        try
        {
            string message = ReadMessage();
            if (message.Contains("\"stop\""))
            {
                StopServer();
                Thread.Sleep(800);
                response = Healthy()
                    ? "{\"ok\":false,\"message\":\"stop requested but server still healthy\"}"
                    : "{\"ok\":true,\"message\":\"stopped\"}";
            }
            else if (Healthy())
            {
                response = "{\"ok\":true,\"started\":false,\"message\":\"already running\"}";
            }
            else
            {
                StartServer();
                bool healthy = false;
                for (int index = 0; index < 60; index++)
                {
                    Thread.Sleep(500);
                    if (Healthy())
                    {
                        healthy = true;
                        break;
                    }
                }
                response = healthy
                    ? "{\"ok\":true,\"started\":true,\"message\":\"server started\"}"
                    : "{\"ok\":false,\"started\":false,\"message\":\"server did not become healthy; see data/native_host.log and data/server.log\"}";
            }
        }
        catch (Exception error)
        {
            Log("error " + error);
            response = "{\"ok\":false,\"message\":\"" + Escape(error.Message) + "\"}";
        }
        WriteMessage(response);
    }
}
