@echo off
setlocal
cd /d "%~dp0"
echo.
echo ============================================
echo   RJ visual model setup - Zhipu GLM-4V-Flash
echo ============================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure-vision.ps1" %*
echo.
pause
