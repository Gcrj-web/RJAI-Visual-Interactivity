chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) {
    return false;
  }
  if (message.type === "rj_get_bilibili_cookie") {
    chrome.cookies.getAll({ domain: "bilibili.com" }, (cookies) => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, cookie: "" });
        return;
      }
      const wanted = new Set(["SESSDATA", "bili_jct", "buvid3", "DedeUserID"]);
      const parts = (cookies || [])
        .filter((cookie) => wanted.has(cookie.name))
        .map((cookie) => `${cookie.name}=${cookie.value}`);
      sendResponse({ ok: true, cookie: parts.join("; ") });
    });
    return true;
  }
  if (!["rj_ensure_server", "rj_stop_server"].includes(message.type)) {
    return false;
  }
  const action = message.type === "rj_stop_server" ? "stop" : "ensure";
  chrome.runtime.sendNativeMessage("com.rj.local", { action }, (response) => {
    if (chrome.runtime.lastError) {
      sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      return;
    }
    sendResponse(response || { ok: false, error: "native host 没有返回结果" });
  });
  return true;
});
