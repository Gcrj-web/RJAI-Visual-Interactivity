(() => {
  const DEFAULT_BACKEND = "http://127.0.0.1:8765";
  const statusEl = document.getElementById("status");
  const backendEl = document.getElementById("backend");
  let backend = DEFAULT_BACKEND;

  function setStatus(text, kind) {
    statusEl.textContent = text;
    statusEl.className = `status ${kind || ""}`;
  }

  function ensureNative(action) {
    return new Promise((resolve) => {
      const type = action === "stop" ? "rj_stop_server" : "rj_ensure_server";
      chrome.runtime.sendMessage({ type }, (response) => {
        if (chrome.runtime.lastError) {
          const message = chrome.runtime.lastError.message || "";
          resolve({
            ok: false,
            error: message.includes("Receiving end does not exist")
              ? "扩展后台未加载：请在 edge://extensions 重新加载 RJ 扩展"
              : message
          });
          return;
        }
        resolve(response || { ok: false, error: "native host 没有返回结果" });
      });
    });
  }

  async function readHealth() {
    try {
      const response = await fetch(`${backend}/api/health`, { cache: "no-store" });
      if (!response.ok) return false;
      const data = await response.json();
      const llm = data.llm && data.llm.available
        ? "LLM 已配置"
        : "LLM 未配置（可用本地规则）";
      const asr = data.asr
        ? (data.asr.available
            ? (data.asr.enabled ? `ASR 已安装（${data.asr.model}）` : "ASR 已安装但禁用")
            : "ASR 未安装")
        : "ASR 状态未知";
      const vision = data.vision
        ? (data.vision.available
            ? `视觉已配置（${data.vision.model}）`
            : (data.vision.enabled ? "视觉配置不完整" : "视觉未配置"))
        : "视觉状态未知";
      setStatus(`本地服务已连接 · ${llm} · ${asr} · ${vision}`, "ok");
      return true;
    } catch (error) {
      return false;
    }
  }

  async function check() {
    setStatus("正在检查本地服务…");
    if (await readHealth()) return;
    setStatus("正在启动本地服务…");
    const ensured = await ensureNative("ensure");
    if (!ensured.ok) {
      setStatus(`启动失败：${ensured.error}`, "bad");
      return;
    }
    for (let index = 0; index < 30; index += 1) {
      if (await readHealth()) return;
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    setStatus("启动超时，请查看 data/server.log 和 data/native_host.log", "bad");
  }

  chrome.storage.local.get(["rjBackend"], (data) => {
    backend = ((data && data.rjBackend) || DEFAULT_BACKEND).replace(/\/+$/, "");
    backendEl.value = backend;
    check();
  });

  document.getElementById("refresh").addEventListener("click", check);
  document.getElementById("inject").addEventListener("click", async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) {
        setStatus("找不到当前标签页", "bad");
        return;
      }
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["main-world.js"],
        world: "MAIN"
      });
      await chrome.scripting.insertCSS({
        target: { tabId: tab.id },
        files: ["panel.css"]
      });
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["markdown.js", "content.js"]
      });
      setStatus("已注入，右下角应该出现 RJ", "ok");
      setTimeout(() => window.close(), 700);
    } catch (error) {
      setStatus(`注入失败：${error.message || error}`, "bad");
    }
  });
  document.getElementById("save").addEventListener("click", () => {
    const value = backendEl.value.trim().replace(/\/+$/, "");
    if (!value) return;
    backend = value;
    chrome.storage.local.set({ rjBackend: value }, check);
  });
  document.getElementById("open").addEventListener("click", () => {
    chrome.tabs.create({ url: "https://www.bilibili.com" });
  });
  document.getElementById("open-douyin").addEventListener("click", () => {
    chrome.tabs.create({ url: "https://www.douyin.com" });
  });
  document.getElementById("stop").addEventListener("click", async () => {
    setStatus("正在停止本地服务…");
    const result = await ensureNative("stop");
    if (result.ok) {
      setStatus("本地服务已停止", "ok");
    } else {
      setStatus(`停止失败：${result.error}`, "bad");
    }
  });
  document.getElementById("restart").addEventListener("click", async () => {
    setStatus("正在重启本地服务…");
    const stopped = await ensureNative("stop");
    if (!stopped.ok) {
      setStatus(`重启失败：${stopped.error || stopped.message || "服务没有停止"}`, "bad");
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 800));
    const ensured = await ensureNative("ensure");
    if (!ensured.ok) {
      setStatus(`重启失败：${ensured.error}`, "bad");
      return;
    }
    for (let index = 0; index < 30; index += 1) {
      if (await readHealth()) {
        setStatus("本地服务已重启", "ok");
        return;
      }
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
    setStatus("重启超时，请查看 data/server.log", "bad");
  });
})();
