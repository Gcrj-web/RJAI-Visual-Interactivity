(() => {
  "use strict";

  if (document.getElementById("rj-fab")) return;

  const DEFAULT_BACKEND = "http://127.0.0.1:8765";
  const ICONS = {
    dock: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <rect x="3" y="4" width="18" height="16" rx="2"></rect>
        <path d="M15 4v16"></path>
      </svg>`,
    center: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M8 3H5a2 2 0 0 0-2 2v3"></path>
        <path d="M16 3h3a2 2 0 0 1 2 2v3"></path>
        <path d="M8 21H5a2 2 0 0 1-2-2v-3"></path>
        <path d="M16 21h3a2 2 0 0 0 2-2v-3"></path>
      </svg>`,
    settings: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M4 21v-7"></path><path d="M4 10V3"></path>
        <path d="M12 21v-9"></path><path d="M12 8V3"></path>
        <path d="M20 21v-5"></path><path d="M20 12V3"></path>
        <path d="M1 14h6"></path><path d="M9 8h6"></path><path d="M17 16h6"></path>
      </svg>`,
    close: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M18 6 6 18"></path><path d="m6 6 12 12"></path>
      </svg>`,
    external: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M15 3h6v6"></path><path d="M10 14 21 3"></path>
        <path d="M21 14v5a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5"></path>
      </svg>`,
    copy: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <rect x="9" y="9" width="13" height="13" rx="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>`,
    extract: `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
           stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <path d="M12 3v12"></path><path d="m7 10 5 5 5-5"></path>
        <path d="M5 21h14"></path>
      </svg>`
  };

  let backend = DEFAULT_BACKEND;
  let currentResult = null;
  let activeTab = "brief";
  let busy = false;
  let asking = false;
  let askAnswer = null;
  let askDraft = "";
  let statusTimer = null;
  let copyLabelTimer = null;
  let lastStatus = { text: "就绪", kind: "" };
  let panelLayout = "side";

  const fab = document.createElement("button");
  fab.id = "rj-fab";
  fab.type = "button";
  fab.textContent = "RJ";
  fab.title = "打开 RJ 复刻情报";
  fab.setAttribute("aria-label", "打开 RJ 复刻情报");

  const backdrop = document.createElement("div");
  backdrop.id = "rj-backdrop";
  backdrop.setAttribute("aria-hidden", "true");

  const panel = document.createElement("section");
  panel.id = "rj-panel";
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-modal", "false");
  panel.setAttribute("aria-labelledby", "rj-title");
  panel.setAttribute("aria-hidden", "true");
  panel.tabIndex = -1;
  panel.innerHTML = `
    <header id="rj-header">
      <div id="rj-brand">
        <span id="rj-logo" aria-hidden="true">RJ</span>
        <div>
          <div id="rj-eyebrow">Video → Brief</div>
          <h2 id="rj-title">RJ 复刻情报</h2>
          <p id="rj-subtitle">B 站 / 抖音视频 → 可执行的复刻简报</p>
        </div>
      </div>

      <div id="rj-header-actions">
        <div id="rj-window-controls">
          <button type="button" class="rj-icon-btn rj-layout-btn" id="rj-layout"
                  title="居中显示" aria-label="居中显示">${ICONS.center}<span id="rj-layout-label">居中</span></button>
          <button type="button" class="rj-icon-btn" id="rj-settings"
                  title="设置本地服务地址" aria-label="设置本地服务地址">${ICONS.settings}</button>
          <button type="button" class="rj-icon-btn" id="rj-close"
                  title="关闭面板" aria-label="关闭面板">${ICONS.close}</button>
        </div>

        <div id="rj-action-row">
          <a id="rj-open" class="rj-btn rj-btn-ghost" href="#" target="_blank"
             rel="noreferrer" hidden>${ICONS.external}<span>打开仓库</span></a>
          <button type="button" id="rj-copy" class="rj-btn rj-btn-ghost" hidden>
            ${ICONS.copy}<span id="rj-copy-label">复制</span>
          </button>
          <button type="button" id="rj-run" class="rj-btn rj-btn-primary">
            ${ICONS.extract}<span id="rj-run-label">提取当前视频</span>
          </button>
        </div>

        <div id="rj-status" role="status" aria-live="polite">
          <span id="rj-status-dot" aria-hidden="true"></span>
          <span id="rj-status-text">就绪</span>
        </div>
      </div>
    </header>

    <nav id="rj-tabs" role="tablist" aria-label="简报视图" hidden>
      <button type="button" class="rj-tab" id="rj-tab-brief" role="tab"
              data-tab="brief" aria-selected="true" aria-controls="rj-panel-brief"
              tabindex="0">简报</button>
      <button type="button" class="rj-tab" id="rj-tab-agent" role="tab"
              data-tab="agent" aria-selected="false" aria-controls="rj-panel-agent"
              tabindex="-1">任务包</button>
      <button type="button" class="rj-tab" id="rj-tab-ask" role="tab"
              data-tab="ask" aria-selected="false" aria-controls="rj-panel-ask"
              tabindex="-1">追问</button>
      <button type="button" class="rj-tab" id="rj-tab-candidates" role="tab"
              data-tab="candidates" aria-selected="false" aria-controls="rj-panel-candidates"
              tabindex="-1">候选仓库</button>
      <span id="rj-tab-indicator" aria-hidden="true"></span>
    </nav>

    <div id="rj-content-wrap">
      <section class="rj-tab-panel" id="rj-panel-brief" role="tabpanel"
               aria-labelledby="rj-tab-brief">
        <p class="rj-empty">打开一个 B 站或抖音视频，点击“提取当前视频”。</p>
      </section>
      <section class="rj-tab-panel" id="rj-panel-agent" role="tabpanel"
               aria-labelledby="rj-tab-agent" hidden></section>
      <section class="rj-tab-panel" id="rj-panel-ask" role="tabpanel"
               aria-labelledby="rj-tab-ask" hidden></section>
      <section class="rj-tab-panel" id="rj-panel-candidates" role="tabpanel"
               aria-labelledby="rj-tab-candidates" hidden></section>
    </div>

    <footer id="rj-footer">
      <span id="rj-footer-status"><span id="rj-backend-label">本地服务</span></span>
      <span>Manifest V3 · 本地优先</span>
    </footer>
  `;
  panel.classList.add("rj-docked");

  document.body.appendChild(backdrop);
  document.body.appendChild(panel);
  document.body.appendChild(fab);

  const tabsEl = panel.querySelector("#rj-tabs");
  const tabIndicator = panel.querySelector("#rj-tab-indicator");
  const contentWrap = panel.querySelector("#rj-content-wrap");
  const briefPanel = panel.querySelector("#rj-panel-brief");
  const agentPanel = panel.querySelector("#rj-panel-agent");
  const askPanel = panel.querySelector("#rj-panel-ask");
  const candidatesPanel = panel.querySelector("#rj-panel-candidates");
  const runButton = panel.querySelector("#rj-run");
  const runLabel = panel.querySelector("#rj-run-label");
  const copyButton = panel.querySelector("#rj-copy");
  const copyLabel = panel.querySelector("#rj-copy-label");
  const openLink = panel.querySelector("#rj-open");
  const layoutButton = panel.querySelector("#rj-layout");
  const layoutLabel = panel.querySelector("#rj-layout-label");
  const settingsButton = panel.querySelector("#rj-settings");
  const closeButton = panel.querySelector("#rj-close");
  const statusEl = panel.querySelector("#rj-status");
  const statusText = panel.querySelector("#rj-status-text");
  const backendLabel = panel.querySelector("#rj-backend-label");
  const tabButtons = Array.from(panel.querySelectorAll(".rj-tab"));
  const tabPanels = Array.from(panel.querySelectorAll(".rj-tab-panel"));

  /* ============================================================
     Shared helpers
     ============================================================ */
  function h(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function makeButton(className, text, onClick) {
    const button = h("button", className, text);
    button.type = "button";
    if (onClick) button.addEventListener("click", onClick);
    return button;
  }

  function escapeFallback(value) {
    return String(value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[character]));
  }

  function renderMarkdown(value) {
    const source = String(value || "");
    if (window.RJMarkdown && typeof window.RJMarkdown.render === "function") {
      return window.RJMarkdown.render(source);
    }
    return escapeFallback(source).replace(/\n/g, "<br>");
  }

  function markdownNode(value) {
    const article = h("article", "rj-markdown");
    article.innerHTML = renderMarkdown(value);
    return article;
  }

  function formatTime(value) {
    const total = Math.max(0, Math.floor(Number(value) || 0));
    const minutes = String(Math.floor(total / 60)).padStart(2, "0");
    const seconds = String(total % 60).padStart(2, "0");
    return `${minutes}:${seconds}`;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /* ============================================================
     Status, panel and tab state
     ============================================================ */
  function applyStatus(text, kind = "") {
    statusText.textContent = text;
    statusEl.className = kind ? `rj-status rj-status-${kind}` : "rj-status";
    lastStatus = { text, kind };
  }

  function setStatus(text, kind = "") {
    clearTimeout(statusTimer);
    statusTimer = null;
    applyStatus(text, kind);
  }

  function flashStatus(text, kind = "ok") {
    clearTimeout(statusTimer);
    const previous = { ...lastStatus };
    applyStatus(text, kind);
    statusTimer = setTimeout(() => {
      applyStatus(previous.text, previous.kind);
      statusTimer = null;
    }, 2000);
  }

  function setBusy(value) {
    busy = value;
    runButton.disabled = value;
    runLabel.textContent = value ? "分析中…" : "提取当前视频";
    copyButton.disabled = value;
  }

  function updateBackendLabel() {
    backendLabel.textContent = `${backend.replace(/^https?:\/\//, "")} · 本地服务`;
  }

  function syncBackdrop() {
    backdrop.classList.toggle(
      "rj-open",
      panelLayout === "center" && panel.classList.contains("rj-open")
    );
  }

  function applyLayout(layout, persist = true) {
    panelLayout = layout === "center" ? "center" : "side";
    panel.classList.add("rj-layout-switching");
    panel.classList.toggle("rj-docked", panelLayout === "side");
    panel.setAttribute("aria-modal", panelLayout === "center" ? "true" : "false");
    layoutButton.title = panelLayout === "side" ? "居中显示" : "停靠到侧边";
    layoutButton.setAttribute("aria-label", layoutButton.title);
    layoutButton.innerHTML = panelLayout === "side" ? ICONS.center : ICONS.dock;
    layoutButton.appendChild(layoutLabel);
    layoutLabel.textContent = panelLayout === "side" ? "居中" : "侧边";
    syncBackdrop();

    if (persist) {
      chrome.storage.local.set({ rjPanelLayout: panelLayout });
    }

    requestAnimationFrame(() => {
      moveTabIndicator();
      requestAnimationFrame(() => panel.classList.remove("rj-layout-switching"));
    });
  }

  function openPanel() {
    panel.classList.add("rj-open");
    syncBackdrop();
    panel.setAttribute("aria-hidden", "false");
    if (currentResult) render();
    requestAnimationFrame(() => {
      moveTabIndicator();
      panel.focus({ preventScroll: true });
    });
  }

  function closePanel() {
    panel.classList.remove("rj-open");
    syncBackdrop();
    panel.setAttribute("aria-hidden", "true");
    fab.focus({ preventScroll: true });
  }

  function moveTabIndicator() {
    if (tabsEl.hidden) return;
    const active = tabButtons.find((button) => button.dataset.tab === activeTab);
    if (!active) return;
    tabIndicator.style.left = `${active.offsetLeft}px`;
    tabIndicator.style.width = `${active.offsetWidth}px`;
  }

  function activateTab(name, shouldFocus = false) {
    activeTab = name;
    tabButtons.forEach((button) => {
      const selected = button.dataset.tab === name;
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
    });
    tabPanels.forEach((element) => {
      element.hidden = element.id !== `rj-panel-${name}`;
    });
    contentWrap.scrollTop = 0;
    requestAnimationFrame(() => {
      moveTabIndicator();
      if (shouldFocus) {
        const active = tabButtons.find((button) => button.dataset.tab === name);
        if (active) active.focus({ preventScroll: true });
      }
    });
  }

  /* ============================================================
     Rendering
     ============================================================ */
  function render() {
    if (!currentResult) {
      tabsEl.hidden = true;
      copyButton.hidden = true;
      openLink.hidden = true;
      return;
    }

    tabsEl.hidden = false;
    copyButton.hidden = false;

    briefPanel.replaceChildren(markdownNode(currentResult.brief_md || "（空）"));
    agentPanel.replaceChildren(markdownNode(currentResult.agent_prompt_md || "（空）"));
    renderAsk();
    renderCandidates();
    updateRepoLink();
    activateTab(activeTab);
  }

  function updateRepoLink() {
    const url = directRepoUrl(currentResult);
    openLink.hidden = !url;
    if (url) openLink.href = url;
  }

  function directRepoUrl(result) {
    if (result.selected && result.selected.html_url) {
      return result.selected.html_url;
    }
    const match = String(result.brief_md || "").match(
      /https?:\/\/(?:www\.)?(?:github|gitee)\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+/i
    );
    return match ? match[0].replace(/[.,;:!?，。；：！？、]+$/, "") : "";
  }

  function renderAsk() {
    askPanel.replaceChildren();

    askPanel.appendChild(h("h2", "rj-section-title", "追问这条视频"));
    askPanel.appendChild(
      h(
        "p",
        "rj-section-hint",
        "基于已保存的字幕、简介、评论和 README 检索；没有 LLM 时返回带时间戳的原文片段。"
      )
    );

    const form = h("div", "rj-ask-form");
    const input = document.createElement("input");
    input.type = "text";
    input.id = "rj-ask-input";
    input.placeholder = "例如：书源怎么导入？";
    input.value = askDraft;
    input.disabled = asking;
    input.addEventListener("input", () => {
      askDraft = input.value;
    });

    const submit = () => askQuestion(input.value);
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") submit();
    });

    const askButton = makeButton(
      "rj-btn-secondary",
      asking ? "检索中…" : "提问",
      submit
    );
    askButton.id = "rj-ask-button";
    askButton.disabled = asking;

    form.appendChild(input);
    form.appendChild(askButton);
    askPanel.appendChild(form);

    if (asking) {
      askPanel.appendChild(h("div", "rj-ask-loading", "正在检索字幕和 README…"));
    }

    if (askAnswer) {
      const answerCard = h("div", "rj-answer-card");
      answerCard.appendChild(h("div", "rj-answer-label", "Answer"));
      answerCard.appendChild(markdownNode(askAnswer.answer || "（空）"));

      const sources = Array.isArray(askAnswer.sources) ? askAnswer.sources : [];
      for (const source of sources) {
        const row = h("div", "rj-source");
        if (source.start !== null && source.start !== undefined) {
          const jump = makeButton(
            "rj-jump",
            formatTime(source.start),
            () => jumpTo(source.start)
          );
          jump.title = "跳转到视频对应位置";
          row.appendChild(jump);
        } else {
          row.appendChild(h("time", "", source.label || source.source || "来源"));
        }
        row.appendChild(
          h("span", "rj-ask-source-text", source.text || "")
        );
        answerCard.appendChild(row);
      }

      if (!askAnswer.llm_used) {
        answerCard.appendChild(
          h("div", "rj-ask-note", "未配置 LLM：以上是检索到的原文片段，不是综合结论。")
        );
      }
      askPanel.appendChild(answerCard);
    } else if (!asking) {
      askPanel.appendChild(
        h("p", "rj-empty", "提问后会在这里显示回答与证据来源。")
      );
    }
  }

  function renderCandidates() {
    candidatesPanel.replaceChildren();
    candidatesPanel.appendChild(h("h2", "rj-section-title", "候选仓库"));
    candidatesPanel.appendChild(
      h(
        "p",
        "rj-section-hint",
        "显式链接优先；检索候选需要确认后再作为权威源。"
      )
    );

    const candidates = Array.isArray(currentResult.candidates)
      ? currentResult.candidates
      : [];
    const list = h("div", "rj-repo-list");

    if (candidates.length) {
      for (const candidate of candidates) {
        list.appendChild(repoCard(candidate, currentResult.kind === "software_project"));
      }
    } else if (currentResult.selected) {
      list.appendChild(repoCard(currentResult.selected, false));
    } else {
      list.appendChild(
        h(
          "p",
          "rj-empty",
          "没有检索到候选仓库。可以检查视频简介里有没有仓库地址，或在设置里配置 GITHUB_TOKEN。"
        )
      );
    }
    candidatesPanel.appendChild(list);

    if (currentResult.kind === "software_project") {
      candidatesPanel.appendChild(buildManualRepo());
    }
  }

  function repoCard(candidate, allowRecompute) {
    const card = h("article", "rj-repo-card");
    const top = h("div", "rj-repo-top");

    const link = document.createElement("a");
    link.className = "rj-repo-name";
    link.href = candidate.html_url || "#";
    link.target = "_blank";
    link.rel = "noreferrer";
    link.textContent = candidate.full_name || "未命名仓库";
    top.appendChild(link);

    const explicit = candidate.source === "explicit";
    top.appendChild(
      h(
        "span",
        "rj-repo-score",
        explicit ? "显式链接" : `${Number(candidate.score || 0)} 分`
      )
    );
    card.appendChild(top);

    const meta = h("div", "rj-repo-meta");
    const host = candidate.host === "gitee" ? "Gitee" : "GitHub";
    if (explicit) {
      meta.appendChild(h("span", "", host));
      meta.appendChild(h("span", "", "视频文字"));
      meta.appendChild(h("span", "", "未读取 README"));
    } else {
      meta.appendChild(h("span", "", candidate.language || "-"));
      meta.appendChild(h("span", "", `${Number(candidate.stars || 0)} stars`));
      meta.appendChild(h("span", "", candidate.license || "许可证未确认"));
    }
    card.appendChild(meta);

    card.appendChild(
      h(
        "p",
        "rj-repo-reason",
        (candidate.reasons || []).join("；") ||
          "视频文字中直接给出的仓库地址，适合作为复刻的起点。"
      )
    );

    const actions = h("div", "rj-repo-actions");
    if (allowRecompute) {
      actions.appendChild(
        makeButton("rj-btn-small rj-primary", "用这个仓库重算", () =>
          confirmRepo(candidate)
        )
      );
    }
    const open = document.createElement("a");
    open.className = "rj-btn-small";
    open.href = candidate.html_url || "#";
    open.target = "_blank";
    open.rel = "noreferrer";
    open.textContent = "打开仓库";
    actions.appendChild(open);
    card.appendChild(actions);

    return card;
  }

  function buildManualRepo() {
    const manual = h("div", "rj-manual");
    manual.appendChild(h("div", "rj-manual-title", "手动指定仓库"));

    const row = h("div", "rj-manual-row");
    const host = document.createElement("select");
    host.innerHTML = "<option value='github'>GitHub</option><option value='gitee'>Gitee</option>";
    const input = document.createElement("input");
    input.placeholder = "owner/repo";
    const button = makeButton("", "重算", () => {
      const value = input.value.trim();
      if (!value.includes("/")) {
        setStatus("请输入 owner/repo 格式", "error");
        return;
      }
      confirmRepo({ full_name: value, host: host.value });
    });

    row.appendChild(host);
    row.appendChild(input);
    row.appendChild(button);
    manual.appendChild(row);
    return manual;
  }

  /* ============================================================
     Backend calls
     ============================================================ */
  function postJson(path, body) {
    return fetch(`${backend}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }).then(async (response) => {
      let data = null;
      try {
        data = await response.json();
      } catch (error) {
        data = { error: `服务返回了非 JSON 内容 (HTTP ${response.status})` };
      }
      if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      return data;
    });
  }

  async function waitForJob(jobId) {
    for (let index = 0; index < 1800; index += 1) {
      await sleep(1000);
      const response = await fetch(`${backend}/api/jobs/${jobId}`);
      if (!response.ok) throw new Error(`查询任务失败 (HTTP ${response.status})`);
      const job = await response.json();
      setStatus(job.step || job.status || "处理中", "busy");
      if (job.status === "done") return job.result;
      if (job.status === "error") throw new Error(job.error || "分析失败");
    }
    throw new Error("分析超时（30 分钟）");
  }

  function ensureServer() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "rj_ensure_server" }, (response) => {
        if (chrome.runtime.lastError) {
          const message = chrome.runtime.lastError.message || "";
          resolve({
            ok: false,
            error: message.includes("Receiving end does not exist")
              ? "扩展后台未加载：请在 edge://extensions 重新加载 RJ 扩展"
              : message
          });
          return;
        }
        resolve(response || { ok: false, error: "native host 没有返回结果" });
      });
    });
  }

  function getBilibiliCookie() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "rj_get_bilibili_cookie" }, (response) => {
        if (chrome.runtime.lastError) {
          resolve("");
          return;
        }
        resolve((response && response.cookie) || "");
      });
    });
  }

  function requestEvidence() {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        cleanup();
        reject(new Error("页面数据提取超时，刷新页面后重试"));
      }, 20000);

      function cleanup() {
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
      }

      function onMessage(event) {
        if (event.source !== window) return;
        const data = event.data;
        if (!data || data.source !== "rj-main") return;
        if (data.type === "RJ_PAGE_DATA") {
          cleanup();
          resolve(data.payload);
        }
        if (data.type === "RJ_PAGE_ERROR") {
          cleanup();
          reject(new Error(data.error || "页面数据提取失败"));
        }
      }

      window.addEventListener("message", onMessage);
      window.postMessage({ source: "rj-page", type: "RJ_COLLECT" }, "*");
    });
  }

  async function run() {
    if (busy) return;
    setBusy(true);
    setStatus("正在读取页面…", "busy");
    try {
      setStatus("正在启动本地服务…", "busy");
      const ensured = await ensureServer();
      if (!ensured.ok) {
        throw new Error(`本地服务启动失败：${ensured.error}`);
      }

      const payload = await requestEvidence();
      const cookie = /bilibili\.com$/i.test(location.hostname)
        ? await getBilibiliCookie()
        : "";
      if (cookie) payload.cookie = cookie;

      setStatus("已读取页面，正在分析…", "busy");
      const { job_id: jobId } = await postJson("/api/ingest", payload);
      const result = await waitForJob(jobId);
      currentResult = result;
      askAnswer = null;
      askDraft = "";
      activeTab = "brief";
      render();
      setStatus(
        result.warnings && result.warnings.length
          ? `完成，${result.warnings.length} 条提示（见简报末尾）`
          : "完成",
        "ok"
      );
    } catch (error) {
      const message = String(error.message || error);
      if (message.includes("Failed to fetch") || message.includes("NetworkError")) {
        setStatus(
          "连接不上本地服务。请在项目目录运行 python -m rj.cli serve",
          "error"
        );
      } else {
        setStatus(message, "error");
      }
    } finally {
      setBusy(false);
    }
  }

  async function confirmRepo(candidate) {
    if (busy || !currentResult) return;
    setBusy(true);
    setStatus(`确认 ${candidate.full_name}，重新分析…`, "busy");
    try {
      const { job_id: jobId } = await postJson(
        `/api/projects/${encodeURIComponent(currentResult.video_id)}/confirm`,
        { full_name: candidate.full_name, host: candidate.host }
      );
      currentResult = await waitForJob(jobId);
      askAnswer = null;
      askDraft = "";
      activeTab = "brief";
      render();
      setStatus(
        currentResult.warnings && currentResult.warnings.length
          ? `完成，${currentResult.warnings.length} 条提示（见简报末尾）`
          : "完成",
        "ok"
      );
    } catch (error) {
      setStatus(String(error.message || error), "error");
    } finally {
      setBusy(false);
    }
  }

  async function askQuestion(question) {
    const value = String(question || "").trim();
    if (!value) {
      setStatus("请输入问题", "error");
      return;
    }
    if (asking || !currentResult) return;

    askDraft = value;
    asking = true;
    activeTab = "ask";
    setStatus("正在检索证据…", "busy");
    render();

    try {
      const response = await fetch(
        `${backend}/api/projects/${encodeURIComponent(currentResult.video_id)}/ask`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ question: value })
        }
      );
      let data = null;
      try {
        data = await response.json();
      } catch (error) {
        data = { error: `服务返回了非 JSON 内容 (HTTP ${response.status})` };
      }
      if (!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      askAnswer = data;
      setStatus(
        data.llm_used ? "回答完成（LLM）" : "回答完成（原文检索）",
        "ok"
      );
    } catch (error) {
      setStatus(String(error.message || error), "error");
    } finally {
      asking = false;
      render();
    }
  }

  function jumpTo(seconds) {
    const video = document.querySelector("video");
    if (!video) {
      setStatus("当前页面没有找到视频元素", "error");
      return;
    }
    try {
      video.currentTime = Math.max(0, Number(seconds) || 0);
      video.play().catch(() => {});
      flashStatus(`已跳转到 ${formatTime(seconds)}`, "ok");
    } catch (error) {
      setStatus("跳转失败", "error");
    }
  }

  /* ============================================================
     Clipboard
     ============================================================ */
  function currentTextForCopy() {
    if (!currentResult) return "";
    if (activeTab === "brief") return currentResult.brief_md || "";
    if (activeTab === "agent") return currentResult.agent_prompt_md || "";
    if (activeTab === "ask") return (askAnswer && askAnswer.answer) || "";
    if (activeTab === "candidates") {
      const candidates = Array.isArray(currentResult.candidates)
        ? currentResult.candidates
        : [];
      if (candidates.length) {
        return candidates
          .map((candidate) =>
            `${candidate.full_name || ""}\t${candidate.html_url || ""}\t${candidate.score || ""}`
          )
          .join("\n");
      }
      return currentResult.selected
        ? `${currentResult.selected.full_name}\t${currentResult.selected.html_url}`
        : "";
    }
    return "";
  }

  async function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      try {
        await navigator.clipboard.writeText(text);
        return;
      } catch (error) {
        // Fall through to the legacy path when permission is denied.
      }
    }

    const area = document.createElement("textarea");
    area.value = text;
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    const copied = document.execCommand("copy");
    area.remove();
    if (!copied) throw new Error("copy failed");
  }

  async function copyCurrentTab() {
    const text = currentTextForCopy();
    if (!text) {
      setStatus("当前标签没有可复制内容", "error");
      return;
    }
    try {
      await copyText(text);
      copyLabel.textContent = "已复制";
      clearTimeout(copyLabelTimer);
      copyLabelTimer = setTimeout(() => {
        copyLabel.textContent = "复制";
      }, 2000);
      flashStatus("已复制到剪贴板", "ok");
    } catch (error) {
      setStatus("复制失败，请手动选择", "error");
    }
  }

  /* ============================================================
     Events
     ============================================================ */
  fab.addEventListener("click", openPanel);
  closeButton.addEventListener("click", closePanel);
  backdrop.addEventListener("click", closePanel);
  runButton.addEventListener("click", run);
  copyButton.addEventListener("click", copyCurrentTab);

  layoutButton.addEventListener("click", () => {
    const next = panelLayout === "side" ? "center" : "side";
    applyLayout(next);
    flashStatus(
      next === "side" ? "已停靠到侧边，可继续操作页面" : "已居中显示",
      "ok"
    );
  });

  settingsButton.addEventListener("click", () => {
    const value = prompt("本地服务地址", backend);
    if (!value) return;
    backend = value.trim().replace(/\/+$/, "") || DEFAULT_BACKEND;
    chrome.storage.local.set({ rjBackend: backend });
    updateBackendLabel();
    flashStatus("已保存本地服务地址", "ok");
  });

  tabButtons.forEach((button, index) => {
    button.addEventListener("click", () => activateTab(button.dataset.tab));
    button.addEventListener("keydown", (event) => {
      if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return;
      event.preventDefault();
      let nextIndex = index;
      if (event.key === "ArrowLeft") nextIndex = (index - 1 + tabButtons.length) % tabButtons.length;
      if (event.key === "ArrowRight") nextIndex = (index + 1) % tabButtons.length;
      if (event.key === "Home") nextIndex = 0;
      if (event.key === "End") nextIndex = tabButtons.length - 1;
      activateTab(tabButtons[nextIndex].dataset.tab, true);
    });
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && panel.classList.contains("rj-open")) {
      closePanel();
    }
  });

  panel.addEventListener("keydown", (event) => {
    if (panelLayout !== "center" || event.key !== "Tab") return;
    const focusable = Array.from(
      panel.querySelectorAll(
        'button:not([disabled]), a[href], input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
      )
    ).filter((element) => element.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  window.addEventListener("resize", moveTabIndicator);

  chrome.storage.local.get(["rjBackend", "rjPanelLayout"], (data) => {
    if (data) {
      if (data.rjBackend) {
        backend = String(data.rjBackend).replace(/\/+$/, "");
      }
      if (data.rjPanelLayout) {
        applyLayout(data.rjPanelLayout, false);
      }
    }
    updateBackendLabel();
  });
  applyLayout("side", false);
  updateBackendLabel();
})();
