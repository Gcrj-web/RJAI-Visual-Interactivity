(() => {
  if (window.__RJ_MAIN_LOADED__) return;
  window.__RJ_MAIN_LOADED__ = true;

  const BILI_API = "https://api.bilibili.com";

  function isDouyin() {
    return (
      window.__RJ_FORCE_DOUYIN__ === true ||
      /(^|\.)douyin\.com$/i.test(location.hostname)
    );
  }

  function currentBvid() {
    const match = location.pathname.match(/\/video\/(BV[0-9A-Za-z]+)/);
    return match ? match[1] : "";
  }

  function currentDouyinId() {
    const match = location.pathname.match(/\/(?:video|note)\/(\d+)/);
    if (match) return match[1];
    const params = new URLSearchParams(location.search);
    const hashParams = new URLSearchParams(location.hash.replace(/^#/, ""));
    return (
      params.get("modal_id") ||
      params.get("aweme_id") ||
      params.get("vid") ||
      params.get("item_id") ||
      hashParams.get("modal_id") ||
      hashParams.get("aweme_id") ||
      ""
    );
  }

  async function getJson(url) {
    const response = await fetch(url, {
      credentials: "include",
      headers: { Accept: "application/json" }
    });
    if (!response.ok) throw new Error(`${url} -> HTTP ${response.status}`);
    return response.json();
  }

  function toComment(item, pinned) {
    const member = item && item.member ? item.member : {};
    const content = item && item.content ? item.content : {};
    return {
      author: member.uname || "",
      text: (content.message || "").trim(),
      likes: Number(item && item.like ? item.like : 0),
      pinned: Boolean(pinned)
    };
  }

  function pageText() {
    const nodes = document.querySelectorAll(
      ".video-desc, .desc-info-text, .tag-panel, .video-tag-container"
    );
    const parts = [];
    nodes.forEach((node) => {
      const text = (node.innerText || "").trim();
      if (text) parts.push(text);
    });
    return parts.join("\n").slice(0, 4000);
  }

  async function collectBilibili() {
    const bvid = currentBvid();
    if (!bvid) throw new Error("当前页面不是 B 站视频页");

    const warnings = [];
    const view = await getJson(`${BILI_API}/x/web-interface/view?bvid=${bvid}`);
    if (view.code !== 0 || !view.data) {
      throw new Error(view.message || `获取视频信息失败 (${view.code})`);
    }
    const data = view.data;

    let tags = [];
    try {
      const tagData = await getJson(`${BILI_API}/x/tag/archive/tags?bvid=${bvid}`);
      if (tagData.code === 0 && Array.isArray(tagData.data)) {
        tags = tagData.data.map((item) => item.tag_name).filter(Boolean);
      }
    } catch (error) {
      warnings.push(`标签获取失败：${error.message}`);
    }

    const comments = [];
    try {
      const reply = await getJson(
        `${BILI_API}/x/v2/reply?type=1&oid=${data.aid}&sort=2&ps=20&pn=1`
      );
      if (reply.code === 0 && reply.data) {
        const top = reply.data.top || {};
        for (const key of ["upper", "admin"]) {
          if (top[key]) comments.push(toComment(top[key], true));
        }
        for (const item of reply.data.replies || []) {
          comments.push(toComment(item, false));
          for (const sub of (item.replies || []).slice(0, 2)) {
            comments.push(toComment(sub, false));
          }
        }
      } else {
        warnings.push(`评论获取失败：${reply.message || reply.code}`);
      }
    } catch (error) {
      warnings.push(`评论获取失败：${error.message}`);
    }

    return {
      platform: "bilibili",
      video_id: data.bvid || bvid,
      url: `https://www.bilibili.com/video/${data.bvid || bvid}/`,
      title: data.title || document.title,
      description: data.desc || "",
      author: data.owner ? data.owner.name : "",
      author_id: String(data.owner ? data.owner.mid : ""),
      tags,
      duration: Number(data.duration || 0),
      pubdate: Number(data.pubdate || 0),
      aid: data.aid,
      cid: data.cid,
      chapters: [],
      subtitles: [],
      comments: comments.slice(0, 24),
      page_text: pageText(),
      warnings,
      fetched_at: new Date().toISOString()
    };
  }

  /* ============================================================
     Douyin page extraction
     ============================================================ */
  function metaContent(name) {
    const node = document.querySelector(
      `meta[property="${name}"], meta[name="${name}"]`
    );
    return node ? String(node.content || "").trim() : "";
  }

  function parseJsonText(text) {
    const raw = String(text || "").trim();
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch (error) {
      try {
        return JSON.parse(decodeURIComponent(raw));
      } catch (innerError) {
        return null;
      }
    }
  }

  function readDouyinRouterData() {
    for (const candidate of [
      window._ROUTER_DATA,
      window.__INITIAL_STATE__,
      window.__NEXT_DATA__
    ]) {
      if (typeof candidate === "string") {
        const parsed = parseJsonText(candidate);
        if (parsed) return parsed;
      } else if (candidate) {
        return candidate;
      }
    }

    for (const id of ["RENDER_DATA", "__NEXT_DATA__"]) {
      const node = document.getElementById(id);
      if (node) {
        const parsed = parseJsonText(node.textContent);
        if (parsed) return parsed;
      }
    }

    for (const node of document.querySelectorAll('script[type="application/json"]')) {
      const text = node.textContent || "";
      if (!text.includes("aweme")) continue;
      const parsed = parseJsonText(text);
      if (parsed) return parsed;
    }
    return null;
  }

  function findAwemeByPath(data, id) {
    if (!data || typeof data !== "object") return null;
    const loader = data.loaderData || data;
    for (const page of Object.values(loader)) {
      if (!page || typeof page !== "object") continue;
      const response =
        page.videoInfoRes ||
        page.noteInfoRes ||
        page.awemeInfoRes ||
        page.awemeDetail;
      const items = response && response.item_list;
      const item =
        (Array.isArray(items) && items[0]) ||
        (response && response.aweme_detail) ||
        page.aweme_detail ||
        page.aweme;
      if (!item || typeof item !== "object") continue;
      const itemId = item.aweme_id || item.awemeId || item.aweme_id_str;
      if (!id || (itemId && String(itemId) === String(id))) return item;
    }
    return null;
  }

  function findAwemeDeep(data, id) {
    if (!data || typeof data !== "object") return null;
    const target = String(id || "");
    const seen = new WeakSet();
    let visited = 0;

    function walk(node, depth) {
      if (!node || typeof node !== "object" || depth > 9) return null;
      if (visited > 20000) return null;
      if (seen.has(node)) return null;
      seen.add(node);
      visited += 1;

      if (Array.isArray(node)) {
        for (const item of node) {
          const found = walk(item, depth + 1);
          if (found) return found;
        }
        return null;
      }

      const itemId = node.aweme_id || node.awemeId || node.aweme_id_str;
      if (itemId && target && String(itemId) === target) return node;
      if (!target && itemId && (node.video || node.desc || node.author)) return node;

      for (const key of [
        "item_list",
        "aweme_list",
        "aweme_detail",
        "videoInfoRes",
        "noteInfoRes",
        "awemeInfoRes",
        "loaderData"
      ]) {
        if (node[key]) {
          const found = walk(node[key], depth + 1);
          if (found) return found;
        }
      }

      for (const value of Object.values(node)) {
        if (value && typeof value === "object") {
          const found = walk(value, depth + 1);
          if (found) return found;
        }
      }
      return null;
    }

    return walk(data, 0);
  }

  function isVisibleNode(node) {
    if (!node) return false;
    const rect = node.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return false;
    const style = getComputedStyle(node);
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity || 1) > 0
    );
  }

  function isActuallyVisible(node) {
    if (!isVisibleNode(node)) return false;
    const rect = node.getBoundingClientRect();
    if (
      rect.bottom < 0 ||
      rect.right < 0 ||
      rect.top > window.innerHeight ||
      rect.left > window.innerWidth
    ) {
      return false;
    }
    const x = Math.min(
      window.innerWidth - 1,
      Math.max(0, rect.left + rect.width / 2)
    );
    const y = Math.min(
      window.innerHeight - 1,
      Math.max(0, rect.top + rect.height / 2)
    );
    const top = document.elementFromPoint(x, y);
    return !top || top === node || node.contains(top) || top.contains(node);
  }

  function findActiveVideo() {
    let active = null;
    let bestScore = -1;
    document.querySelectorAll("video").forEach((video) => {
      if (!isVisibleNode(video)) return;
      const rect = video.getBoundingClientRect();
      const playing = !video.paused && !video.ended && video.readyState >= 2;
      const score =
        (playing ? 1e9 : 0) +
        Math.min(rect.width * rect.height, 5e7) +
        (video.currentSrc ? 1e7 : 0) +
        (video.readyState >= 2 ? 1e6 : 0);
      if (score > bestScore) {
        active = video;
        bestScore = score;
      }
    });
    return active;
  }

  function findDomAwemeId(video) {
    let node = video;
    for (let depth = 0; node && depth < 10; depth += 1, node = node.parentElement) {
      const ownId =
        (node.getAttribute &&
          (node.getAttribute("data-aweme-id") ||
            node.getAttribute("data-item-id"))) ||
        "";
      if (/^\d{8,}$/.test(ownId)) return ownId;
      const link = node.querySelector && node.querySelector('a[href*="/video/"]');
      if (link) {
        const match = String(link.href || "").match(/\/video\/(\d+)/);
        if (match) return match[1];
      }
    }
    return "";
  }

  function nearestVisibleText(selectors, video) {
    const origin = video ? video.getBoundingClientRect() : null;
    let best = "";
    let bestScore = Number.POSITIVE_INFINITY;
    for (const selector of selectors) {
      document.querySelectorAll(selector).forEach((node) => {
        if (!isActuallyVisible(node)) return;
        const text = (node.innerText || "").trim();
        if (!text) return;
        const rect = node.getBoundingClientRect();
        let score = 0;
        if (origin) {
          const dx = Math.max(
            0,
            Math.max(origin.left - rect.right, rect.left - origin.right)
          );
          const dy = Math.max(
            0,
            Math.max(origin.top - rect.bottom, rect.top - origin.bottom)
          );
          score = dx + dy + Math.abs(rect.width - origin.width) * 0.1;
        } else {
          score = Math.abs(rect.top);
        }
        if (score < bestScore) {
          bestScore = score;
          best = text;
        }
      });
    }
    return best;
  }

  function nearestTextInScope(video, selectors) {
    let scope = video;
    for (let depth = 0; scope && depth < 10; depth += 1, scope = scope.parentElement) {
      if (scope === document.body) break;
      const rect = scope.getBoundingClientRect();
      if (rect.width < 300 || rect.height < 300) continue;
      for (const selector of selectors) {
        for (const node of scope.querySelectorAll(selector)) {
          if (!isVisibleNode(node)) continue;
          const text = (node.innerText || "").trim();
          if (text) return text;
        }
      }
    }
    return "";
  }

  function mediaUrlKeys(url) {
    const keys = new Set();
    const raw = String(url || "").trim();
    if (!raw) return keys;
    keys.add(raw);
    try {
      const parsed = new URL(raw);
      const videoId = parsed.searchParams.get("video_id");
      if (videoId) keys.add("vid:" + videoId);
      const tail = parsed.pathname.split("/").filter(Boolean).pop();
      if (tail) keys.add("tail:" + tail);
    } catch (error) {
      // blob: 或签名异常时只保留原始 URL。
    }
    return keys;
  }

  function findAwemeByMediaUrl(data, mediaUrl) {
    const target = mediaUrlKeys(mediaUrl);
    if (!data || typeof data !== "object" || !target.size) return null;
    const seen = new WeakSet();
    let visited = 0;

    function walk(node, depth) {
      if (!node || typeof node !== "object" || depth > 10) return null;
      if (visited > 30000 || seen.has(node)) return null;
      seen.add(node);
      visited += 1;

      if (Array.isArray(node)) {
        for (const item of node) {
          const found = walk(item, depth + 1);
          if (found) return found;
        }
        return null;
      }

      const video = node.video;
      if (video && typeof video === "object") {
        for (const key of [
          "play_addr",
          "play_addr_h264",
          "play_addr_265",
          "download_addr"
        ]) {
          const address = video[key];
          const list =
            (address && address.url_list) ||
            (address && address.url ? [address.url] : []);
          for (const url of Array.isArray(list) ? list : []) {
            const keys = mediaUrlKeys(url);
            for (const key of target) {
              if (keys.has(key)) return node;
            }
          }
        }
      }

      for (const key of [
        "item_list",
        "aweme_list",
        "aweme_detail",
        "videoInfoRes",
        "noteInfoRes",
        "awemeInfoRes",
        "loaderData"
      ]) {
        if (node[key]) {
          const found = walk(node[key], depth + 1);
          if (found) return found;
        }
      }
      for (const value of Object.values(node)) {
        if (value && typeof value === "object") {
          const found = walk(value, depth + 1);
          if (found) return found;
        }
      }
      return null;
    }

    return walk(data, 0);
  }

  function douyinTags(item, description) {
    const tags = [];
    for (const entry of (item && item.text_extra) || []) {
      const name = entry && (entry.hashtag_name || entry.hashtagName);
      if (name) tags.push(String(name));
    }
    for (const entry of (item && item.cha_list) || []) {
      const name = entry && (entry.cha_name || entry.cname || entry.name);
      if (name) tags.push(String(name));
    }
    for (const match of String(description || "").match(/#[^\s#]+/g) || []) {
      tags.push(match.replace(/^#/, ""));
    }

    const seen = new Set();
    const unique = [];
    for (const tag of tags) {
      const value = String(tag || "").trim();
      if (!value || seen.has(value)) continue;
      seen.add(value);
      unique.push(value);
      if (unique.length >= 20) break;
    }
    return unique;
  }

  function douyinMediaUrl(item, activeVideo) {
    const video = (item && item.video) || {};
    const urls = [];
    for (const key of [
      "play_addr",
      "play_addr_h264",
      "play_addr_265",
      "download_addr"
    ]) {
      const address = video[key];
      if (!address) continue;
      const list = address.url_list || (address.url ? [address.url] : []);
      for (const url of Array.isArray(list) ? list : []) {
        if (/^https?:\/\//i.test(url)) urls.push(url);
      }
    }
    if (!urls.length && activeVideo) {
      const source = activeVideo.currentSrc || activeVideo.src || "";
      if (/^https?:\/\//i.test(source)) urls.push(source);
    }
    if (!urls.length) {
      const ogVideo = metaContent("og:video");
      if (/^https?:\/\//i.test(ogVideo)) urls.push(ogVideo);
    }
    return urls[0] || "";
  }

  function douyinComments(item) {
    const source =
      (item && (item.comment_list || item.comments || item.commentList)) || [];
    if (!Array.isArray(source)) return [];
    const seen = new Set();
    const comments = [];
    for (const entry of source) {
      if (!entry || typeof entry !== "object") continue;
      const user = entry.user || entry.author || {};
      const text = String(entry.text || entry.content || entry.comment || "").trim();
      if (!text || seen.has(text)) continue;
      seen.add(text);
      comments.push({
        author: String(user.nickname || user.name || entry.user_name || ""),
        text,
        likes: Number(entry.digg_count || entry.like_count || entry.likes || 0),
        pinned: Boolean(entry.pinned)
      });
    }
    return comments.slice(0, 24);
  }

  function douyinPageText(description, tags, author) {
    const parts = [description];
    if (tags.length) parts.push(tags.map((tag) => `#${tag}`).join(" "));
    if (author) parts.push(author);
    return parts.filter(Boolean).join("\n").slice(0, 4000);
  }

  function currentDouyinUrl(id) {
    if (id) {
      const kind = location.pathname.includes("/note/") ? "note" : "video";
      return `https://www.douyin.com/${kind}/${id}`;
    }
    return location.href.split("?")[0];
  }

  function collectDouyin() {
    const warnings = [];
    const id = currentDouyinId();
    const activeVideo = findActiveVideo();
    const activeSource = activeVideo
      ? activeVideo.currentSrc || activeVideo.src || ""
      : "";
    const data = readDouyinRouterData();
    const isProfilePage = location.pathname.startsWith("/user/");
    const isVideoPage = /^\/(video|note)\//.test(location.pathname);
    const item = data
      ? (id ? findAwemeByPath(data, id) : null) ||
        findAwemeByMediaUrl(data, activeSource) ||
        (id ? findAwemeDeep(data, id) : null)
      : null;

    if (!data) {
      warnings.push("没有读取到抖音页面数据，已从播放器附近的文字提取。");
    } else if (!item) {
      warnings.push("没有从抖音页面数据中解析到当前视频，已从播放器附近的文字提取。");
    }

    if (!item && !activeVideo) {
      throw new Error(
        "没有检测到正在播放的抖音视频。请先点开视频，等画面加载后再点 RJ。"
      );
    }

    const descSelectors = [
      '[data-e2e="detail-video-desc"]',
      '[data-e2e="video-desc"]',
      '[data-e2e="video-title"]',
      '[data-e2e="video-caption"]',
      '[data-e2e="desc"]',
      '[data-e2e="aweme-desc"]'
    ];
    const authorSelectors = [
      '[data-e2e="video-author-name"]',
      '[data-e2e="user-name"]',
      '[data-e2e="author-name"]',
      '[data-e2e="video-user-name"]'
    ];
    const activeDescription =
      nearestVisibleText(descSelectors, activeVideo) ||
      nearestTextInScope(activeVideo, descSelectors);
    const activeAuthor =
      nearestVisibleText(authorSelectors, activeVideo) ||
      nearestTextInScope(activeVideo, authorSelectors);

    const description = String(
      (item && item.desc) ||
        activeDescription ||
        (isVideoPage
          ? metaContent("og:description") || metaContent("description")
          : "") ||
        ""
    ).trim();
    const rawTitle =
      (item && item.desc) ||
      activeDescription ||
      (isVideoPage ? metaContent("og:title") : "") ||
      (!isProfilePage ? document.title : "") ||
      description;
    const title = String(rawTitle)
      .replace(/\s*-\s*抖音\s*$/i, "")
      .split("\n")[0]
      .trim();
    const tags = douyinTags(item, description);
    const author = String(
      (item && item.author && (item.author.nickname || item.author.name)) ||
        activeAuthor ||
        (isVideoPage
          ? metaContent("author") || metaContent("og:article:author")
          : "") ||
        ""
    ).trim();
    const authorId = String(
      (item && item.author && (item.author.sec_uid || item.author.uid)) || ""
    );

    let duration = Number((item && item.video && item.video.duration) || 0);
    if (duration > 1000) duration /= 1000;
    if (!duration && activeVideo) {
      duration = Number(activeVideo.duration || 0);
    }

    const comments = douyinComments(item);
    const mediaUrl = douyinMediaUrl(item, activeVideo);
    const itemId = item && (item.aweme_id || item.awemeId || item.aweme_id_str);
    const resolvedId = id || itemId || findDomAwemeId(activeVideo) || "";
    if (!resolvedId) {
      warnings.push(
        "没有识别到当前视频 ID，项目会使用临时名称；建议刷新页面后重试。"
      );
    }
    if (isProfilePage && !description) {
      warnings.push(
        "当前视频文案没有解析出来；请确认视频已经完整打开，必要时滚动评论区后再重试。"
      );
    }
    if (!comments.length) {
      warnings.push(
        "抖音评论区需要登录态和签名接口，当前未抓取评论；简报只使用标题、简介、标签和可用的语音转写。"
      );
    }
    if (!mediaUrl && /^blob:/i.test(activeSource)) {
      warnings.push(
        "抖音播放器使用 blob 地址，无法直接下载媒体；本次未做语音识别。"
      );
    }
    if (location.pathname.includes("/note/")) {
      warnings.push("这是抖音图文作品，通常没有可转写的视频音轨。");
    }

    const fallbackId = resolvedId || `douyin-${Date.now()}`;
    const finalTitle =
      title || (resolvedId ? `抖音视频 ${resolvedId}` : "抖音视频");

    return {
      platform: "douyin",
      video_id: String(fallbackId),
      url: currentDouyinUrl(resolvedId),
      title: finalTitle,
      description,
      author: String(author),
      author_id: String(authorId),
      tags,
      duration,
      pubdate: Number((item && item.create_time) || 0),
      aid: 0,
      cid: 0,
      chapters: [],
      subtitles: [],
      comments,
      page_text: douyinPageText(description, tags, author),
      media_url: mediaUrl,
      warnings,
      fetched_at: new Date().toISOString()
    };
  }

  async function collect() {
    return isDouyin() ? collectDouyin() : collectBilibili();
  }

  if (window.__RJ_FORCE_DOUYIN__ === true) {
    window.__RJ_COLLECT_DEBUG__ = collect;
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== "rj-page" || data.type !== "RJ_COLLECT") return;
    collect()
      .then((payload) => {
        window.postMessage({ source: "rj-main", type: "RJ_PAGE_DATA", payload }, "*");
      })
      .catch((error) => {
        window.postMessage(
          { source: "rj-main", type: "RJ_PAGE_ERROR", error: String(error.message || error) },
          "*"
        );
      });
  });
})();
