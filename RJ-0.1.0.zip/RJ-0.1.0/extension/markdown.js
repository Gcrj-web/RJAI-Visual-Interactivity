(() => {
  "use strict";

  /**
   * Small, dependency-free Markdown renderer for the RJ panel.
   * It intentionally supports only the constructs used by RJ briefs:
   * headings, tables, blockquotes, lists, fenced code, inline code,
   * links, bold text and evidence badges.
   */
  const escapeHtml = (value) =>
    String(value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[character]));

  const badgeClass = (label) => ({
    "确认": "rj-badge-ok",
    "推断": "rj-badge-infer",
    "未知": "rj-badge-unknown",
    "待核实": "rj-badge-pending"
  }[label] || "rj-badge-unknown");

  function renderInline(value) {
    const codeSpans = [];
    const links = [];
    let text = escapeHtml(value);

    // Extract code spans first so their contents are never parsed as markup.
    text = text.replace(/`([^`]+)`/g, (_, code) => {
      codeSpans.push(code);
      return `\u0000${codeSpans.length - 1}\u0000`;
    });

    text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, (_, label, url) => {
      links.push(`<a href="${url}" target="_blank" rel="noreferrer">${label}</a>`);
      return `\u0001${links.length - 1}\u0001`;
    });

    text = text.replace(/(^|[\s（(])(https?:\/\/[^\s<）)]+)/g, (_, prefix, url) => {
      links.push(`<a href="${url}" target="_blank" rel="noreferrer">${url}</a>`);
      return `${prefix}\u0001${links.length - 1}\u0001`;
    });

    text = text.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    text = text.replace(/__([^_]+)__/g, "<strong>$1</strong>");
    text = text.replace(/\[(确认|推断|未知|待核实)\]/g, (_, label) =>
      `<span class="rj-badge ${badgeClass(label)}">${label}</span>`
    );

    text = text.replace(/\u0001(\d+)\u0001/g, (_, index) => links[Number(index)]);
    text = text.replace(/\u0000(\d+)\u0000/g, (_, index) => `<code>${codeSpans[Number(index)]}</code>`);
    return text;
  }

  function isTableSeparator(line) {
    if (!line || !line.includes("|")) return false;
    const cells = line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|");
    return cells.length > 0 && cells.every((cell) => /^\s*:?-{3,}:?\s*$/.test(cell));
  }

  function splitTableRow(line) {
    return line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((cell) => cell.trim());
  }

  function isBlockStart(line, nextLine) {
    return (
      /^```/.test(line) ||
      /^#{1,4}\s+/.test(line) ||
      /^\s*>/.test(line) ||
      /^\s*[-*+]\s+/.test(line) ||
      /^\s*\d+[.)]\s+/.test(line) ||
      /^\s*(?:---+|\*\*\*+|___+)\s*$/.test(line) ||
      (line.includes("|") && isTableSeparator(nextLine || ""))
    );
  }

  function render(source) {
    const lines = String(source || "").replace(/\r\n?/g, "\n").split("\n");
    const output = [];
    let index = 0;

    while (index < lines.length) {
      const line = lines[index];

      if (!line.trim()) {
        index += 1;
        continue;
      }

      if (/^```/.test(line)) {
        const code = [];
        index += 1;
        while (index < lines.length && !/^```/.test(lines[index])) {
          code.push(lines[index]);
          index += 1;
        }
        index += 1;
        output.push(`<pre><code>${escapeHtml(code.join("\n"))}</code></pre>`);
        continue;
      }

      const heading = line.match(/^(#{1,4})\s+(.+?)\s*#*$/);
      if (heading) {
        const level = heading[1].length;
        output.push(`<h${level}>${renderInline(heading[2])}</h${level}>`);
        index += 1;
        continue;
      }

      if (/^\s*(?:---+|\*\*\*+|___+)\s*$/.test(line)) {
        output.push("<hr>");
        index += 1;
        continue;
      }

      if (line.includes("|") && isTableSeparator(lines[index + 1] || "")) {
        const headers = splitTableRow(line);
        const aligns = splitTableRow(lines[index + 1]).map((cell) => {
          if (/^:-+:$/.test(cell)) return "center";
          if (/^-+:$/.test(cell)) return "right";
          return "left";
        });
        const rows = [];
        index += 2;
        while (index < lines.length && lines[index].trim() && lines[index].includes("|")) {
          rows.push(splitTableRow(lines[index]));
          index += 1;
        }
        const head = headers.map((cell, column) =>
          `<th style="text-align:${aligns[column] || "left"}">${renderInline(cell)}</th>`
        ).join("");
        const body = rows.map((row) =>
          `<tr>${headers.map((_, column) =>
            `<td style="text-align:${aligns[column] || "left"}">${renderInline(row[column] || "")}</td>`
          ).join("")}</tr>`
        ).join("");
        output.push(
          `<div class="rj-table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`
        );
        continue;
      }

      if (/^\s*>/.test(line)) {
        const quote = [];
        while (index < lines.length && /^\s*>/.test(lines[index])) {
          quote.push(lines[index].replace(/^\s*>\s?/, ""));
          index += 1;
        }
        output.push(`<blockquote><p>${quote.map(renderInline).join("<br>")}</p></blockquote>`);
        continue;
      }

      if (/^\s*[-*+]\s+/.test(line)) {
        const items = [];
        while (index < lines.length && /^\s*[-*+]\s+/.test(lines[index])) {
          items.push(lines[index].replace(/^\s*[-*+]\s+/, ""));
          index += 1;
        }
        output.push(`<ul>${items.map((item) => `<li>${renderInline(item)}</li>`).join("")}</ul>`);
        continue;
      }

      if (/^\s*\d+[.)]\s+/.test(line)) {
        const items = [];
        while (index < lines.length && /^\s*\d+[.)]\s+/.test(lines[index])) {
          items.push(lines[index].replace(/^\s*\d+[.)]\s+/, ""));
          index += 1;
        }
        output.push(`<ol>${items.map((item) => `<li>${renderInline(item)}</li>`).join("")}</ol>`);
        continue;
      }

      const paragraph = [];
      while (
        index < lines.length &&
        lines[index].trim() &&
        !isBlockStart(lines[index], lines[index + 1])
      ) {
        paragraph.push(lines[index].trim());
        index += 1;
      }
      output.push(`<p>${renderInline(paragraph.join(" "))}</p>`);
    }

    return output.join("\n");
  }

  window.RJMarkdown = { render, escapeHtml };
})();
