from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .analyze import analyze_video
from .bilibili import (
    BilibiliClient,
    BilibiliError,
    evidence_from_payload,
    hydrate_evidence,
    load_cookie,
)
from .models import RepoCandidate, format_seconds
from .qa import answer_project_question
from .store import ProjectStore


def _candidate_from_dict(data: dict) -> RepoCandidate:
    allowed = set(RepoCandidate.__dataclass_fields__.keys())
    return RepoCandidate(**{key: value for key, value in data.items() if key in allowed})


def _print_result(result, directory: Path) -> None:
    print("")
    print(f"标题：{result.video.title}")
    kind_labels = {
        "software_project": "软件项目",
        "software_usage": "软件使用/安装教程",
        "hardware_tutorial": "硬件维修/拆机教程",
        "hardware_software_mixed": "硬件 + 软件混合教程",
        "media_content": "动漫/影视内容",
        "game_guide": "游戏攻略/抽卡规划",
        "game_review": "游戏测评/排行",
        "hardware_topic": "硬件资讯/评测",
        "science_content": "科普/健康",
        "general": "通用内容",
    }
    print(f"类型：{kind_labels.get(result.kind, result.kind)}")
    if result.selected:
        print(f"仓库：{result.selected.full_name}（匹配分 {result.selected.score}）")
        print(f"链接：{result.selected.html_url}")
    else:
        print("仓库：未定位")
    print(f"LLM：{'已使用' if result.llm_used else '未使用'}")
    print(f"简报：{directory / 'brief.md'}")
    print(f"任务包：{directory / 'agent_prompt.md'}")
    if result.warnings:
        print("")
        print("提示：")
        for warning in result.warnings:
            print(f"  - {warning}")


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except (AttributeError, ValueError):
            pass
    parser = argparse.ArgumentParser(prog="rj", description="把技术视频变成可执行的复刻简报")
    sub = parser.add_subparsers(dest="command", required=True)

    serve_p = sub.add_parser("serve", help="启动本地服务，供浏览器扩展调用")
    serve_p.add_argument("--port", type=int, default=8765)

    fetch_p = sub.add_parser("fetch", help="直接从 B 站抓取并分析")
    fetch_p.add_argument("bvid")
    fetch_p.add_argument("--no-comments", action="store_true")

    subs_p = sub.add_parser("subs", help="检查某个视频能否取到字幕")
    subs_p.add_argument("bvid")

    asr_p = sub.add_parser("asr", help="对视频做本地语音识别并缓存")
    asr_p.add_argument("bvid")
    asr_p.add_argument("--model", default="", help="覆盖 RJ_ASR_MODEL，例如 small/base/medium")

    analyze_p = sub.add_parser("analyze", help="分析扩展导出的 JSON")
    analyze_p.add_argument("payload")

    demo_p = sub.add_parser("demo", help="用离线样例跑通全流程")
    demo_p.add_argument("--payload", default="samples/sample_payload.json")

    sub.add_parser("list", help="列出已分析的项目")

    show_p = sub.add_parser("show", help="打印某个项目的简报")
    show_p.add_argument("video_id")

    ask_p = sub.add_parser("ask", help="对已分析项目追问")
    ask_p.add_argument("video_id")
    ask_p.add_argument("question")

    vision_p = sub.add_parser("vision", help="检查或测试视觉模型配置")
    vision_p.add_argument("--image", default="", help="可选：用一张本地图片测试模型")
    vision_p.add_argument("--title", default="测试图片")

    args = parser.parse_args(argv)

    if args.command == "serve":
        from .server import serve

        serve(args.port)
        return 0

    store = ProjectStore()
    if args.command == "subs":
        client = BilibiliClient(cookie=load_cookie())
        try:
            view = client.get_view(args.bvid)
            subtitles = client.get_subtitles(
                int(view["aid"]),
                int(view["cid"]),
                view["bvid"],
            )
        except (BilibiliError, KeyError, ValueError) as exc:
            print(f"检查失败：{exc}")
            return 1
        print(f"视频：{view.get('title')}")
        print(f"字幕段落：{len(subtitles)}")
        if subtitles:
            for seg in subtitles[:8]:
                print(f"[{format_seconds(seg.start)}] {seg.text}")
        else:
            print(
                "没有取到字幕。检查：视频是否有字幕、AI 字幕是否已生成、"
                "data/bilibili_cookie.txt 是否包含 SESSDATA。"
            )
            print(f"可以尝试本地转写：python -m rj.cli asr {args.bvid}")
        return 0

    if args.command == "fetch":
        client = BilibiliClient(cookie=load_cookie())
        video = client.fetch_evidence(args.bvid, include_comments=not args.no_comments)
        video = hydrate_evidence(
            video,
            video.to_dict(),
            progress=lambda step: print(f"  · {step}"),
        )
        from .vision import enrich_video_vision

        video = enrich_video_vision(
            video,
            video.to_dict(),
            progress=lambda step: print(f"  · {step}"),
        )
        result = analyze_video(video, progress=lambda step: print(f"  · {step}"))
        directory = store.save(result, video.to_dict())
        _print_result(result, directory)
        return 0

    if args.command == "analyze":
        payload_path = Path(args.payload)
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
        video = evidence_from_payload(payload)
        video = hydrate_evidence(
            video,
            payload,
            progress=lambda step: print(f"  · {step}"),
        )
        from .vision import enrich_video_vision

        video = enrich_video_vision(
            video,
            payload,
            progress=lambda step: print(f"  · {step}"),
        )
        result = analyze_video(video, progress=lambda step: print(f"  · {step}"))
        directory = store.save(result, payload)
        _print_result(result, directory)
        return 0

    if args.command == "asr":
        from .asr import ASRConfig, transcribe_bilibili

        client = BilibiliClient(cookie=load_cookie())
        try:
            view = client.get_view(args.bvid)
            config = ASRConfig.from_env()
            if args.model:
                config.model = args.model
            print(
                f"  · 模型：{config.model}，设备：{config.device}，"
                f"语言：{config.language or 'auto'}"
            )
            chapters = client.get_chapters(
                int(view["aid"]), int(view["cid"]), view["bvid"]
            )
            segments = transcribe_bilibili(
                view["bvid"],
                int(view["aid"]),
                int(view["cid"]),
                config=config,
                progress=lambda step: print(f"  · {step}"),
                client=client,
                hints={
                    "title": view.get("title") or "",
                    "description": view.get("desc") or "",
                    "chapters": [chapter.title for chapter in chapters],
                },
            )
        except Exception as exc:
            print(f"ASR 失败：{exc}")
            return 1
        print(f"识别段落：{len(segments)}")
        for seg in segments[:8]:
            print(f"[{format_seconds(seg.start)}] {seg.text}")
        return 0

    if args.command == "demo":
        payload_path = Path(args.payload)
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
        video = evidence_from_payload(payload)
        mock = [_candidate_from_dict(item) for item in payload.get("mock_candidates") or []]
        result = analyze_video(
            video,
            offline=True,
            mock_candidates=mock,
            progress=lambda step: print(f"  · {step}"),
        )
        directory = store.save(result, payload)
        _print_result(result, directory)
        return 0

    if args.command == "list":
        entries = store.list()
        if not entries:
            print("还没有分析过项目。先运行 `python -m rj.cli demo`。")
            return 0
        for entry in entries:
            print(
                f"{entry.get('video_id', '')}  "
                f"{entry.get('selected_repo') or '未定位'}  "
                f"{entry.get('title', '')}"
            )
        return 0

    if args.command == "show":
        text = store.read_brief(args.video_id)
        if not text:
            print(f"没有找到 {args.video_id} 的简报。")
            return 1
        print(text)
        return 0

    if args.command == "ask":
        try:
            result = answer_project_question(store, args.video_id, args.question)
        except Exception as exc:
            print(f"提问失败：{exc}")
            return 1
        print(result["answer"])
        if result.get("sources"):
            print("")
            print("来源：")
            for source in result["sources"]:
                prefix = ""
                if source.get("start") is not None:
                    prefix = f"[{format_seconds(source['start'])}] "
                print(f"- {prefix}{source['label']}：{source['text'][:180]}")
        return 0

    if args.command == "vision":
        from .vision import VisionClient, VisionConfig

        config = VisionConfig.from_env()
        print(json.dumps(config.describe(), ensure_ascii=False, indent=2))
        if not args.image:
            return 0
        try:
            from PIL import Image
            from .frames import ExtractedFrame

            path = Path(args.image)
            with Image.open(path) as image:
                width, height = image.size
            result = VisionClient(config).analyze(
                [ExtractedFrame(0, path, width, height)],
                {
                    "platform": "local",
                    "title": args.title,
                    "description": "",
                    "tags": [],
                    "duration": 0,
                },
            )
        except Exception as exc:
            print(f"视觉测试失败：{exc}")
            return 1
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
