from __future__ import annotations

import os
from typing import Any

import requests


class LLMError(RuntimeError):
    pass


class LLMClient:
    """最小化的 OpenAI-compatible Chat Completions 客户端。"""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
    ):
        self.base_url = (
            base_url
            or os.environ.get("RJ_LLM_BASE_URL", "")
            or "https://api.deepseek.com/v1"
        ).rstrip("/")
        self.api_key = (
            api_key if api_key is not None else os.environ.get("RJ_LLM_API_KEY", "")
        ).strip()
        self.model = model or os.environ.get("RJ_LLM_MODEL", "deepseek-chat")
        self.timeout = int(timeout or os.environ.get("RJ_LLM_TIMEOUT", "150"))

    def available(self) -> bool:
        return bool(self.api_key)

    def describe(self) -> dict[str, Any]:
        return {
            "available": self.available(),
            "base_url": self.base_url,
            "model": self.model,
        }

    def complete(
        self,
        system: str,
        user: str,
        temperature: float = 0.2,
        max_tokens: int = 4200,
    ) -> str:
        if not self.available():
            raise LLMError("未配置 RJ_LLM_API_KEY。")
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise LLMError(f"模型请求失败：{exc}") from exc
        if response.status_code >= 400:
            raise LLMError(f"模型返回 HTTP {response.status_code}：{response.text[:300]}")
        try:
            data = response.json()
            content = data["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise LLMError("模型返回格式不符合预期。") from exc
        if not isinstance(content, str) or not content.strip():
            raise LLMError("模型返回了空内容。")
        return content.strip()
