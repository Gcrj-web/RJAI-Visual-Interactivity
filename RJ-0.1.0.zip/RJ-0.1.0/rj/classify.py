from __future__ import annotations

from dataclasses import dataclass, field

from .models import ExtractedSignals, VideoEvidence


@dataclass
class VideoClassification:
    kind: str
    hardware_score: int = 0
    software_score: int = 0
    usage_score: int = 0
    development_score: int = 0
    media_score: int = 0
    game_score: int = 0
    repair_score: int = 0
    review_score: int = 0
    science_score: int = 0
    hardware_hits: list[str] = field(default_factory=list)
    software_hits: list[str] = field(default_factory=list)
    usage_hits: list[str] = field(default_factory=list)
    development_hits: list[str] = field(default_factory=list)
    media_hits: list[str] = field(default_factory=list)
    game_hits: list[str] = field(default_factory=list)
    repair_hits: list[str] = field(default_factory=list)
    review_hits: list[str] = field(default_factory=list)
    science_hits: list[str] = field(default_factory=list)

    @property
    def label(self) -> str:
        return {
            "software_project": "软件项目",
            "software_usage": "软件使用/安装教程",
            "hardware_tutorial": "硬件维修/拆机教程",
            "hardware_software_mixed": "硬件 + 软件混合教程",
            "media_content": "动漫/影视内容",
            "game_guide": "游戏攻略/游戏内容",
            "game_review": "游戏测评/排行",
            "hardware_topic": "硬件资讯/评测",
            "science_content": "科普/健康",
            "general": "通用内容",
        }.get(self.kind, self.kind)


# 权重只用来做“视频类型路由”，不参与仓库匹配打分。
HARDWARE_TERMS = {
    "拆机": 4, "拆解": 3, "清灰": 4, "除尘": 3, "换硅脂": 5, "硅脂": 3,
    "相变片": 5, "相变": 3, "导热垫": 3, "散热": 2, "风扇": 2, "热管": 2,
    "均热板": 4, "主板": 2, "电池": 2, "排线": 3, "螺丝": 2, "镊子": 2,
    "撬棒": 2, "撬片": 2, "吸盘": 2, "防静电": 2, "装机": 2, "维修": 2,
    "笔记本": 1, "拯救者": 2, "r9000p": 3, "y9000p": 3, "天选": 2,
    "暗影精灵": 2, "macbook": 2, "iphone": 2, "换屏": 4, "换电池": 4,
    "换键盘": 3, "卡扣": 2, "转轴": 2, "尾插": 3, "充电口": 2,
    "拆焊": 3, "热风枪": 2, "电烙铁": 2, "测温": 1, "功耗": 1,
    "esp32": 4, "stm32": 4, "arduino": 4, "树莓派": 4, "raspberry": 4,
    "开发板": 3, "烧录": 4, "固件": 3, "接线": 4, "引脚": 3, "gpio": 3,
    "传感器": 3, "舵机": 4, "电机": 3, "驱动板": 3, "锂电池": 3,
    "万用表": 3, "示波器": 3, "焊台": 3, "3d打印": 4, "结构件": 2,
    "亚克力": 2, "螺丝孔": 2, "电池组": 3, "遥控": 2, "无人机": 3,
    "机器人": 2, "机械臂": 4, "小车": 2,
}

# 只有出现明确的拆装/维修动作，才把它当成“维修教程”；
# 评测和价格讨论里也会大量出现“笔记本、散热、电池”。
REPAIR_TERMS = {
    "拆机": 4, "拆解": 3, "清灰": 4, "除尘": 3, "换硅脂": 5, "硅脂": 2,
    "相变片": 5, "相变": 2, "导热垫": 3, "主板": 2, "排线": 3,
    "螺丝": 2, "镊子": 2, "撬棒": 2, "撬片": 2, "吸盘": 2,
    "防静电": 2, "装机": 2, "维修": 2, "换屏": 4, "换电池": 4,
    "换键盘": 3, "卡扣": 2, "转轴": 2, "尾插": 3, "充电口": 2,
    "拆焊": 3, "热风枪": 2, "电烙铁": 2, "均热板": 4,
    "风扇": 1, "散热": 1, "电池": 1,
    "接线": 3, "烧录": 4, "固件": 2, "引脚": 3, "gpio": 3,
    "舵机": 3, "电机": 2, "传感器": 2, "开发板": 2,
    "万用表": 3, "示波器": 3, "焊台": 3, "3d打印": 4,
    "结构件": 2, "亚克力": 2, "螺丝孔": 2, "电池组": 3,
    "机械臂": 4, "小车": 2,
}

SOFTWARE_TERMS = {
    "开源": 3, "源码": 4, "代码": 2, "编程": 3, "仓库": 3, "github": 5,
    "gitee": 5, "部署": 2, "框架": 2, "api": 2, "python": 3,
    "javascript": 3, "typescript": 3, "react": 2, "vue": 2, "docker": 2,
    "数据库": 2, "算法": 2, "后端": 2, "前端": 2, "插件": 2, "爬虫": 3,
    "脚本": 2, "命令行": 2, "sdk": 2, "接口": 1, "项目": 1, "模型": 1,
    "prompt": 2, "llm": 2, "agent": 2, "mcp": 3, "编译": 2, "调试": 1,
    "git": 2, "语音助手": 3, "本地部署": 2,
    "软件": 2, "app": 2, "安卓": 2, "android": 2, "apk": 2, "ios": 2,
}

USAGE_TERMS = {
    "下载": 3, "安装": 3, "导入": 3, "书源": 4, "小白": 2, "零基础": 2,
    "新手": 2, "使用教程": 3, "点击": 1, "打开": 1, "搜索": 1,
    "软件": 2, "教程": 1, "app": 2, "手机": 2, "安卓": 2, "android": 2,
    "安装包": 3, "apk": 3, "注册": 1, "登录": 1, "设置": 2, "更新": 1,
    "版本": 1, "下载地址": 3, "网盘": 2, "书源导入": 4, "使用说明": 2,
    "步骤": 1, "方法": 1,
}

DEVELOPMENT_TERMS = {
    "源码": 5, "编译": 5, "构建": 4, "开发": 4, "部署": 4, "环境": 3,
    "依赖": 3, "sdk": 3, "架构": 3, "从零实现": 6, "手写": 3, "克隆": 4,
    "运行": 2, "调试": 3, "接口": 2, "框架": 3, "docker": 3, "数据库": 3,
    "后端": 3, "前端": 3, "算法": 2, "模型训练": 5, "微调": 4, "推理": 2,
    "代码": 3, "编程": 4, "项目": 2, "github": 2, "gitee": 2, "仓库": 2,
    "开源": 2,
}

MEDIA_TERMS = {
    "动漫": 3, "动画": 2, "番剧": 3, "二次元": 3, "amv": 4, "mad": 4,
    "剪辑": 2, "混剪": 3, "素材": 2, "名场面": 3, "片段": 1,
    "电影": 2, "电视剧": 2, "影视": 3, "音乐": 1, "mv": 2,
    "日语": 2, "日文": 2, "配音": 2, "人物": 1, "角色": 1, "情感": 1,
    "jump": 3, "周刊": 1, "火影": 5, "忍者": 2, "宁次": 5,
    "咒术": 4, "绮罗罗": 5, "鬼灭": 4, "海贼": 3, "柯南": 3,
    "进击的巨人": 4, "naruto": 4, "jujutsu": 4, "anime": 4,
}

GAME_TERMS = {
    "游戏": 2, "手游": 3, "抽卡": 4, "卡池": 4, "抽数": 4, "角色": 2,
    "技能": 2, "版本": 2, "攻略": 3, "半周年": 4, "周年": 2, "养成": 2,
    "强度": 2, "配队": 3, "商店": 1, "副本": 2, "玩家": 1, "up": 2,
    "保底": 3, "氪": 2, "避坑": 3, "前瞻": 2, "棕色尘埃": 5,
    "阿奇拉": 5, "黑妹": 3, "提尔": 3, "西利亚": 3,
    "原神": 5, "崩坏": 4, "星穹铁道": 5, "崩铁": 5, "明日方舟": 5,
    "鸣潮": 4, "绝区零": 4, "蔚蓝档案": 4, "碧蓝航线": 4, "公主连结": 4,
    "fgo": 4, "阴阳师": 3, "王者荣耀": 4, "和平精英": 3, "三角洲": 3,
    "深渊": 3, "boss": 2, "出货": 2, "零氪": 3, "月卡": 2, "通行证": 2,
    "复刻": 2, "限定": 2, "皮肤": 2, "歪": 1,
    "有缘之客": 4,
}

GAME_REVIEW_TERMS = {
    "排行": 4, "排名": 4, "测评": 4, "评测": 3, "评价": 3, "点评": 3,
    "从夯到拉": 6, "t0": 3, "t1": 2, "t2": 2, "强度榜": 5,
    "节奏榜": 5, "榜": 2, "主观": 3, "鉴赏": 3, "值不值得": 3,
    "拉完": 3, "人上人": 3, "夯": 3, "强度": 2,
}

SCIENCE_TERMS = {
    "科普": 3, "医学": 4, "医学生": 4, "医生": 3, "临床": 4, "健康": 3,
    "减肥": 4, "减脂": 4, "瘦身": 3, "减重": 3, "营养": 3, "饮食": 2,
    "药物": 4, "药品": 4, "otc": 5, "处方": 4, "剂量": 3, "副作用": 4,
    "禁忌": 4, "疗效": 3, "临床药理": 5, "研究": 2, "论文": 3, "实验": 2,
    "指南": 3, "证据": 2, "疾病": 3, "治疗": 3, "手术": 2, "保健品": 3,
    "奥利司他": 5, "奥利斯": 5, "脂肪": 2, "热量": 2, "代谢": 3,
    "胰岛素": 3, "血糖": 3, "血压": 2, "维生素": 2, "益生菌": 2,
    "偏方": 3, "辟谣": 4, "科学": 2, "知识": 1, "医美": 3, "皮肤": 2,
    "痘": 2, "脱发": 2, "睡眠": 2, "免疫力": 2,
}


def _score_terms(text: str, terms: dict[str, int]) -> tuple[int, list[str]]:
    low = (text or "").lower()
    score = 0
    hits: list[str] = []
    for term, weight in terms.items():
        if term.lower() in low:
            score += weight
            hits.append(term)
    return score, hits


def classify_video(
    video: VideoEvidence,
    signals: ExtractedSignals,
) -> VideoClassification:
    # 标题/简介/标签决定视频主题；页面文本、字幕和评论只做加权补充，
    # 避免评论区跑题把整条视频带偏。
    primary_text = " ".join([video.title, video.description, " ".join(video.tags)])
    # 评论只取点赞最高的 5 条做弱信号，避免评论区玩梗把类型带偏。
    top_comments = sorted(
        video.comments,
        key=lambda comment: comment.likes,
        reverse=True,
    )[:5]
    secondary_text = " ".join(
        [
            video.page_text,
            video.transcript_text(),
            " ".join(comment.text for comment in top_comments),
        ]
    )
    hardware_primary, hardware_hits_primary = _score_terms(primary_text, HARDWARE_TERMS)
    hardware_secondary, hardware_hits_secondary = _score_terms(
        secondary_text, HARDWARE_TERMS
    )
    software_primary, software_hits_primary = _score_terms(primary_text, SOFTWARE_TERMS)
    software_secondary, software_hits_secondary = _score_terms(
        secondary_text, SOFTWARE_TERMS
    )
    usage_primary, usage_hits_primary = _score_terms(primary_text, USAGE_TERMS)
    usage_secondary, usage_hits_secondary = _score_terms(secondary_text, USAGE_TERMS)
    development_primary, development_hits_primary = _score_terms(
        primary_text, DEVELOPMENT_TERMS
    )
    development_secondary, development_hits_secondary = _score_terms(
        secondary_text, DEVELOPMENT_TERMS
    )
    media_primary, media_hits_primary = _score_terms(primary_text, MEDIA_TERMS)
    media_secondary, media_hits_secondary = _score_terms(secondary_text, MEDIA_TERMS)
    game_primary, game_hits_primary = _score_terms(primary_text, GAME_TERMS)
    game_secondary, game_hits_secondary = _score_terms(secondary_text, GAME_TERMS)
    repair_primary, repair_hits_primary = _score_terms(primary_text, REPAIR_TERMS)
    repair_secondary, repair_hits_secondary = _score_terms(
        secondary_text, REPAIR_TERMS
    )
    review_primary, review_hits_primary = _score_terms(
        primary_text, GAME_REVIEW_TERMS
    )
    review_secondary, review_hits_secondary = _score_terms(
        secondary_text, GAME_REVIEW_TERMS
    )
    science_primary, science_hits_primary = _score_terms(
        primary_text, SCIENCE_TERMS
    )
    science_secondary, science_hits_secondary = _score_terms(
        secondary_text, SCIENCE_TERMS
    )

    hardware_score = hardware_primary * 2 + hardware_secondary
    software_score = software_primary * 2 + software_secondary
    usage_score = usage_primary * 2 + usage_secondary
    development_score = development_primary * 2 + development_secondary
    media_score = media_primary * 2 + media_secondary
    game_score = game_primary * 2 + game_secondary
    repair_score = repair_primary * 2 + repair_secondary
    review_score = review_primary * 2 + review_secondary
    science_score = science_primary * 2 + science_secondary
    hardware_hits = list(
        dict.fromkeys(hardware_hits_primary + hardware_hits_secondary)
    )
    software_hits = list(
        dict.fromkeys(software_hits_primary + software_hits_secondary)
    )
    usage_hits = list(dict.fromkeys(usage_hits_primary + usage_hits_secondary))
    development_hits = list(
        dict.fromkeys(development_hits_primary + development_hits_secondary)
    )
    media_hits = list(dict.fromkeys(media_hits_primary + media_hits_secondary))
    game_hits = list(dict.fromkeys(game_hits_primary + game_hits_secondary))
    repair_hits = list(
        dict.fromkeys(repair_hits_primary + repair_hits_secondary)
    )
    review_hits = list(
        dict.fromkeys(review_hits_primary + review_hits_secondary)
    )
    science_hits = list(
        dict.fromkeys(science_hits_primary + science_hits_secondary)
    )

    if signals.repo_mentions:
        software_score += 10
        software_hits.append("仓库地址")

    if (
        hardware_score >= 6
        and software_score >= 8
        and hardware_score <= software_score * 3
    ):
        kind = "hardware_software_mixed"
    elif (
        hardware_score >= 4
        and (repair_score >= 8 or repair_primary >= 4)
        and hardware_score > software_score + 2
    ):
        kind = "hardware_tutorial"
    elif (
        game_score >= 5
        and review_score >= 6
        and software_score < 4
        and hardware_score < 4
    ):
        kind = "game_review"
    elif (
        game_score >= 5
        and game_score >= software_score * 2
        and game_score >= media_score * 2
        and hardware_score < 4
    ):
        kind = "game_guide"
    elif (
        science_score >= 8
        and science_score >= software_score * 3
        and hardware_score < 4
        and game_score < 5
    ):
        kind = "science_content"
    elif software_score >= 4 or signals.repo_mentions:
        if usage_score >= 5 and usage_score >= development_score + 2:
            kind = "software_usage"
        else:
            kind = "software_project"
    elif (
        hardware_score >= 2
        and software_score < 4
        and repair_score < 8
    ):
        kind = "hardware_topic"
    elif media_score >= 4:
        kind = "media_content"
    else:
        kind = "general"

    return VideoClassification(
        kind=kind,
        hardware_score=hardware_score,
        software_score=software_score,
        usage_score=usage_score,
        development_score=development_score,
        media_score=media_score,
        game_score=game_score,
        repair_score=repair_score,
        review_score=review_score,
        science_score=science_score,
        hardware_hits=hardware_hits,
        software_hits=software_hits,
        usage_hits=usage_hits,
        development_hits=development_hits,
        media_hits=media_hits,
        game_hits=game_hits,
        repair_hits=repair_hits,
        review_hits=review_hits,
        science_hits=science_hits,
    )
