from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Any

from .llm import LLMClient, LLMError
from .models import format_seconds
from .store import ProjectStore


EN_STOP = {
    "the", "and", "for", "with", "this", "that", "what", "how", "why",
    "when", "where", "which", "who", "is", "are", "was", "were", "be",
    "to", "of", "in", "on", "at", "by", "or", "if", "it", "its", "as",
    "a", "an", "do", "does", "did", "can", "could", "should", "would",
    "you", "your", "my", "me", "we", "our", "they", "them", "their",
}

CJK_STOP = {
    "怎么", "如何", "什么", "为什么", "哪里", "哪个", "这个", "那个",
    "一个", "可以", "一下", "视频", "里面", "这里", "那里", "就是",
    "需要", "是否", "有没有", "告诉我", "请问", "作者", "博主",
}


def _tokens(text: str) -> list[str]:
    value = (text or "").lower()
    tokens: list[str] = []
    for word in re.findall(r"[a-z][a-z0-9_.+-]{1,}", value):
        if word not in EN_STOP:
            tokens.append(word)
    for run in re.findall(r"[\u4e00-\u9fff]{2,}", value):
        for size in (2, 3, 4):
            for index in range(max(0, len(run) - size + 1)):
                token = run[index : index + size]
                if token not in CJK_STOP:
                    tokens.append(token)
    return tokens


def _chunks(analysis: dict[str, Any]) -> list[dict[str, Any]]:
    video = analysis.get("video") or {}
    chunks: list[dict[str, Any]] = []

    def add(text: str, source: str, start: float | None = None, label: str = "") -> None:
        clean = re.sub(r"\s+", " ", text or "").strip()
        if not clean:
            return
        chunks.append(
            {
                "text": clean,
                "source": source,
                "start": start,
                "label": label or source,
            }
        )

    add(str(video.get("title") or ""), "title", label="视频标题")
    add(str(video.get("description") or ""), "description", label="视频简介")
    for chapter in video.get("chapters") or []:
        add(
            str(chapter.get("title") or ""),
            "chapter",
            float(chapter.get("start") or 0),
            label="章节",
        )
    for seg in video.get("subtitles") or []:
        source = str(seg.get("source") or "cc")
        label = "本地 ASR" if source == "asr" else "视频字幕"
        add(
            str(seg.get("text") or ""),
            "subtitle",
            float(seg.get("start") or 0),
            label=label,
        )
    for comment in video.get("comments") or []:
        add(str(comment.get("text") or ""), "comment", label="评论")

    for candidate in analysis.get("candidates") or []:
        readme = str(candidate.get("readme") or "")
        for paragraph in re.split(r"\n{2,}", readme):
            add(paragraph, "readme", label="仓库 README")
        deps = candidate.get("dependencies") or []
        if deps:
            add("、".join(str(item) for item in deps), "dependencies", label="依赖清单")

    unique: list[dict[str, Any]] = []
    seen: set[str] = set()
    for chunk in chunks:
        key = chunk["text"][:160]
        if key in seen:
            continue
        seen.add(key)
        unique.append(chunk)
    return unique


def retrieve_sources(
    analysis: dict[str, Any],
    question: str,
    limit: int = 6,
) -> list[dict[str, Any]]:
    query_tokens = list(dict.fromkeys(_tokens(question)))
    if not query_tokens:
        return []
    source_weights = {
        "subtitle": 1.6,
        "readme": 1.2,
        "chapter": 1.2,
        "description": 0.9,
        "comment": 0.35,
        "dependencies": 0.7,
        "title": 0.4,
    }
    if any(marker in question for marker in ("怎么", "如何", "步骤", "哪一步", "操作", "导入")):
        source_weights["subtitle"] *= 1.8
        source_weights["chapter"] *= 1.2
        source_weights["comment"] *= 0.5
    scored: list[tuple[float, dict[str, Any]]] = []
    for chunk in _chunks(analysis):
        text = chunk["text"].lower()
        score = 0.0
        for token in query_tokens:
            count = text.count(token)
            if count:
                score += count * (len(token) + 1)
        if score > 0:
            score *= source_weights.get(chunk["source"], 0.7)
            score /= 1 + math.log10(max(1, len(text)))
            scored.append((score, chunk))
    scored.sort(key=lambda item: (-item[0], item[1].get("start") or 0))
    results: list[dict[str, Any]] = []
    for score, chunk in scored[:limit]:
        item = dict(chunk)
        item["score"] = round(score, 2)
        results.append(item)
    return results


def _extractive_answer(sources: list[dict[str, Any]], question: str) -> str:
    if not sources:
        return (
            f"在已保存的证据里没有找到与“{question}”直接相关的内容。"
            "可以换一个关键词，或重新分析视频。"
        )
    lines = [f"根据已保存的证据，找到这些与“{question}”相关的片段："]
    for source in sources:
        prefix = ""
        if source.get("start") is not None:
            prefix = f"[{format_seconds(source['start'])}] "
        lines.append(f"- {prefix}{source['text']}（{source['label']}）")
    lines.append("")
    lines.append("当前未配置 LLM，以上是检索到的原文片段，不是综合结论。")
    return "\n".join(lines)


def answer_question(
    analysis: dict[str, Any],
    question: str,
    llm: LLMClient | None = None,
) -> dict[str, Any]:
    question = (question or "").strip()
    if not question:
        raise ValueError("问题为空。")
    sources = retrieve_sources(analysis, question)
    llm_used = False
    answer = ""
    if llm is None:
        client = LLMClient()
    else:
        client = llm
    if client.available():
        evidence = "\n\n".join(
            f"[{source['label']}"
            + (
                f" {format_seconds(source['start'])}"
                if source.get("start") is not None
                else ""
            )
            + f"] {source['text']}"
            for source in sources
        )
        system = """你是 RJ 的项目问答助手。只根据给出的证据回答。
规则：
1. 不要编造视频、仓库、命令、型号或时间戳。
2. 每条关键结论标注来源，例如 [视频字幕 01:23] 或 [仓库 README]。
3. 区分视频原文、仓库文档和推断；证据不足就说不知道。
4. 用简洁中文回答，不要输出分析过程。"""
        user = f"问题：{question}\n\n证据：\n{evidence or '（没有检索到相关片段）'}"
        try:
            answer = client.complete(system, user, max_tokens=1200)
            llm_used = True
        except LLMError:
            answer = ""
    if not answer:
        answer = _extractive_answer(sources, question)
    return {
        "question": question,
        "answer": answer,
        "sources": sources,
        "llm_used": llm_used,
    }


def answer_project_question(
    store: ProjectStore,
    video_id: str,
    question: str,
    llm: LLMClient | None = None,
) -> dict[str, Any]:
    analysis = store.load(video_id)
    if not analysis:
        raise FileNotFoundError("项目不存在或尚未分析。")
    candidates_path = store.project_dir(video_id) / "candidates.json"
    if candidates_path.exists():
        try:
            analysis["candidates"] = json.loads(
                candidates_path.read_text(encoding="utf-8")
            )
        except (OSError, json.JSONDecodeError):
            pass
    result = answer_question(analysis, question, llm=llm)
    result["video_id"] = video_id
    return result
