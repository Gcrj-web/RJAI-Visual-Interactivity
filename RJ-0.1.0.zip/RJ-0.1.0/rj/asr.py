from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
import subprocess
import threading
import time
import uuid
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable

from .bilibili import BilibiliClient, BilibiliError
from .asr_norm import normalize_text
from .models import SubtitleSegment


Progress = Callable[[str], None] | None


class ASRError(RuntimeError):
    pass


class ASRDependencyError(ASRError):
    pass


_AVAILABLE: bool | None = None


def asr_available() -> bool:
    """不只检查包是否存在，也确认 ctranslate2/av 能真正导入。"""
    global _AVAILABLE
    if _AVAILABLE is None:
        try:
            import faster_whisper  # noqa: F401

            _AVAILABLE = True
        except Exception:
            _AVAILABLE = False
    return _AVAILABLE


def _truthy(value: str, default: bool = True) -> bool:
    if not value:
        return default
    return value.strip().lower() not in {"0", "false", "no", "off", "disabled"}


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


@dataclass
class ASRConfig:
    model: str = "small"
    device: str = "cpu"
    compute_type: str = "int8"
    language: str = "zh"
    beam_size: int = 5
    vad_filter: bool = True
    enabled: bool = True
    model_dir: Path = Path("data/models/faster-whisper")
    cache_dir: Path = Path("data/cache/asr")
    audio_dir: Path = Path("data/cache/audio")

    @classmethod
    def from_env(cls) -> "ASRConfig":
        return cls(
            model=os.environ.get("RJ_ASR_MODEL", "small").strip() or "small",
            device=os.environ.get("RJ_ASR_DEVICE", "cpu").strip() or "cpu",
            compute_type=(
                os.environ.get("RJ_ASR_COMPUTE_TYPE", "int8").strip() or "int8"
            ),
            language=os.environ.get("RJ_ASR_LANGUAGE", "zh").strip(),
            beam_size=_env_int("RJ_ASR_BEAM_SIZE", 5),
            vad_filter=_truthy(os.environ.get("RJ_ASR_VAD", "1")),
            enabled=_truthy(os.environ.get("RJ_ASR_ENABLED", "1")),
            model_dir=Path(
                os.environ.get("RJ_ASR_MODEL_DIR") or "data/models/faster-whisper"
            ),
            cache_dir=Path(os.environ.get("RJ_ASR_CACHE_DIR") or "data/cache/asr"),
            audio_dir=Path(os.environ.get("RJ_ASR_AUDIO_DIR") or "data/cache/audio"),
        )


def describe() -> dict:
    config = ASRConfig.from_env()
    return {
        "available": asr_available(),
        "enabled": config.enabled,
        "model": config.model,
        "device": config.device,
        "compute_type": config.compute_type,
        "language": config.language,
        "ffmpeg": shutil.which("ffmpeg") or "",
    }


_MODEL_LOCK = threading.Lock()
_TRANSCRIBE_LOCK = threading.Lock()
_MODELS: dict[tuple[str, str, str], object] = {}
ASR_CACHE_VERSION = "4"


def _model_cache_exists(config: ASRConfig) -> bool:
    if not config.model or "/" in config.model or "\\" in config.model:
        return False
    snapshot = config.model_dir / f"models--Systran--faster-whisper-{config.model}"
    return snapshot.exists() and any(snapshot.rglob("config.json"))


def _get_model(config: ASRConfig):
    if not asr_available():
        raise ASRDependencyError(
            "未安装 faster-whisper，跳过 ASR。运行 "
            "`python -m pip install -r requirements-asr.txt` 后重启服务。"
        )
    from faster_whisper import WhisperModel

    key = (config.model, config.device, config.compute_type)
    with _MODEL_LOCK:
        model = _MODELS.get(key)
        if model is None:
            config.model_dir.mkdir(parents=True, exist_ok=True)
            # 已缓存的模型直接离线加载，避免 huggingface_hub 每次都联网查仓库信息。
            local_only = _truthy(
                os.environ.get("RJ_ASR_LOCAL_FILES_ONLY", "0")
            ) or _model_cache_exists(config)
            model = WhisperModel(
                config.model,
                device=config.device,
                compute_type=config.compute_type,
                download_root=str(config.model_dir),
                local_files_only=local_only,
            )
            _MODELS[key] = model
    return model


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value or "")[:80] or "video"


def _cache_path(video_id: str, config: ASRConfig, hint_key: str = "") -> Path:
    name = (
        f"{_safe_name(video_id)}-{_safe_name(config.model)}-"
        f"{_safe_name(config.language or 'auto')}-v{ASR_CACHE_VERSION}"
        f"-{_safe_name(hint_key or 'none')[:10]}.json"
    )
    return config.cache_dir / name


def _hint_terms(hints: dict | None) -> list[str]:
    """从标题、标签、章节里提取给 Whisper 的术语提示。"""
    if not hints:
        return []
    values: list[str] = []
    for key in ("title", "description", "tags", "chapters"):
        value = hints.get(key)
        if isinstance(value, str):
            values.append(value)
        elif isinstance(value, (list, tuple)):
            values.extend(str(item) for item in value if item)
    text = " ".join(values)
    terms: list[str] = []
    for part in re.split(r"[，,。;；|/\\\s【】\[\]（）()]+", text):
        part = part.strip()
        if 2 <= len(part) <= 24 and not part.isdigit():
            terms.append(part)
    # 这些是中文游戏/技术视频里高频、且 Whisper 容易写错的术语。
    known = (
        "有缘之客", "图鉴", "卡池", "抽数", "保底", "半周年", "属性伤害",
        "增益", "泛用性", "竞技场", "商店", "常驻", "复刻", "皮肤", "服装",
        "技能", "冷却", "SP", "PVP", "魔兽",
    )
    terms.extend(term for term in known if term in text)
    return list(dict.fromkeys(terms))[:24]


def _hint_key(hints: dict | None) -> str:
    terms = _hint_terms(hints)
    if not terms:
        return "none"
    return hashlib.sha1("|".join(terms).encode("utf-8")).hexdigest()[:10]


def _hint_text(hints: dict | None) -> str:
    if not hints:
        return ""
    parts: list[str] = []
    for key in ("title", "description"):
        value = hints.get(key)
        if value:
            parts.append(str(value))
    for key in ("tags", "chapters"):
        value = hints.get(key)
        if isinstance(value, (list, tuple)):
            parts.extend(str(item) for item in value if item)
    return " ".join(parts)


def _normalize_segments(
    segments: list[SubtitleSegment],
    hints: dict | None,
) -> list[SubtitleSegment]:
    hint_text = _hint_text(hints)
    result: list[SubtitleSegment] = []
    last_start = -1.0
    for segment in segments:
        # Whisper 偶尔会把某一小段的时间戳写回几分钟前，这里保证时间线单调。
        start = max(float(segment.start), last_start)
        end = max(float(segment.end), start + 0.3)
        # 日文行里也可能有汉字，不能套用繁转简，否则会把“龍”改成“龙”。
        is_japanese = bool(re.search(r"[\u3040-\u30ff]", segment.text))
        result.append(
            replace(
                segment,
                start=start,
                end=end,
                text=normalize_text(
                    segment.text,
                    hint_text,
                    chinese=not is_japanese,
                ),
            )
        )
        last_start = start
    return result


def _strip_prompt_echo(
    segments: list[SubtitleSegment],
    hints: dict | None,
) -> list[SubtitleSegment]:
    """去掉 Whisper 偶尔复读的提示词、标题和章节列表。"""
    chapter_titles = [
        str(item)
        for item in (hints or {}).get("chapters") or []
        if item
    ]
    title = str((hints or {}).get("title") or "")
    markers = (
        "请用简体中文转写",
        "以下是视频里出现的专有名词",
        "请保持这些写法",
        "专有名词：",
        "固有名詞：",
        "proper nouns:",
    )
    result: list[SubtitleSegment] = []
    for segment in segments:
        text = (segment.text or "").strip()
        if not text:
            continue
        low = text.lower()
        if any(marker.lower() in low for marker in markers):
            continue
        chapter_hits = sum(
            1 for chapter in chapter_titles if chapter and chapter in text
        )
        if chapter_hits >= 2 and len(text) < 200:
            continue
        if title and text.startswith(title) and len(text) < 120:
            continue
        result.append(segment)
    return result


def cleanup_stale_audio(audio_dir: Path, max_age_seconds: int = 3600) -> int:
    """清理异常中断留下的临时音频，不动转写 JSON 和模型。"""
    if not audio_dir.exists():
        return 0
    removed = 0
    now = time.time()
    for path in audio_dir.glob("*"):
        if not path.is_file() or path.suffix.lower() not in {
            ".bin", ".wav", ".m4s", ".flv", ".mp4", ".mp3", ".m4a", ".aac"
        }:
            continue
        try:
            if now - path.stat().st_mtime > max_age_seconds:
                path.unlink()
                removed += 1
        except OSError:
            pass
    return removed


def _load_cache(path: Path) -> list[SubtitleSegment]:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    segments: list[SubtitleSegment] = []
    for item in data if isinstance(data, list) else []:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text") or "").strip()
        if not text:
            continue
        segments.append(
            SubtitleSegment(
                start=float(item.get("start") or 0),
                end=float(item.get("end") or 0),
                text=text,
                source="asr",
            )
        )
    return segments


def _save_cache(path: Path, segments: list[SubtitleSegment]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = [
        {"start": seg.start, "end": seg.end, "text": seg.text}
        for seg in segments
    ]
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _prepare_audio(audio_path: Path) -> tuple[Path, Path | None]:
    """有 ffmpeg 就转成 16k 单声道 wav；没有就直接交给 PyAV 解码。"""
    ffmpeg = shutil.which("ffmpeg")
    if not ffmpeg:
        return audio_path, None
    wav_path = audio_path.with_suffix(".wav")
    try:
        subprocess.run(
            [
                ffmpeg,
                "-y",
                "-i",
                str(audio_path),
                "-vn",
                "-ac",
                "1",
                "-ar",
                "16000",
                str(wav_path),
            ],
            check=True,
            capture_output=True,
            timeout=180,
        )
    except (OSError, subprocess.SubprocessError):
        return audio_path, None
    if wav_path.exists() and wav_path.stat().st_size > 1024:
        return wav_path, wav_path
    return audio_path, None


def transcribe_file(
    path: Path,
    config: ASRConfig,
    progress: Progress = None,
    hints: dict | None = None,
) -> list[SubtitleSegment]:
    model = _get_model(config)
    if progress:
        progress("语音识别中")
    language = (
        None
        if config.language.lower() in {"", "auto"}
        else config.language.lower()
    )
    terms = _hint_terms(hints)
    prompt = None
    if terms:
        if language == "ja":
            prompt = "固有名詞：" + "、".join(terms[:16])
        elif language == "en":
            prompt = "Proper nouns: " + ", ".join(terms[:16])
        else:
            # 短提示比长指令更不容易被 Whisper 复读。
            prompt = "专有名词：" + "、".join(terms[:16])
    hotwords = " ".join(terms[:20]) if terms else None
    with _TRANSCRIBE_LOCK:
        segments, _info = model.transcribe(
            str(path),
            language=language,
            beam_size=config.beam_size,
            vad_filter=config.vad_filter,
            condition_on_previous_text=False,
            initial_prompt=prompt,
            hotwords=hotwords,
        )
        result: list[SubtitleSegment] = []
        for segment in segments:
            text = (getattr(segment, "text", "") or "").strip()
            if not text:
                continue
            result.append(
                SubtitleSegment(
                    start=float(getattr(segment, "start", 0) or 0),
                    end=float(getattr(segment, "end", 0) or 0),
                    text=text,
                    source="asr",
                )
            )
    if not result:
        raise ASRError("ASR 没有识别出文字。")
    return result


def _transcribe_with_fallback(
    path: Path,
    config: ASRConfig,
    progress: Progress = None,
    hints: dict | None = None,
) -> list[SubtitleSegment]:
    try:
        return transcribe_file(path, config, progress, hints=hints)
    except ASRError:
        if (config.language or "").lower() in {"", "auto"}:
            raise
        if progress:
            progress("中文识别为空，自动检测语言重试")
        fallback = replace(config, language="auto")
        return transcribe_file(path, fallback, progress, hints=hints)


def transcribe_media_file(
    video_id: str,
    path: Path,
    config: ASRConfig | None = None,
    progress: Progress = None,
    hints: dict | None = None,
) -> list[SubtitleSegment]:
    """转写一个临时下载的媒体文件（mp4 / m4a / webm），并复用 ASR 缓存。"""
    config = config or ASRConfig.from_env()
    if not config.enabled:
        raise ASRError("ASR 已禁用（RJ_ASR_ENABLED=0）。")
    if not asr_available():
        raise ASRDependencyError(
            "未安装 faster-whisper，跳过 ASR。运行 "
            "`python -m pip install -r requirements-asr.txt` 后重启服务。"
        )

    cache_path = _cache_path(video_id, config, _hint_key(hints))
    cached = _load_cache(cache_path)
    if cached:
        if progress:
            progress("使用缓存的 ASR 转写")
        return _strip_prompt_echo(_normalize_segments(cached, hints), hints)

    prepared, converted = _prepare_audio(path)
    try:
        segments = _transcribe_with_fallback(prepared, config, progress, hints=hints)
        segments = _normalize_segments(segments, hints)
        segments = _strip_prompt_echo(segments, hints)
        _save_cache(cache_path, segments)
        return segments
    finally:
        if converted and converted.exists():
            try:
                converted.unlink()
            except OSError:
                pass


def transcribe_bilibili(
    video_id: str,
    aid: int,
    cid: int,
    cookie: str = "",
    config: ASRConfig | None = None,
    progress: Progress = None,
    client: BilibiliClient | None = None,
    hints: dict | None = None,
) -> list[SubtitleSegment]:
    config = config or ASRConfig.from_env()
    if not config.enabled:
        raise ASRError("ASR 已禁用（RJ_ASR_ENABLED=0）。")

    cache_path = _cache_path(video_id, config, _hint_key(hints))
    cached = _load_cache(cache_path)
    if cached:
        if progress:
            progress("使用缓存的 ASR 转写")
        return _strip_prompt_echo(_normalize_segments(cached, hints), hints)

    if not asr_available():
        raise ASRDependencyError(
            "未安装 faster-whisper，跳过 ASR。运行 "
            "`python -m pip install -r requirements-asr.txt` 后重启服务。"
        )

    client = client or BilibiliClient(cookie=cookie)
    if progress:
        progress("获取音频流")
    try:
        audio_urls = client.get_audio_urls(aid, cid, video_id)
    except BilibiliError as exc:
        raise ASRError(f"获取音频流失败：{exc}") from exc

    config.audio_dir.mkdir(parents=True, exist_ok=True)
    cleanup_stale_audio(config.audio_dir)
    audio_path = config.audio_dir / (
        f"{_safe_name(video_id)}-{uuid.uuid4().hex[:8]}.bin"
    )
    if progress:
        progress("下载音频")
    try:
        client.download_audio(
            audio_urls,
            audio_path,
            referer=f"https://www.bilibili.com/video/{video_id}/",
        )
    except BilibiliError as exc:
        raise ASRError(str(exc)) from exc

    temporary = [audio_path]
    try:
        prepared, converted = _prepare_audio(audio_path)
        if converted:
            temporary.append(converted)
        if progress:
            progress("加载语音模型（首次运行会下载模型）")
        segments = _transcribe_with_fallback(
            prepared, config, progress, hints=hints
        )
        segments = _normalize_segments(segments, hints)
        segments = _strip_prompt_echo(segments, hints)
        _save_cache(cache_path, segments)
        return segments
    finally:
        for path in dict.fromkeys(temporary):
            try:
                path.unlink()
            except OSError:
                pass
