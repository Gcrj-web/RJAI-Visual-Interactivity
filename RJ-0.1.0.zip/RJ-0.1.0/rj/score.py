from __future__ import annotations

import difflib
import math
import re
from datetime import datetime, timezone

from .extract import clean_title, term_counter
from .models import ExtractedSignals, RepoCandidate, VideoEvidence


def _parse_year(value: str) -> int:
    match = re.search(r"(20\d{2})", value or "")
    return int(match.group(1)) if match else 0


def _confidence(score: float) -> str:
    if score >= 70:
        return "高"
    if score >= 45:
        return "中"
    return "低"


def score_candidates(
    candidates: list[RepoCandidate],
    signals: ExtractedSignals,
    video: VideoEvidence,
) -> list[RepoCandidate]:
    explicit = {m.full_name.lower() for m in signals.repo_mentions}
    video_text = " ".join(
        [video.title, video.description, " ".join(video.tags), video.transcript_text()]
    ).lower()
    video_counter = term_counter(video_text)
    title_clean = clean_title(video.title).lower()

    seen: set[tuple[str, str]] = set()
    unique: list[RepoCandidate] = []
    for candidate in candidates:
        key = (candidate.host, candidate.full_name.lower())
        if not candidate.full_name or key in seen:
            continue
        seen.add(key)
        unique.append(candidate)

    current_year = datetime.now(timezone.utc).year
    for candidate in unique:
        reasons: list[str] = []
        if candidate.source == "manual":
            candidate.score = 100.0
            candidate.reasons = ["用户手动确认的仓库"]
            continue
        haystack = " ".join(
            [
                candidate.full_name,
                candidate.description,
                " ".join(candidate.topics),
                candidate.readme[:12000],
            ]
        ).lower()

        if candidate.full_name.lower() in explicit:
            candidate.score = 100.0
            candidate.reasons = ["视频简介/评论/字幕中直接给出了仓库地址"]
            candidate.source = "explicit"
            continue

        score = 0.0
        name_hit = False
        if candidate.full_name.lower() in video_text:
            score += 30
            name_hit = True
            reasons.append("仓库全名出现在视频文本中")
        else:
            repo_name = candidate.full_name.split("/")[-1].lower()
            if len(repo_name) >= 4 and repo_name in video_text:
                score += 18
                name_hit = True
                reasons.append("仓库名出现在视频文本中")

        hits = 0
        for term in signals.terms[:40]:
            if len(term.term) < 3 and not re.search(r"[\u4e00-\u9fff]", term.term):
                continue
            if term.term in haystack:
                score += min(4.0, term.weight)
                hits += 1
        if hits >= 6:
            score += 8
        if hits:
            reasons.append(f"与视频线索有 {hits} 个词重合")

        # 没有名称命中、也没有任何线索词命中时，星级和更新时间会把
        # 完全无关的热门仓库推上来。这里直接判为无效候选。
        if not name_hit and hits == 0:
            candidate.score = 0.0
            candidate.reasons = ["与视频线索没有实质重合"]
            continue

        if candidate.description and title_clean:
            ratio = difflib.SequenceMatcher(
                None, title_clean, candidate.description.lower()[:120]
            ).ratio()
            score += round(ratio * 12, 1)
            if ratio > 0.5:
                reasons.append("仓库描述与视频标题相近")

        star_bonus = min(10.0, math.log10(max(candidate.stars, 1) + 1) * 3.2)
        if name_hit or hits >= 2:
            score += star_bonus
            if candidate.stars >= 100:
                reasons.append(f"{candidate.stars} stars")

            year = _parse_year(candidate.updated_at)
            if year and current_year - year <= 2:
                score += 5
                reasons.append("近两年有更新")
            if candidate.license:
                score += 2
        else:
            # 只命中一个泛词时，不让 stars 主导排序。
            score += min(2.0, star_bonus * 0.2)
        if not candidate.description:
            score -= 6
        if any(name in candidate.full_name.lower() for name in ("awesome", "tutorial", "example")):
            score -= 8

        # 只有几个通用英文词命中时，避免把大而全的仓库排到前面。
        top_video_terms = {t for t, _ in video_counter.most_common(8)}
        if top_video_terms and not any(t in haystack for t in top_video_terms):
            score -= 10

        candidate.score = round(max(0.0, min(95.0, score)), 1)
        candidate.reasons = reasons or ["仅有弱相关线索"]

    unique.sort(key=lambda c: (-c.score, -c.stars))
    for candidate in unique:
        candidate.reasons = list(dict.fromkeys(candidate.reasons))
        candidate.reasons.append(f"置信度：{_confidence(candidate.score)}")
    return unique
