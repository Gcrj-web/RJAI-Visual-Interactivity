from __future__ import annotations

import tempfile
from dataclasses import dataclass
from pathlib import Path

import av
from PIL import Image


class FrameError(RuntimeError):
    pass


@dataclass
class ExtractedFrame:
    time: float
    path: Path
    width: int
    height: int


def _resampling_lanczos():
    resampling = getattr(Image, "Resampling", Image)
    return resampling.LANCZOS


def _frame_hash(image: Image.Image) -> int:
    gray = image.convert("L").resize((9, 8), _resampling_lanczos())
    pixels = list(gray.getdata())
    bits = 0
    for row in range(8):
        offset = row * 9
        for column in range(8):
            if pixels[offset + column] > pixels[offset + column + 1]:
                bits |= 1 << (row * 8 + column)
    return bits


def _hamming(left: int, right: int) -> int:
    return (left ^ right).bit_count()


def _timestamps(duration: float, count: int) -> list[float]:
    count = max(1, min(int(count or 1), 16))
    if duration <= 0:
        return [0.0]
    start = min(max(duration * 0.05, 0.0), max(duration - 0.2, 0.0))
    end = max(start, duration * 0.95)
    if count == 1:
        return [round((start + end) / 2, 3)]
    return [
        round(start + (end - start) * index / (count - 1), 3)
        for index in range(count)
    ]


def extract_frames(
    media_path: Path | str,
    duration: float = 0,
    count: int = 8,
    max_width: int = 768,
    jpeg_quality: int = 82,
    output_dir: Path | str | None = None,
) -> list[ExtractedFrame]:
    """从本地临时视频中抽取少量关键帧；调用方负责删除视频和帧目录。"""
    path = Path(media_path)
    if not path.exists() or path.stat().st_size < 1024:
        raise FrameError("视频文件不存在或过小")

    target_dir = Path(output_dir or tempfile.mkdtemp(prefix="rj-frames-"))
    target_dir.mkdir(parents=True, exist_ok=True)

    try:
        container = av.open(str(path))
    except Exception as exc:
        raise FrameError(f"无法打开视频：{exc}") from exc

    try:
        if not container.streams.video:
            raise FrameError("视频没有画面轨道")
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        if duration <= 0:
            duration = float(container.duration or 0) / av.time_base

        time_base = float(stream.time_base or 0)
        if time_base <= 0:
            raise FrameError("视频时间基准无效")

        frames: list[ExtractedFrame] = []
        previous_hash: int | None = None
        for timestamp in _timestamps(duration, count):
            try:
                container.seek(int(timestamp / time_base), stream=stream, backward=True)
            except Exception:
                continue

            chosen = None
            for frame in container.decode(stream):
                if frame.pts is None:
                    continue
                current = float(frame.pts) * time_base
                if current + 0.06 >= timestamp:
                    chosen = (frame, current)
                    break
            if chosen is None:
                continue

            image = chosen[0].to_image().convert("RGB")
            gray = image.convert("L").resize((32, 32))
            brightness = sum(gray.getdata()) / (32 * 32)
            if brightness < 6:
                continue

            current_hash = _frame_hash(image)
            if previous_hash is not None and _hamming(current_hash, previous_hash) <= 3:
                continue
            previous_hash = current_hash

            if image.width > max_width:
                ratio = max_width / image.width
                image = image.resize(
                    (max_width, max(1, int(image.height * ratio))),
                    _resampling_lanczos(),
                )

            frame_path = target_dir / f"frame-{len(frames):02d}.jpg"
            image.save(
                frame_path,
                "JPEG",
                quality=max(40, min(int(jpeg_quality), 95)),
                optimize=True,
            )
            frames.append(
                ExtractedFrame(
                    time=round(chosen[1], 3),
                    path=frame_path,
                    width=image.width,
                    height=image.height,
                )
            )
    finally:
        container.close()

    if not frames:
        raise FrameError("没有抽取到可用关键帧，视频可能全是黑屏或解码失败")
    return frames
