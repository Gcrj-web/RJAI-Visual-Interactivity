from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class SubtitleSegment:
    start: float
    end: float
    text: str
    source: str = "cc"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Comment:
    author: str
    text: str
    likes: int = 0
    pinned: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Chapter:
    title: str
    start: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class VideoEvidence:
    platform: str
    video_id: str
    url: str
    title: str
    description: str = ""
    author: str = ""
    author_id: str = ""
    aid: int = 0
    cid: int = 0
    tags: list[str] = field(default_factory=list)
    duration: float = 0.0
    pubdate: int = 0
    chapters: list[Chapter] = field(default_factory=list)
    subtitles: list[SubtitleSegment] = field(default_factory=list)
    comments: list[Comment] = field(default_factory=list)
    page_text: str = ""
    warnings: list[str] = field(default_factory=list)
    fetched_at: str = ""
    visual_analysis: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def transcript_text(self, with_time: bool = False) -> str:
        if not with_time:
            return "\n".join(seg.text for seg in self.subtitles if seg.text)
        lines: list[str] = []
        for seg in self.subtitles:
            if not seg.text:
                continue
            lines.append(f"[{format_seconds(seg.start)}] {seg.text}")
        return "\n".join(lines)


@dataclass
class RepoMention:
    host: str
    owner: str
    repo: str
    raw: str
    source: str
    start: float | None = None

    @property
    def full_name(self) -> str:
        return f"{self.owner}/{self.repo}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class SignalTerm:
    term: str
    weight: float
    sources: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ExtractedSignals:
    repo_mentions: list[RepoMention] = field(default_factory=list)
    urls: list[dict[str, Any]] = field(default_factory=list)
    terms: list[SignalTerm] = field(default_factory=list)
    tech_terms: list[str] = field(default_factory=list)
    queries: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RepoCandidate:
    host: str
    full_name: str
    html_url: str
    description: str = ""
    stars: int = 0
    forks: int = 0
    language: str = ""
    license: str = ""
    topics: list[str] = field(default_factory=list)
    updated_at: str = ""
    default_branch: str = ""
    readme: str = ""
    manifests: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    score: float = 0.0
    reasons: list[str] = field(default_factory=list)
    source: str = "search"

    def to_dict(self, include_readme: bool = False) -> dict[str, Any]:
        data = asdict(self)
        if not include_readme:
            data["readme"] = data["readme"][:1200]
        return data


@dataclass
class AnalysisResult:
    video: VideoEvidence
    signals: ExtractedSignals
    candidates: list[RepoCandidate]
    selected: RepoCandidate | None
    brief_md: str
    agent_prompt_md: str
    kind: str = "software_project"
    llm_used: bool = False
    warnings: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "video": self.video.to_dict(),
            "signals": self.signals.to_dict(),
            "candidates": [c.to_dict() for c in self.candidates],
            "selected": self.selected.to_dict() if self.selected else None,
            "brief_md": self.brief_md,
            "agent_prompt_md": self.agent_prompt_md,
            "kind": self.kind,
            "llm_used": self.llm_used,
            "warnings": self.warnings,
        }


def format_seconds(value: float | int | None) -> str:
    if value is None:
        return "?"
    total = max(0, int(float(value)))
    hours, rem = divmod(total, 3600)
    minutes, seconds = divmod(rem, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    return f"{minutes:02d}:{seconds:02d}"
