from __future__ import annotations

import base64
import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests

from .models import RepoCandidate


USER_AGENT = "RJ-project-intel/0.1 (personal research tool)"
MANIFEST_NAMES = [
    "package.json", "pyproject.toml", "requirements.txt", "Cargo.toml",
    "go.mod", "pom.xml", "build.gradle", "CMakeLists.txt", "Dockerfile",
    "docker-compose.yml", "docker-compose.yaml", "Makefile",
]


class CodeHostError(RuntimeError):
    pass


class RateLimited(CodeHostError):
    pass


class _DiskCache:
    def __init__(self, root: Path, ttl: int = 1800):
        self.root = root
        self.ttl = ttl
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        digest = hashlib.sha1(key.encode("utf-8")).hexdigest()
        return self.root / f"{digest}.json"

    def get(self, key: str) -> Any | None:
        path = self._path(key)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if time.time() - float(data.get("ts", 0)) > self.ttl:
            return None
        return data.get("value")

    def put(self, key: str, value: Any) -> None:
        path = self._path(key)
        try:
            path.write_text(
                json.dumps({"ts": time.time(), "value": value}, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            pass


def _sanitize_query(query: str) -> str:
    value = re.sub(r"[\"':]", " ", query or "")
    value = re.sub(r"\s+", " ", value).strip()
    return value[:80]


class GitHubClient:
    api = "https://api.github.com"

    def __init__(self, token: str | None = None, cache_dir: Path | None = None, timeout: int = 20):
        self.token = token
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(
            {
                "User-Agent": USER_AGENT,
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            }
        )
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"
        self.cache = _DiskCache(cache_dir or Path("data/cache/github"), ttl=1800)

    def _request(self, url: str, params: dict | None = None, accept: str | None = None, ttl: int = 1800):
        headers = {"Accept": accept} if accept else {}
        key = f"{url}|{params}|{accept}"
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        try:
            response = self.session.get(url, params=params, headers=headers, timeout=self.timeout)
        except requests.RequestException as exc:
            raise CodeHostError(f"GitHub 请求失败：{exc}") from exc
        if response.status_code == 403 and "rate limit" in response.text.lower():
            raise RateLimited("GitHub API 触发限流，请稍后再试或配置 GITHUB_TOKEN。")
        if response.status_code == 404:
            raise CodeHostError("GitHub 资源不存在（404）。")
        if response.status_code >= 400:
            raise CodeHostError(f"GitHub 返回 {response.status_code}：{response.text[:200]}")
        if accept and "raw" in accept:
            value: Any = response.text
        else:
            try:
                value = response.json()
            except ValueError as exc:
                raise CodeHostError("GitHub 返回了非 JSON 内容。") from exc
        self.cache.put(key, value)
        return value

    def search(self, query: str, per_page: int = 8) -> list[RepoCandidate]:
        clean = _sanitize_query(query)
        if not clean:
            return []
        data = self._request(
            f"{self.api}/search/repositories",
            params={
                "q": f"{clean} in:name,description,readme",
                "sort": "stars",
                "order": "desc",
                "per_page": str(per_page),
            },
        )
        return [self._to_candidate(item) for item in data.get("items", [])]

    def get_repo(self, full_name: str) -> RepoCandidate:
        data = self._request(f"{self.api}/repos/{quote(full_name)}")
        return self._to_candidate(data)

    def get_readme(self, full_name: str) -> str:
        try:
            return self._request(
                f"{self.api}/repos/{quote(full_name)}/readme",
                accept="application/vnd.github.raw",
            )
        except CodeHostError:
            return ""

    def list_root_files(self, full_name: str) -> list[str]:
        try:
            data = self._request(f"{self.api}/repos/{quote(full_name)}/contents/")
        except CodeHostError:
            return []
        if not isinstance(data, list):
            return []
        return [item.get("name", "") for item in data if item.get("type") == "file"]

    def get_raw_file(self, full_name: str, branch: str, path: str) -> str:
        url = f"https://raw.githubusercontent.com/{full_name}/{quote(branch)}/{quote(path)}"
        cached = self.cache.get(url)
        if cached is not None:
            return str(cached)
        try:
            response = self.session.get(url, timeout=self.timeout)
        except requests.RequestException:
            return ""
        if response.status_code >= 400:
            return ""
        text = response.text[:40000]
        self.cache.put(url, text)
        return text

    def enrich(self, candidate: RepoCandidate, include_manifests: bool = True) -> RepoCandidate:
        try:
            detail = self.get_repo(candidate.full_name)
            candidate = detail
        except CodeHostError:
            pass
        candidate.host = "github"
        candidate.html_url = candidate.html_url or f"https://github.com/{candidate.full_name}"
        candidate.readme = self.get_readme(candidate.full_name)
        if include_manifests and candidate.default_branch:
            files = self.list_root_files(candidate.full_name)
            candidate.manifests = [name for name in files if name in MANIFEST_NAMES]
            candidate.dependencies = []
            for name in candidate.manifests[:3]:
                text = self.get_raw_file(candidate.full_name, candidate.default_branch, name)
                if text:
                    candidate.dependencies.extend(parse_dependencies(name, text))
            candidate.dependencies = _dedupe(candidate.dependencies)[:20]
        return candidate

    @staticmethod
    def _to_candidate(item: dict) -> RepoCandidate:
        license_info = item.get("license") or {}
        full_name = item.get("full_name", "")
        return RepoCandidate(
            host="github",
            full_name=full_name,
            html_url=item.get("html_url") or f"https://github.com/{full_name}",
            description=item.get("description") or "",
            stars=int(item.get("stargazers_count") or 0),
            forks=int(item.get("forks_count") or 0),
            language=item.get("language") or "",
            license=license_info.get("spdx_id") or license_info.get("name") or "",
            topics=list(item.get("topics") or []),
            updated_at=item.get("updated_at") or "",
            default_branch=item.get("default_branch") or "main",
        )


class GiteeClient:
    api = "https://gitee.com/api/v5"

    def __init__(self, cache_dir: Path | None = None, timeout: int = 20):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})
        self.cache = _DiskCache(cache_dir or Path("data/cache/gitee"), ttl=1800)

    def _request(self, url: str, params: dict | None = None):
        key = f"{url}|{params}"
        cached = self.cache.get(key)
        if cached is not None:
            return cached
        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise CodeHostError(f"Gitee 请求失败：{exc}") from exc
        if response.status_code == 404:
            raise CodeHostError("Gitee 资源不存在（404）。")
        if response.status_code >= 400:
            raise CodeHostError(f"Gitee 返回 {response.status_code}：{response.text[:200]}")
        try:
            value = response.json()
        except ValueError as exc:
            raise CodeHostError("Gitee 返回了非 JSON 内容。") from exc
        self.cache.put(key, value)
        return value

    def search(self, query: str, per_page: int = 8) -> list[RepoCandidate]:
        clean = _sanitize_query(query)
        if not clean:
            return []
        data = self._request(
            f"{self.api}/search/repositories",
            params={"q": clean, "per_page": per_page, "sort": "stars_count", "order": "desc"},
        )
        if not isinstance(data, list):
            return []
        return [self._to_candidate(item) for item in data]

    def get_repo(self, full_name: str) -> RepoCandidate:
        data = self._request(f"{self.api}/repos/{full_name}")
        return self._to_candidate(data)

    def get_readme(self, full_name: str) -> str:
        try:
            data = self._request(f"{self.api}/repos/{full_name}/readme")
        except CodeHostError:
            return ""
        content = data.get("content") or ""
        try:
            return base64.b64decode(content).decode("utf-8", errors="replace")[:40000]
        except (ValueError, TypeError):
            return ""

    def enrich(self, candidate: RepoCandidate, include_manifests: bool = True) -> RepoCandidate:
        try:
            candidate = self.get_repo(candidate.full_name)
        except CodeHostError:
            pass
        candidate.host = "gitee"
        candidate.html_url = candidate.html_url or f"https://gitee.com/{candidate.full_name}"
        candidate.readme = self.get_readme(candidate.full_name)
        if include_manifests and candidate.default_branch:
            candidate.manifests = []
            candidate.dependencies = []
            for name in MANIFEST_NAMES[:8]:
                url = f"https://gitee.com/{candidate.full_name}/raw/{candidate.default_branch}/{name}"
                try:
                    response = self.session.get(url, timeout=self.timeout)
                except requests.RequestException:
                    continue
                if response.status_code >= 400:
                    continue
                candidate.manifests.append(name)
                candidate.dependencies.extend(parse_dependencies(name, response.text[:40000]))
                if len(candidate.manifests) >= 3:
                    break
            candidate.dependencies = _dedupe(candidate.dependencies)[:20]
        return candidate

    @staticmethod
    def _to_candidate(item: dict) -> RepoCandidate:
        license_info = item.get("license") or {}
        full_name = item.get("full_name") or item.get("path") or ""
        return RepoCandidate(
            host="gitee",
            full_name=full_name,
            html_url=item.get("html_url") or f"https://gitee.com/{full_name}",
            description=item.get("description") or "",
            stars=int(item.get("stargazers_count") or 0),
            forks=int(item.get("forks_count") or 0),
            language=item.get("language") or "",
            license=license_info.get("name") or "",
            topics=list(item.get("topics") or []),
            updated_at=item.get("updated_at") or "",
            default_branch=item.get("default_branch") or "master",
        )


def _dedupe(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        key = value.lower()
        if not value or key in seen:
            continue
        seen.add(key)
        result.append(value)
    return result


def parse_dependencies(filename: str, text: str) -> list[str]:
    try:
        if filename == "package.json":
            data = json.loads(text)
            deps: list[str] = []
            for key in ("dependencies", "devDependencies", "peerDependencies"):
                section = data.get(key)
                if isinstance(section, dict):
                    deps.extend(section.keys())
            return _dedupe(deps)
        if filename == "requirements.txt":
            deps = []
            for line in text.splitlines():
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("-"):
                    continue
                name = re.split(r"[<>=!~;\[\s]", line, maxsplit=1)[0]
                if name:
                    deps.append(name)
            return _dedupe(deps)
        if filename == "Cargo.toml":
            return _toml_section_keys(text, "dependencies")
        if filename == "pyproject.toml":
            deps = _toml_section_keys(text, "tool.poetry.dependencies")
            match = re.search(r"dependencies\s*=\s*\[(.*?)\]", text, re.S)
            if match:
                for item in re.findall(r"[\"']([^\"']+)[\"']", match.group(1)):
                    name = re.split(r"[<>=!~\[]", item, maxsplit=1)[0]
                    deps.append(name)
            return _dedupe(deps)
        if filename == "go.mod":
            deps = []
            for line in text.splitlines():
                line = line.strip()
                if line.startswith("require "):
                    parts = line.split()
                    if len(parts) >= 2:
                        deps.append(parts[1].strip("()"))
                elif re.match(r"^[a-z0-9.\-]+\.[a-z]+/", line):
                    deps.append(line.split()[0])
            return _dedupe(deps)
        if filename == "pom.xml":
            return _dedupe(re.findall(r"<artifactId>([^<]+)</artifactId>", text))[:20]
        if filename == "build.gradle":
            return _dedupe(
                re.findall(r"(?:implementation|api|compileOnly)\s+['\"]([^'\"]+)['\"]", text)
            )[:20]
        if filename == "Dockerfile":
            return _dedupe(re.findall(r"^FROM\s+(\S+)", text, re.M))[:3]
    except (ValueError, TypeError):
        return []
    return []


def _toml_section_keys(text: str, section: str) -> list[str]:
    keys: list[str] = []
    active = False
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("[") and line.endswith("]"):
            active = line.strip("[]").strip() == section
            continue
        if not active or not line or line.startswith("#"):
            continue
        match = re.match(r"([A-Za-z0-9_.\-]+)\s*=", line)
        if match:
            keys.append(match.group(1))
    return _dedupe(keys)
