from __future__ import annotations

import hashlib
import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .models import AnalysisResult


class ProjectStore:
    def __init__(self, root: Path | str = Path("data/projects")):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.index_path = self.root / "index.json"
        self._lock = threading.Lock()

    def _safe_id(self, video_id: str) -> str:
        value = video_id.strip()
        if re.fullmatch(r"[A-Za-z0-9_-]{2,48}", value):
            return value
        return "v_" + hashlib.sha1(value.encode("utf-8")).hexdigest()[:16]

    def project_dir(self, video_id: str) -> Path:
        return self.root / self._safe_id(video_id)

    def save(
        self,
        result: AnalysisResult,
        payload: dict[str, Any] | None = None,
    ) -> Path:
        directory = self.project_dir(result.video.video_id)
        directory.mkdir(parents=True, exist_ok=True)
        (directory / "analysis.json").write_text(
            json.dumps(result.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (directory / "evidence.json").write_text(
            json.dumps(result.video.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        (directory / "brief.md").write_text(result.brief_md, encoding="utf-8")
        (directory / "agent_prompt.md").write_text(result.agent_prompt_md, encoding="utf-8")
        (directory / "candidates.json").write_text(
            json.dumps(
                [candidate.to_dict(include_readme=True) for candidate in result.candidates],
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        if payload is not None:
            # Cookie 只在本次请求内使用，不落盘。
            safe_payload = {
                key: value
                for key, value in payload.items()
                if key not in {"cookie", "media_url"}
            }
            (directory / "payload.json").write_text(
                json.dumps(safe_payload, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        self._upsert_index(result)
        return directory

    def load(self, video_id: str) -> dict[str, Any] | None:
        path = self.project_dir(video_id) / "analysis.json"
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

    def load_payload(self, video_id: str) -> dict[str, Any] | None:
        path = self.project_dir(video_id) / "payload.json"
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None

    def read_brief(self, video_id: str) -> str:
        path = self.project_dir(video_id) / "brief.md"
        if not path.exists():
            return ""
        return path.read_text(encoding="utf-8")

    def list(self) -> list[dict[str, Any]]:
        if not self.index_path.exists():
            return []
        try:
            data = json.loads(self.index_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return []
        return data if isinstance(data, list) else []

    def _upsert_index(self, result: AnalysisResult) -> None:
        with self._lock:
            entries = self.list()
            selected = result.selected
            entry = {
                "video_id": result.video.video_id,
                "title": result.video.title,
                "author": result.video.author,
                "url": result.video.url,
                "platform": result.video.platform,
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "selected_repo": selected.full_name if selected else "",
                "selected_url": selected.html_url if selected else "",
                "selected_score": selected.score if selected else 0,
                "llm_used": result.llm_used,
            }
            entries = [item for item in entries if item.get("video_id") != entry["video_id"]]
            entries.insert(0, entry)
            self.index_path.write_text(
                json.dumps(entries, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
