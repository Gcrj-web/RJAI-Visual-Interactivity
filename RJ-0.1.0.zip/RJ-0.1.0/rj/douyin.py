from __future__ import annotations

import os
import re
import uuid
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urljoin, urlparse

import requests

from .asr import (
    ASRConfig,
    ASRDependencyError,
    ASRError,
    asr_available,
    transcribe_media_file,
)
from .models import VideoEvidence


Progress = Callable[[str], None] | None
MAX_MEDIA_BYTES = 200 * 1024 * 1024
ALLOWED_MEDIA_HOSTS = (
    "douyinvod.com",
    "douyin.com",
    "douyinpic.com",
    "douyincdn.com",
    "byteimg.com",
    "ibytedtos.com",
    "bytecdn.cn",
    "zjcdn.com",
    "bytegoofy.com",
    "pstatp.com",
    "ixigua.com",
)


def media_host_allowed(url: str) -> bool:
    """只允许从抖音/字节 CDN 下载媒体，避免把页面数据当成任意 URL 代理。"""
    parsed = urlparse(str(url or ""))
    if parsed.scheme not in {"http", "https"}:
        return False
    host = (parsed.hostname or "").lower()
    if not host or host in {"localhost", "127.0.0.1", "::1"}:
        return False
    return any(host == allowed or host.endswith("." + allowed) for allowed in ALLOWED_MEDIA_HOSTS)


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value or "")[:80] or "douyin"


def download_media(
    url: str,
    video_id: str,
    audio_dir: Path,
    progress: Progress = None,
) -> Path:
    """下载抖音直链到临时文件；调用方负责在转写后删除。"""
    if not media_host_allowed(url):
        raise ValueError("抖音媒体地址不在允许的 CDN 域名内")

    session = requests.Session()
    session.trust_env = os.environ.get("RJ_USE_SYSTEM_PROXY", "").strip().lower() in {
        "1",
        "true",
        "yes",
    }
    headers = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/131.0.0.0 Safari/537.36"
        ),
        "Referer": "https://www.douyin.com/",
        "Accept": "*/*",
    }

    audio_dir.mkdir(parents=True, exist_ok=True)
    path = audio_dir / (
        f"{_safe_name(video_id)}-douyin-{uuid.uuid4().hex[:8]}.mp4"
    )
    current = url
    response = None
    try:
        for _ in range(4):
            if not media_host_allowed(current):
                raise ValueError("媒体重定向到了不允许的域名")
            response = session.get(
                current,
                headers=headers,
                stream=True,
                timeout=(15, 90),
                allow_redirects=False,
            )
            if response.status_code in {301, 302, 303, 307, 308}:
                location = response.headers.get("Location") or ""
                response.close()
                if not location:
                    raise ValueError("媒体重定向缺少 Location")
                current = urljoin(current, location)
                continue
            break
        else:
            raise ValueError("媒体重定向次数过多")

        if response is None:
            raise ValueError("没有拿到媒体响应")
        if response.status_code not in {200, 206}:
            raise ValueError(f"媒体下载 HTTP {response.status_code}")

        content_type = (response.headers.get("Content-Type") or "").lower()
        if "mpegurl" in content_type or current.lower().endswith(".m3u8"):
            raise ValueError("抖音返回的是 HLS 播放列表，当前只支持直链 MP4")
        if content_type.startswith("application/json"):
            raise ValueError("抖音返回了 JSON 而不是媒体文件")

        length = int(response.headers.get("Content-Length") or 0)
        if length > MAX_MEDIA_BYTES:
            raise ValueError("媒体文件超过 200MB 限制")

        total = 0
        with path.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=1 << 20):
                if not chunk:
                    continue
                total += len(chunk)
                if total > MAX_MEDIA_BYTES:
                    raise ValueError("媒体文件超过 200MB 限制")
                handle.write(chunk)
        if total < 10_000:
            raise ValueError("媒体文件过小")
        if progress:
            progress(f"抖音媒体已下载（{total / 1024 / 1024:.1f}MB），准备转写")
        return path
    except Exception:
        try:
            path.unlink()
        except OSError:
            pass
        raise
    finally:
        if response is not None:
            response.close()
        session.close()


def hydrate_evidence(
    video: VideoEvidence,
    payload: dict[str, Any],
    progress: Progress = None,
    enable_asr: bool = True,
) -> VideoEvidence:
    """抖音没有公开字幕接口；有直链时临时下载媒体并做本地 ASR。"""
    if video.subtitles:
        return video

    media_url = str(payload.get("media_url") or "").strip()
    if not media_url:
        video.warnings.append(
            "抖音没有公开字幕，也没有拿到视频直链；本次未做语音识别。"
        )
        return video
    if not enable_asr:
        video.warnings.append("ASR 已关闭，未生成抖音语音转写。")
        return video

    config = ASRConfig.from_env()
    if not config.enabled:
        video.warnings.append("ASR 已禁用（RJ_ASR_ENABLED=0），未生成抖音语音转写。")
        return video
    if not asr_available():
        video.warnings.append(
            "未安装 faster-whisper，跳过抖音语音识别。运行 "
            "`python -m pip install -r requirements-asr.txt` 后重启服务。"
        )
        return video

    media_path: Path | None = None
    try:
        if progress:
            progress("下载抖音媒体并准备语音识别")
        media_path = download_media(media_url, video.video_id, config.audio_dir, progress)
        if progress:
            progress("抖音视频语音识别")
        segments = transcribe_media_file(
            video.video_id,
            media_path,
            config=config,
            progress=progress,
            hints={
                "title": video.title,
                "description": video.description,
                "tags": video.tags,
                "chapters": [],
            },
        )
        if segments:
            video.subtitles = segments
            video.warnings = [
                warning
                for warning in video.warnings
                if "没有公开字幕" not in warning
                and "没有拿到抖音视频直链" not in warning
            ]
        else:
            video.warnings.append("抖音语音识别没有返回文字。")
    except (ASRDependencyError, ASRError) as exc:
        video.warnings.append(f"抖音 ASR 失败：{exc}")
    except Exception as exc:
        video.warnings.append(f"抖音媒体处理失败：{exc}")
    finally:
        if media_path is not None:
            try:
                media_path.unlink()
            except OSError:
                pass
    return video
