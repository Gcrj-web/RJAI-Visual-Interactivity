from __future__ import annotations

import base64
import json
import os
import re
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

import requests

from .frames import ExtractedFrame, extract_frames
from .models import VideoEvidence


Progress = Callable[[str], None] | None


class VisionError(RuntimeError):
    pass


def _truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class VisionConfig:
    enabled: bool = False
    provider: str = "openai"
    base_url: str = "https://api.openai.com/v1"
    api_key: str = ""
    model: str = ""
    timeout: int = 180
    max_frames: int = 8
    max_images: int = 1
    image_format: str = "data_url"
    max_width: int = 768
    jpeg_quality: int = 82

    @classmethod
    def from_env(cls) -> "VisionConfig":
        file_data: dict[str, Any] = {}
        config_path = Path(
            os.environ.get("RJ_VISION_CONFIG", "").strip() or "data/vision.json"
        )
        if config_path.exists():
            try:
                loaded = json.loads(config_path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    file_data = loaded
            except (OSError, json.JSONDecodeError):
                file_data = {}

        def value(env_key: str, file_key: str, default: str) -> str:
            env_value = os.environ.get(env_key)
            if env_value is not None and str(env_value).strip():
                return str(env_value).strip()
            file_value = file_data.get(file_key)
            if file_value is not None and str(file_value).strip():
                return str(file_value).strip()
            return default

        provider = value("RJ_VISION_PROVIDER", "provider", "openai").lower()
        if provider not in {"openai", "ollama"}:
            provider = "openai"
        default_base = (
            "http://127.0.0.1:11434"
            if provider == "ollama"
            else "https://api.openai.com/v1"
        )
        return cls(
            enabled=_truthy(value("RJ_VISION_ENABLED", "enabled", "0")),
            provider=provider,
            base_url=(
                value("RJ_VISION_BASE_URL", "base_url", "").rstrip("/")
                or default_base
            ),
            api_key=value("RJ_VISION_API_KEY", "api_key", ""),
            model=value("RJ_VISION_MODEL", "model", ""),
            timeout=int(value("RJ_VISION_TIMEOUT", "timeout", "180") or 180),
            max_frames=max(
                1, min(int(value("RJ_VISION_FRAMES", "max_frames", "8") or 8), 16)
            ),
            max_images=max(
                1,
                min(int(value("RJ_VISION_MAX_IMAGES", "max_images", "1") or 1), 8),
            ),
            image_format=(
                value("RJ_VISION_IMAGE_FORMAT", "image_format", "data_url").lower()
                if value("RJ_VISION_IMAGE_FORMAT", "image_format", "data_url").lower()
                in {"data_url", "base64"}
                else "data_url"
            ),
            max_width=max(
                320,
                min(int(value("RJ_VISION_MAX_WIDTH", "max_width", "768") or 768), 1600),
            ),
            jpeg_quality=max(
                40,
                min(
                    int(value("RJ_VISION_JPEG_QUALITY", "jpeg_quality", "82") or 82),
                    95,
                ),
            ),
        )

    def available(self) -> bool:
        has_credentials = self.provider == "ollama" or bool(self.api_key)
        return bool(self.enabled and self.model and has_credentials)

    def describe(self) -> dict[str, Any]:
        return {
            "available": self.available(),
            "enabled": self.enabled,
            "provider": self.provider,
            "base_url": self.base_url,
            "model": self.model,
            "frames": self.max_frames,
            "max_images": self.max_images,
            "image_format": self.image_format,
        }


def parse_vision_json(text: str) -> dict[str, Any]:
    """从模型输出中提取 JSON，兼容 ```json 代码块和前后说明。"""
    raw = str(text or "").strip()
    if not raw:
        raise VisionError("视觉模型返回了空内容")
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    start = raw.find("{")
    end = raw.rfind("}")
    if start < 0 or end <= start:
        raise VisionError("视觉模型没有返回 JSON 对象")
    try:
        data = json.loads(raw[start : end + 1])
    except json.JSONDecodeError as exc:
        raise VisionError(f"视觉模型 JSON 解析失败：{exc}") from exc
    if not isinstance(data, dict):
        raise VisionError("视觉模型返回的 JSON 不是对象")
    return data


def _as_list(value: Any, limit: int = 20) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()][:limit]
    if isinstance(value, str) and value.strip():
        return [value.strip()][:limit]
    return []


def _seconds(value: Any, fallback: float = 0.0) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value or "").strip()
    if not text:
        return fallback
    if re.fullmatch(r"\d+(?:\.\d+)?", text):
        return float(text)
    match = re.fullmatch(r"(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)", text)
    if match:
        hours = int(match.group(1) or 0)
        minutes = int(match.group(2) or 0)
        seconds = float(match.group(3) or 0)
        return hours * 3600 + minutes * 60 + seconds
    match = re.fullmatch(r"(\d+):(\d+(?:\.\d+)?)", text)
    if match:
        return int(match.group(1)) * 60 + float(match.group(2))
    return fallback


def _confidence(value: Any) -> str:
    text = str(value or "").strip().lower()
    if text in {"visible", "画面", "可见", "confirmed"}:
        return "visible"
    if text in {"unknown", "未知"}:
        return "unknown"
    return "inferred"


def normalize_vision_result(
    data: dict[str, Any],
    frames: list[ExtractedFrame],
    config: VisionConfig,
) -> dict[str, Any]:
    notes: list[dict[str, Any]] = []
    raw_notes = data.get("scene_notes") or data.get("frames") or []
    if isinstance(raw_notes, dict):
        raw_notes = [raw_notes]
    if isinstance(raw_notes, list):
        for index, item in enumerate(raw_notes[:16]):
            fallback_time = frames[index].time if index < len(frames) else 0.0
            if isinstance(item, dict):
                observation = str(
                    item.get("observation")
                    or item.get("description")
                    or item.get("text")
                    or ""
                ).strip()
                if not observation:
                    continue
                notes.append(
                    {
                        "time": _seconds(
                            item.get("time", item.get("timestamp")), fallback_time
                        ),
                        "observation": observation,
                        "confidence": _confidence(
                            item.get("confidence", item.get("source"))
                        ),
                    }
                )
            elif isinstance(item, str) and item.strip():
                notes.append(
                    {
                        "time": round(fallback_time, 3),
                        "observation": item.strip(),
                        "confidence": "inferred",
                    }
                )

    return {
        "summary": str(data.get("summary") or "").strip(),
        "people": _as_list(data.get("people")),
        "objects": _as_list(data.get("objects")),
        "actions": _as_list(data.get("actions")),
        "emotion": _as_list(data.get("emotion")),
        "screen_text": _as_list(data.get("screen_text") or data.get("text_on_screen")),
        "scene_notes": notes,
        "uncertainties": _as_list(data.get("uncertainties")),
        "frames": [
            {"time": round(frame.time, 3), "width": frame.width, "height": frame.height}
            for frame in frames
        ],
        "provider": config.provider,
        "model": config.model,
    }


def merge_vision_results(
    results: list[dict[str, Any]],
    frames: list[ExtractedFrame],
    config: VisionConfig,
    errors: list[str] | None = None,
) -> dict[str, Any]:
    merged: dict[str, Any] = {
        "summary": "",
        "people": [],
        "objects": [],
        "actions": [],
        "emotion": [],
        "screen_text": [],
        "scene_notes": [],
        "uncertainties": [],
        "frames": [
            {"time": round(frame.time, 3), "width": frame.width, "height": frame.height}
            for frame in frames
        ],
        "provider": config.provider,
        "model": config.model,
    }
    summaries: list[str] = []
    for result in results:
        summary = str(result.get("summary") or "").strip()
        if summary:
            summaries.append(summary)
        for key in (
            "people",
            "objects",
            "actions",
            "emotion",
            "screen_text",
            "uncertainties",
        ):
            current = merged[key]
            for value in result.get(key) or []:
                text = str(value).strip()
                if text and text not in current:
                    current.append(text)
        for note in result.get("scene_notes") or []:
            if not isinstance(note, dict):
                continue
            observation = str(note.get("observation") or "").strip()
            if not observation:
                continue
            key = (round(float(note.get("time") or 0), 2), observation)
            if any(
                (round(float(existing.get("time") or 0), 2), existing.get("observation"))
                == key
                for existing in merged["scene_notes"]
            ):
                continue
            merged["scene_notes"].append(note)
    merged["summary"] = "；".join(dict.fromkeys(summaries))[:1600]
    merged["scene_notes"].sort(key=lambda item: float(item.get("time") or 0))
    if errors:
        merged["uncertainties"].extend(errors)
    return merged


def _prompt(context: dict[str, Any], frames: list[ExtractedFrame]) -> str:
    times = ", ".join(f"{frame.time:.1f}s" for frame in frames)
    tags = "、".join(str(item) for item in context.get("tags") or [])
    return "\n".join(
        [
            "你是严谨的视频画面分析助手。下面是从同一段视频按时间顺序抽取的关键帧。",
            f"关键帧时间戳：{times}",
            f"平台：{context.get('platform') or '未知'}",
            f"标题：{context.get('title') or ''}",
            f"简介：{context.get('description') or ''}",
            f"标签：{tags}",
            "",
            "请只根据画面作答，不要根据标题猜测画面里没有出现的内容。",
            "如果画面是动漫/影视，关注可见人物特征、动作、表情、镜头和场景；",
            "如果是硬件/教程，关注可见器件、接线、界面文字和操作步骤。",
            "人物身份无法确认时写“未知”，不要编造角色名、作品名或台词。",
            "严格区分直接可见（visible）、合理推断（inferred）和未知（unknown）。",
            "",
            "只输出一个 JSON 对象，不要 Markdown，不要解释：",
            "{",
            '  "summary": "一句话概括画面内容",',
            '  "people": ["可见人物/角色；无法确认身份就写未知"],',
            '  "objects": ["可见物体、器件或场景元素"],',
            '  "actions": ["可见动作或事件"],',
            '  "emotion": ["可见的表情、氛围或情绪线索"],',
            '  "screen_text": ["画面中可读的文字、字幕或界面标签"],',
            '  "scene_notes": [',
            '    {"time": 12.3, "observation": "这一帧可见什么", "confidence": "visible|inferred|unknown"}',
            "  ],",
            '  "uncertainties": ["无法确认的内容"]',
            "}",
        ]
    )


class VisionClient:
    def __init__(self, config: VisionConfig):
        self.config = config

    def _session(self) -> requests.Session:
        session = requests.Session()
        session.trust_env = _truthy(os.environ.get("RJ_USE_SYSTEM_PROXY"))
        return session

    def _openai_analyze(self, prompt: str, images: list[str]) -> str:
        content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        for image in images:
            image_url = (
                f"data:image/jpeg;base64,{image}"
                if self.config.image_format == "data_url"
                else image
            )
            content.append(
                {
                    "type": "image_url",
                    "image_url": {"url": image_url},
                }
            )
        headers = {"Content-Type": "application/json"}
        if self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        payload = {
            "model": self.config.model,
            "messages": [
                {
                    "role": "system",
                    "content": "你是视频画面分析助手，只输出合法 JSON。",
                },
                {"role": "user", "content": content},
            ],
            "temperature": 0.1,
            "max_tokens": 2200,
            "stream": False,
        }
        url = f"{self.config.base_url}/chat/completions"
        session = self._session()
        try:
            response = session.post(
                url, headers=headers, json=payload, timeout=self.config.timeout
            )
        except requests.RequestException as exc:
            raise VisionError(f"视觉模型请求失败：{exc}") from exc
        finally:
            session.close()
        if response.status_code >= 400:
            raise VisionError(
                f"视觉模型返回 HTTP {response.status_code}: {response.text[:300]}"
            )
        try:
            data = response.json()
            content_value = data["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise VisionError("视觉模型返回格式不符合 OpenAI Chat Completions") from exc
        if isinstance(content_value, list):
            content_value = "".join(
                str(item.get("text") or "")
                for item in content_value
                if isinstance(item, dict)
            )
        if not isinstance(content_value, str) or not content_value.strip():
            raise VisionError("视觉模型返回了空内容")
        return content_value.strip()

    def _ollama_analyze(self, prompt: str, images: list[str]) -> str:
        payload = {
            "model": self.config.model,
            "messages": [
                {
                    "role": "user",
                    "content": prompt,
                    "images": images,
                }
            ],
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.1, "num_predict": 2200},
        }
        url = f"{self.config.base_url}/api/chat"
        session = self._session()
        try:
            response = session.post(url, json=payload, timeout=self.config.timeout)
        except requests.RequestException as exc:
            raise VisionError(f"本地视觉模型请求失败：{exc}") from exc
        finally:
            session.close()
        if response.status_code >= 400:
            raise VisionError(
                f"本地视觉模型返回 HTTP {response.status_code}: {response.text[:300]}"
            )
        try:
            data = response.json()
            content = data["message"]["content"]
        except (ValueError, KeyError, TypeError) as exc:
            raise VisionError("Ollama 返回格式不符合预期") from exc
        if not isinstance(content, str) or not content.strip():
            raise VisionError("本地视觉模型返回了空内容")
        return content.strip()

    def _analyze_chunk(
        self, frames: list[ExtractedFrame], context: dict[str, Any]
    ) -> dict[str, Any]:
        images = [
            base64.b64encode(frame.path.read_bytes()).decode("ascii")
            for frame in frames
        ]
        prompt = _prompt(context, frames)
        text = (
            self._ollama_analyze(prompt, images)
            if self.config.provider == "ollama"
            else self._openai_analyze(prompt, images)
        )
        return normalize_vision_result(parse_vision_json(text), frames, self.config)

    def analyze(
        self, frames: list[ExtractedFrame], context: dict[str, Any]
    ) -> dict[str, Any]:
        if not frames:
            raise VisionError("没有关键帧可发送")
        if not self.config.available():
            raise VisionError(
                "视觉模型未配置完整：需要 RJ_VISION_ENABLED=1、RJ_VISION_MODEL，"
                "云端还需要 RJ_VISION_API_KEY。"
            )
        limit = max(1, min(int(self.config.max_images or 1), 8))
        chunks = [frames[index : index + limit] for index in range(0, len(frames), limit)]
        results: list[dict[str, Any]] = []
        errors: list[str] = []
        for index, chunk in enumerate(chunks):
            try:
                results.append(self._analyze_chunk(chunk, context))
            except Exception as exc:
                errors.append(f"第 {index + 1} 组关键帧分析失败：{exc}")
        if not results:
            raise VisionError("；".join(errors) or "视觉模型没有返回结果")
        return merge_vision_results(results, frames, self.config, errors)


def _safe_temp_dir(root: Path, video_id: str) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", video_id or "video")[:60]
    path = root / f"{safe}-{uuid.uuid4().hex[:8]}"
    path.mkdir(parents=True, exist_ok=False)
    return path


def enrich_video_vision(
    video: VideoEvidence,
    payload: dict[str, Any],
    progress: Progress = None,
) -> VideoEvidence:
    """下载低码率视频到临时目录，抽帧并调用视觉模型；结束后删除媒体和帧。"""
    config = VisionConfig.from_env()
    if not config.enabled:
        return video
    if not config.available():
        video.warnings.append(
            "视觉模型已启用但配置不完整：请设置 RJ_VISION_MODEL 和 "
            "RJ_VISION_API_KEY（Ollama 可不需要 Key）。"
        )
        return video

    cache_root = Path("data/cache/vision")
    temp_dir: Path | None = None
    media_path: Path | None = None
    try:
        temp_dir = _safe_temp_dir(cache_root, video.video_id)
        if progress:
            progress("下载视频用于关键帧分析")

        if video.platform == "douyin":
            from .douyin import download_media

            media_url = str(payload.get("media_url") or "").strip()
            if not media_url:
                video.warnings.append("视觉分析跳过：没有拿到抖音视频直链。")
                return video
            media_path = download_media(
                media_url, video.video_id, temp_dir, progress
            )
        elif video.platform == "bilibili":
            from .bilibili import BilibiliClient, load_cookie

            client = BilibiliClient(cookie=payload.get("cookie") or load_cookie())
            urls = client.get_video_urls(
                int(video.aid), int(video.cid), video.video_id
            )
            media_path = temp_dir / "video.mp4"
            client.download_stream(
                urls,
                media_path,
                referer=f"https://www.bilibili.com/video/{video.video_id}/",
                max_bytes=200 * 1024 * 1024,
            )
        else:
            video.warnings.append(f"视觉分析暂不支持平台：{video.platform}")
            return video

        if progress:
            progress("抽取关键帧")
        frames = extract_frames(
            media_path,
            duration=video.duration,
            count=config.max_frames,
            max_width=config.max_width,
            jpeg_quality=config.jpeg_quality,
            output_dir=temp_dir / "frames",
        )

        if progress:
            progress(f"调用视觉模型（{config.model}）")
        client = VisionClient(config)
        result = client.analyze(
            frames,
            {
                "platform": video.platform,
                "title": video.title,
                "description": video.description,
                "tags": video.tags,
                "duration": video.duration,
            },
        )
        video.visual_analysis = result
        video.warnings = [
            warning
            for warning in video.warnings
            if "没有接入视觉模型" not in warning
        ]
    except Exception as exc:
        video.warnings.append(f"画面分析失败：{exc}")
    finally:
        if temp_dir is not None:
            shutil.rmtree(temp_dir, ignore_errors=True)
    return video
