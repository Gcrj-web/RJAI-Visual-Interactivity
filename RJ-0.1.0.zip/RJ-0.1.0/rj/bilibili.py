from __future__ import annotations

import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import quote, urlparse

import requests

from .models import Chapter, Comment, SubtitleSegment, VideoEvidence


BILI_API = "https://api.bilibili.com"
MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35,
    27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13,
    37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4,
    22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52,
]


class BilibiliError(RuntimeError):
    pass


def load_cookie() -> str:
    env = os.environ.get("BILIBILI_COOKIE", "").strip()
    if env:
        return env
    path = Path("data/bilibili_cookie.txt")
    if path.exists():
        return path.read_text(encoding="utf-8", errors="ignore").strip()
    return ""


class BilibiliClient:
    def __init__(self, cookie: str = "", timeout: int = 20):
        self.cookie = cookie
        self.timeout = timeout
        self.session = requests.Session()
        # 默认直连，避免继承桌面环境里已经失效的 Clash/系统代理。
        # 确实需要代理时设置 RJ_USE_SYSTEM_PROXY=1。
        self.session.trust_env = (
            os.environ.get("RJ_USE_SYSTEM_PROXY", "0").strip().lower()
            in {"1", "true", "yes", "on"}
        )
        self.session.headers.update(
            {
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/126.0.0.0 Safari/537.36"
                ),
                "Referer": "https://www.bilibili.com/",
                "Accept": "application/json, text/plain, */*",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.5",
                "Origin": "https://www.bilibili.com",
                "Sec-Fetch-Site": "same-site",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Dest": "empty",
                "sec-ch-ua": (
                    '"Chromium";v="126", "Google Chrome";v="126", '
                    '"Not-A.Brand";v="99"'
                ),
                "sec-ch-ua-mobile": "?0",
                "sec-ch-ua-platform": '"Windows"',
            }
        )
        if cookie:
            self.session.headers["Cookie"] = cookie
        self._wbi_mixin: str | None = None
        self._wbi_time = 0.0
        self._player_cache: dict[tuple[int, int], dict[str, Any]] = {}

    def _get(self, url: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
        except requests.RequestException as exc:
            raise BilibiliError(f"B 站请求失败：{exc}") from exc
        if response.status_code >= 400:
            raise BilibiliError(f"B 站返回 HTTP {response.status_code}")
        try:
            data = response.json()
        except ValueError as exc:
            raise BilibiliError("B 站返回了非 JSON 内容，可能触发了风控。") from exc
        return data

    def _get_wbi_mixin(self) -> str:
        if self._wbi_mixin and time.time() - self._wbi_time < 3600:
            return self._wbi_mixin
        data = self._get(f"{BILI_API}/x/web-interface/nav")
        wbi = (data.get("data") or {}).get("wbi_img") or {}
        img_url = wbi.get("img_url") or ""
        sub_url = wbi.get("sub_url") or ""
        img_key = img_url.rsplit("/", 1)[-1].split(".")[0]
        sub_key = sub_url.rsplit("/", 1)[-1].split(".")[0]
        if not img_key or not sub_key:
            raise BilibiliError("无法获取 B 站 WBI 签名密钥。")
        raw = img_key + sub_key
        mixin = "".join(raw[index] for index in MIXIN_KEY_ENC_TAB if index < len(raw))[:32]
        self._wbi_mixin = mixin
        self._wbi_time = time.time()
        return mixin

    def _sign(self, params: dict[str, Any]) -> dict[str, Any]:
        mixin = self._get_wbi_mixin()
        signed = {k: v for k, v in params.items() if v is not None}
        signed["wts"] = int(time.time())
        query = "&".join(
            f"{quote(str(key), safe='')}={quote(str(value), safe='')}"
            for key, value in sorted(signed.items())
        )
        query = re.sub(r"[!'()*]", "", query)
        signed["w_rid"] = hashlib.md5((query + mixin).encode("utf-8")).hexdigest()
        return signed

    def get_view(self, bvid: str) -> dict[str, Any]:
        self.session.headers["Referer"] = f"https://www.bilibili.com/video/{bvid}/"
        data = self._get(f"{BILI_API}/x/web-interface/view", {"bvid": bvid})
        if data.get("code") != 0:
            raise BilibiliError(f"获取视频信息失败：{data.get('message')} ({data.get('code')})")
        return data["data"]

    def get_tags(self, bvid: str) -> list[str]:
        try:
            data = self._get(f"{BILI_API}/x/tag/archive/tags", {"bvid": bvid})
        except BilibiliError:
            return []
        if data.get("code") != 0:
            return []
        return [item.get("tag_name", "") for item in data.get("data") or [] if item.get("tag_name")]

    def get_comments(self, aid: int, limit: int = 20) -> list[Comment]:
        try:
            data = self._get(
                f"{BILI_API}/x/v2/reply",
                {"type": 1, "oid": aid, "sort": 2, "ps": limit, "pn": 1},
            )
        except BilibiliError:
            return []
        if data.get("code") != 0:
            return []
        payload = data.get("data") or {}
        comments: list[Comment] = []
        top = payload.get("top") or {}
        for key in ("upper", "admin"):
            item = top.get(key)
            if item:
                comments.append(self._to_comment(item, pinned=True))
        for item in payload.get("replies") or []:
            comments.append(self._to_comment(item))
            for sub in (item.get("replies") or [])[:2]:
                comments.append(self._to_comment(sub))
        unique: list[Comment] = []
        seen: set[str] = set()
        for comment in comments:
            key = f"{comment.author}|{comment.text}"
            if key in seen or not comment.text:
                continue
            seen.add(key)
            unique.append(comment)
        return unique[:limit]

    @staticmethod
    def _to_comment(item: dict[str, Any], pinned: bool = False) -> Comment:
        member = item.get("member") or {}
        content = item.get("content") or {}
        return Comment(
            author=member.get("uname") or "",
            text=(content.get("message") or "").strip(),
            likes=int(item.get("like") or 0),
            pinned=pinned,
        )

    def get_player_data(self, aid: int, cid: int, bvid: str) -> dict[str, Any]:
        cache_key = (aid, cid)
        if cache_key in self._player_cache:
            return self._player_cache[cache_key]
        self.session.headers["Referer"] = f"https://www.bilibili.com/video/{bvid}/"
        params = {"aid": aid, "cid": cid, "bvid": bvid}
        signed = self._sign(params)
        data = self._get(f"{BILI_API}/x/player/wbi/v2", signed)
        if data.get("code") != 0:
            data = self._get(f"{BILI_API}/x/player/v2", signed)
        if data.get("code") != 0:
            raise BilibiliError(f"获取播放器信息失败：{data.get('message')} ({data.get('code')})")
        payload = data.get("data") or {}
        self._player_cache[cache_key] = payload
        return payload

    def get_subtitles(self, aid: int, cid: int, bvid: str) -> list[SubtitleSegment]:
        player = self.get_player_data(aid, cid, bvid)
        subtitle_info = player.get("subtitle") or {}
        tracks = subtitle_info.get("subtitles") or []
        ai_track = subtitle_info.get("ai_subtitle")
        if isinstance(ai_track, dict) and ai_track.get("subtitle_url"):
            tracks = [ai_track] + list(tracks)
        if not tracks:
            return []
        preferred = sorted(
            tracks,
            key=lambda item: (
                0 if str(item.get("lan", "")).lower().startswith("zh") else 1,
                0 if "ai" in str(item.get("lan", "")).lower() else 1,
            ),
        )
        for track in preferred:
            url = track.get("subtitle_url") or ""
            if not url:
                continue
            if url.startswith("//"):
                url = "https:" + url
            try:
                response = self.session.get(url, timeout=self.timeout)
                payload = response.json()
            except (requests.RequestException, ValueError):
                continue
            segments: list[SubtitleSegment] = []
            for item in payload.get("body") or []:
                text = (item.get("content") or "").strip()
                if not text:
                    continue
                segments.append(
                    SubtitleSegment(
                        start=float(item.get("from") or 0),
                        end=float(item.get("to") or 0),
                        text=text,
                        source="cc",
                    )
                )
            if segments:
                return segments
        return []

    def get_chapters(self, aid: int, cid: int, bvid: str) -> list[Chapter]:
        try:
            player = self.get_player_data(aid, cid, bvid)
        except BilibiliError:
            return []
        chapters: list[Chapter] = []
        for item in player.get("view_points") or []:
            chapters.append(
                Chapter(
                    title=str(item.get("content") or "").strip(),
                    start=float(item.get("from") or 0),
                )
            )
        return [c for c in chapters if c.title]

    def get_audio_urls(self, aid: int, cid: int, bvid: str) -> list[str]:
        self.session.headers["Referer"] = f"https://www.bilibili.com/video/{bvid}/"
        params = {
            "avid": aid,
            "cid": cid,
            "bvid": bvid,
            "fnval": 16,
            "fnver": 0,
            "fourk": 1,
        }
        signed = self._sign(params)
        data = self._get(f"{BILI_API}/x/player/wbi/playurl", signed)
        if data.get("code") != 0:
            data = self._get(f"{BILI_API}/x/player/playurl", signed)
        if data.get("code") != 0:
            raise BilibiliError(
                f"获取音频流失败：{data.get('message')} ({data.get('code')})"
            )
        urls = pick_audio_urls(data.get("data") or {})
        if not urls:
            raise BilibiliError(
                "播放器没有返回独立音频流；为避免缓存整段视频，未回退到 durl。"
            )
        return urls

    def get_audio_url(self, aid: int, cid: int, bvid: str) -> str:
        return self.get_audio_urls(aid, cid, bvid)[0]

    def get_video_urls(
        self, aid: int, cid: int, bvid: str, max_height: int = 480
    ) -> list[str]:
        """取视频流候选；优先 480p 以下，减少抽帧时的临时下载量。"""
        self.session.headers["Referer"] = f"https://www.bilibili.com/video/{bvid}/"
        params = {
            "avid": aid,
            "cid": cid,
            "bvid": bvid,
            "fnval": 16,
            "fnver": 0,
            "fourk": 1,
        }
        signed = self._sign(params)
        data = self._get(f"{BILI_API}/x/player/wbi/playurl", signed)
        if data.get("code") != 0:
            data = self._get(f"{BILI_API}/x/player/playurl", signed)
        if data.get("code") != 0:
            raise BilibiliError(
                f"获取视频流失败：{data.get('message')} ({data.get('code')})"
            )

        payload = data.get("data") or {}
        dash = payload.get("dash") or {}
        candidates: list[tuple[int, int, int, str]] = []
        for item in dash.get("video") or []:
            if not isinstance(item, dict):
                continue
            height = int(item.get("height") or 0)
            bandwidth = int(item.get("bandwidth") or 0)
            urls = [item.get("baseUrl") or item.get("base_url") or ""]
            backups = item.get("backupUrl") or item.get("backup_url") or []
            if isinstance(backups, str):
                backups = [backups]
            urls.extend(backups)
            for url in urls:
                normalized = _normalize_stream_url(url)
                if normalized:
                    candidates.append(
                        (
                            0 if height and height <= max_height else 1,
                            height or 99999,
                            bandwidth,
                            normalized,
                        )
                    )
        if candidates:
            result: list[str] = []
            seen: set[str] = set()
            for _, _, _, url in sorted(candidates):
                if url in seen:
                    continue
                seen.add(url)
                result.append(url)
            return result

        durl_urls = [
            _normalize_stream_url(item.get("url") or "")
            for item in payload.get("durl") or []
            if isinstance(item, dict) and item.get("url")
        ]
        durl_urls = [url for url in durl_urls if url]
        if durl_urls:
            return durl_urls
        raise BilibiliError("播放器没有返回可下载的视频流。")

    def download_stream(
        self,
        url: str | list[str],
        dest: Path | str,
        referer: str = "",
        max_bytes: int = 200 * 1024 * 1024,
    ) -> Path:
        path = Path(dest)
        path.parent.mkdir(parents=True, exist_ok=True)
        headers = {"Referer": referer} if referer else {}
        candidates = [url] if isinstance(url, str) else list(url)
        errors: list[str] = []
        for candidate in candidates:
            if not candidate:
                continue
            try:
                with self.session.get(
                    candidate, headers=headers, stream=True, timeout=30
                ) as response:
                    if response.status_code >= 400:
                        errors.append(f"HTTP {response.status_code}")
                        continue
                    total = 0
                    too_large = False
                    with path.open("wb") as handle:
                        for chunk in response.iter_content(chunk_size=1 << 20):
                            if chunk:
                                handle.write(chunk)
                                total += len(chunk)
                                if total > max_bytes:
                                    too_large = True
                                    break
                    if too_large:
                        errors.append("文件超过大小限制")
                        continue
                if total >= 10_000:
                    return path
                errors.append("文件过小")
            except requests.RequestException as exc:
                errors.append(_short_error(exc))
        try:
            path.unlink()
        except OSError:
            pass
        detail = "；".join(errors[-3:]) or "没有可用媒体地址"
        raise BilibiliError(
            f"下载媒体失败：所有候选 CDN 均失败（{detail}）。"
            "如果开启了代理，尝试关闭代理后重启服务。"
        )

    def download_audio(
        self,
        url: str | list[str],
        dest: Path | str,
        referer: str = "",
    ) -> Path:
        return self.download_stream(url, dest, referer=referer)

    def fetch_evidence(self, bvid: str, include_comments: bool = True) -> VideoEvidence:
        view = self.get_view(bvid)
        aid = int(view.get("aid") or 0)
        cid = int(view.get("cid") or 0)
        pages = view.get("pages") or []
        warnings: list[str] = []
        if len(pages) > 1:
            warnings.append(f"该视频有 {len(pages)} 个分P，当前只分析第 1 P。")

        tags = self.get_tags(bvid)
        subtitles: list[SubtitleSegment] = []
        try:
            subtitles = self.get_subtitles(aid, cid, bvid)
        except BilibiliError as exc:
            warnings.append(str(exc))
        if not subtitles:
            warnings.append(
                "没有拿到字幕。可在 data/bilibili_cookie.txt 放入登录后的 Cookie，"
                "或后续接入本地 ASR。"
            )

        comments = self.get_comments(aid) if include_comments else []
        chapters = self.get_chapters(aid, cid, bvid)
        owner = view.get("owner") or {}

        return VideoEvidence(
            platform="bilibili",
            video_id=view.get("bvid") or bvid,
            url=f"https://www.bilibili.com/video/{view.get('bvid') or bvid}/",
            title=view.get("title") or "",
            description=view.get("desc") or "",
            author=owner.get("name") or "",
            author_id=str(owner.get("mid") or ""),
            aid=aid,
            cid=cid,
            tags=tags,
            duration=float(view.get("duration") or 0),
            pubdate=int(view.get("pubdate") or 0),
            chapters=chapters,
            subtitles=subtitles,
            comments=comments,
            warnings=warnings,
            fetched_at=datetime.now(timezone.utc).isoformat(),
        )


def parse_bvid(value: str) -> str:
    match = re.search(r"(BV[0-9A-Za-z]{8,14})", value or "")
    if not match:
        raise BilibiliError(f"无法从 {value!r} 中解析 BV 号。")
    return match.group(1)


def _normalize_stream_url(url: str) -> str:
    value = (url or "").strip()
    if value.startswith("//"):
        return "https:" + value
    if value.startswith("http://"):
        return "https://" + value[7:]
    return value


def _short_error(exc: Exception, limit: int = 220) -> str:
    text = str(exc)
    text = re.sub(
        r"https?://[^\s)]+",
        lambda match: match.group(0).split("?", 1)[0] + "?…",
        text,
    )
    return text[:limit]


def _audio_host_rank(url: str) -> int:
    host = (urlparse(url).hostname or "").lower()
    # 主 CDN 通常比第三方 PCDN 稳；PCDN 的 TLS 连接更容易被中断。
    if host.endswith("bilivideo.com") and "mcdn" not in host:
        return 0
    if host.endswith("bilivideo.cn") or "mcdn" in host:
        return 1
    return 2


def pick_audio_urls(data: dict[str, Any]) -> list[str]:
    """返回独立 DASH 音频的候选地址，按可靠性排序；不回退到 durl。"""
    dash = data.get("dash") or {}
    audios = dash.get("audio") or []
    candidates: list[tuple[int, int, str]] = []
    if isinstance(audios, list):
        for audio in audios:
            if not isinstance(audio, dict):
                continue
            bandwidth = int(audio.get("bandwidth") or 0)
            urls = [audio.get("baseUrl") or audio.get("base_url") or ""]
            backups = audio.get("backupUrl") or audio.get("backup_url") or []
            if isinstance(backups, str):
                backups = [backups]
            urls.extend(backups)
            for url in urls:
                normalized = _normalize_stream_url(url)
                if not normalized:
                    continue
                candidates.append(
                    (_audio_host_rank(normalized), -bandwidth, normalized)
                )
    result: list[str] = []
    seen: set[str] = set()
    for _, _, url in sorted(candidates):
        if url in seen:
            continue
        seen.add(url)
        result.append(url)
    return result


def pick_audio_url(data: dict[str, Any]) -> str:
    urls = pick_audio_urls(data)
    return urls[0] if urls else ""


def evidence_from_payload(payload: dict[str, Any]) -> VideoEvidence:
    """把浏览器扩展传来的 JSON 归一化成 VideoEvidence。"""
    subtitles: list[SubtitleSegment] = []
    for item in payload.get("subtitles") or []:
        text = str(item.get("text") or "").strip()
        if not text:
            continue
        subtitles.append(
            SubtitleSegment(
                start=float(item.get("start") or item.get("from") or 0),
                end=float(item.get("end") or item.get("to") or 0),
                text=text,
                source=str(item.get("source") or "cc"),
            )
        )
    comments = [
        Comment(
            author=str(item.get("author") or ""),
            text=str(item.get("text") or "").strip(),
            likes=int(item.get("likes") or 0),
            pinned=bool(item.get("pinned")),
        )
        for item in payload.get("comments") or []
        if str(item.get("text") or "").strip()
    ]
    chapters = [
        Chapter(title=str(item.get("title") or ""), start=float(item.get("start") or 0))
        for item in payload.get("chapters") or []
        if item.get("title")
    ]
    platform = str(payload.get("platform") or "bilibili").strip().lower()
    video_id = str(payload.get("video_id") or payload.get("bvid") or "").strip()
    if not video_id:
        if platform == "douyin":
            video_id = "douyin"
        else:
            video_id = parse_bvid(str(payload.get("url") or ""))
    default_url = (
        f"https://www.douyin.com/video/{video_id}"
        if platform == "douyin"
        else f"https://www.bilibili.com/video/{video_id}/"
    )
    warnings = [str(item) for item in payload.get("warnings") or []]
    return VideoEvidence(
        platform=platform,
        video_id=video_id,
        url=str(payload.get("url") or default_url),
        title=str(payload.get("title") or "").strip(),
        description=str(payload.get("description") or "").strip(),
        author=str(payload.get("author") or "").strip(),
        author_id=str(payload.get("author_id") or "").strip(),
        aid=int(payload.get("aid") or 0),
        cid=int(payload.get("cid") or 0),
        tags=[str(item).strip() for item in payload.get("tags") or [] if str(item).strip()],
        duration=float(payload.get("duration") or 0),
        pubdate=int(payload.get("pubdate") or 0),
        chapters=chapters,
        subtitles=subtitles,
        comments=comments,
        page_text=str(payload.get("page_text") or ""),
        warnings=warnings,
        fetched_at=str(payload.get("fetched_at") or datetime.now(timezone.utc).isoformat()),
    )


def _clear_subtitle_warnings(warnings: list[str]) -> list[str]:
    return [
        warning
        for warning in warnings
        if "没有字幕" not in warning
        and "没有拿到字幕" not in warning
        and "页面没有提供字幕" not in warning
    ]


def hydrate_evidence(
    video: VideoEvidence,
    payload: dict[str, Any],
    cookie: str = "",
    progress: Callable[[str], None] | None = None,
    enable_asr: bool = True,
) -> VideoEvidence:
    """补齐扩展拿不到的字幕/章节/评论；没有字幕时尝试本地 ASR。

    扩展运行在页面里，但播放器接口需要 WBI 签名；这里用 Python 端补一次。
    失败不阻断主流程，只记录提示。
    """
    if video.platform == "douyin":
        from .douyin import hydrate_evidence as hydrate_douyin

        return hydrate_douyin(
            video,
            payload,
            progress=progress,
            enable_asr=enable_asr,
        )
    if video.platform != "bilibili":
        return video
    effective_cookie = cookie or load_cookie()
    client = BilibiliClient(cookie=effective_cookie)
    aid = int(video.aid or payload.get("aid") or 0)
    cid = int(video.cid or payload.get("cid") or 0)
    if not aid or not cid:
        try:
            view = client.get_view(video.video_id)
            aid = int(view.get("aid") or 0)
            cid = int(view.get("cid") or 0)
            video.aid = aid
            video.cid = cid
        except BilibiliError as exc:
            video.warnings.append(f"无法获取 aid/cid：{exc}")
            return video

    if not video.subtitles:
        try:
            video.subtitles = client.get_subtitles(aid, cid, video.video_id)
            if video.subtitles:
                video.warnings = _clear_subtitle_warnings(video.warnings)
        except BilibiliError as exc:
            video.warnings.append(f"补取字幕失败：{exc}")

    # 章节标题对 ASR 的术语提示很有用，所以要在转写前补齐。
    if not video.chapters:
        try:
            video.chapters = client.get_chapters(aid, cid, video.video_id)
        except BilibiliError:
            pass

    if not video.subtitles and enable_asr:
        try:
            from .asr import ASRConfig, ASRDependencyError, ASRError, transcribe_bilibili

            config = ASRConfig.from_env()
            if not config.enabled:
                video.warnings.append("ASR 已禁用（RJ_ASR_ENABLED=0），未生成语音转写。")
            else:
                if progress:
                    progress("下载音频并做语音识别")
                video.subtitles = transcribe_bilibili(
                    video.video_id,
                    aid,
                    cid,
                    config=config,
                    progress=progress,
                    client=client,
                    hints={
                        "title": video.title,
                        "description": video.description,
                        "tags": video.tags,
                        "chapters": [
                            chapter.title for chapter in video.chapters if chapter.title
                        ],
                    },
                )
                if video.subtitles:
                    video.warnings = _clear_subtitle_warnings(video.warnings)
        except ASRDependencyError as exc:
            video.warnings.append(str(exc))
        except ASRError as exc:
            video.warnings.append(f"ASR 失败：{exc}")
        except Exception as exc:
            video.warnings.append(f"ASR 异常：{exc}")

    if not video.subtitles and not effective_cookie:
        video.warnings.append(
            "未读取到 B 站登录 Cookie；如果该视频有 AI 字幕，登录后重试通常比本地 ASR 更准确。"
        )
    if not video.comments:
        try:
            video.comments = client.get_comments(aid)
        except BilibiliError:
            pass
    return video
