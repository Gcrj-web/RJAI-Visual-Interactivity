from __future__ import annotations

import re
from collections import Counter, defaultdict
from urllib.parse import urlparse

from .models import Comment, ExtractedSignals, RepoMention, SignalTerm, SubtitleSegment, VideoEvidence


URL_RE = re.compile(r"https?://[^\s<>\"'）)\]】]+", re.IGNORECASE)
REPO_RE = re.compile(
    r"(?<![\w.-])(?:www\.)?(github\.com|gitee\.com)/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)
EN_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_+.#-]{1,40}")
CJK_RUN_RE = re.compile(r"[\u4e00-\u9fff]{2,}")
QUOTED_RE = re.compile(r"[《“\"']([^》”\"']{2,40})[》”\"']")

EN_STOPWORDS = {
    "the", "and", "for", "with", "this", "that", "you", "your", "from", "are",
    "was", "were", "have", "has", "had", "not", "but", "can", "could", "all",
    "any", "how", "what", "why", "when", "where", "who", "use", "used", "using",
    "make", "made", "new", "app", "apps", "demo", "video", "videos", "project",
    "projects", "github", "gitee", "code", "source", "open", "tutorial", "build",
    "builds", "simple", "easy", "free", "full", "more", "most", "very", "just",
    "will", "would", "should", "about", "into", "than", "then", "them", "they",
    "there", "here", "been", "being", "also", "only", "some", "such", "over",
    "under", "after", "before", "up", "down", "out", "off", "on", "in", "to",
    "of", "a", "an", "is", "it", "its", "as", "at", "by", "or", "if", "so",
    "we", "our", "my", "me", "i", "do", "does", "did", "get", "got", "one",
    "two", "three", "first", "last", "next", "now", "day", "days", "way",
    "like", "want", "need", "know", "see", "look", "think", "really",
}

CJK_STOPWORDS = {
    "这个", "那个", "一个", "我们", "你们", "他们", "自己", "可以", "就是",
    "但是", "因为", "所以", "如果", "然后", "现在", "怎么", "如何", "什么",
    "视频", "项目", "教程", "分享", "推荐", "开源", "免费", "今天", "大家",
    "非常", "真的", "其实", "已经", "没有", "不是", "这样", "那样", "一下",
    "进行", "使用", "需要", "功能", "效果", "东西", "时候", "问题", "方法",
}

# 这些词在技术视频里出现频率高，且对仓库检索很有区分度。
TECH_TERMS = {
    "python": "Python", "javascript": "JavaScript", "typescript": "TypeScript",
    "rust": "Rust", "golang": "Go", "java": "Java", "kotlin": "Kotlin",
    "swift": "Swift", "cpp": "C++", "c++": "C++", "csharp": "C#",
    "react": "React", "vue": "Vue", "nextjs": "Next.js", "next.js": "Next.js",
    "nuxt": "Nuxt", "nodejs": "Node.js", "node.js": "Node.js",
    "three.js": "Three.js", "django": "Django", "flask": "Flask",
    "fastapi": "FastAPI", "spring": "Spring", "electron": "Electron",
    "tauri": "Tauri", "flutter": "Flutter", "android": "Android",
    "ios": "iOS", "docker": "Docker", "kubernetes": "Kubernetes",
    "linux": "Linux", "ubuntu": "Ubuntu", "windows": "Windows",
    "esp32": "ESP32", "stm32": "STM32", "arduino": "Arduino",
    "raspberry": "Raspberry Pi", "ros2": "ROS2", "ros": "ROS",
    "opencv": "OpenCV", "pytorch": "PyTorch", "tensorflow": "TensorFlow",
    "whisper": "Whisper", "llm": "LLM", "rag": "RAG", "ollama": "Ollama",
    "langchain": "LangChain", "stable": "Stable Diffusion",
    "comfyui": "ComfyUI", "ffmpeg": "FFmpeg", "sqlite": "SQLite",
    "postgres": "PostgreSQL", "mysql": "MySQL", "redis": "Redis",
    "mongodb": "MongoDB", "graphql": "GraphQL", "grpc": "gRPC",
    "websocket": "WebSocket", "mqtt": "MQTT", "bluetooth": "Bluetooth",
    "opengl": "OpenGL", "unity": "Unity", "unreal": "Unreal Engine",
    "pyqt": "PyQt", "pyside": "PySide", "tkinter": "Tkinter",
    "pytest": "pytest", "vite": "Vite", "tailwind": "Tailwind CSS",
    "vad": "VAD", "tts": "TTS", "asr": "ASR", "openai": "OpenAI",
    "claude": "Claude", "deepseek": "DeepSeek", "qwen": "Qwen",
    "llama": "Llama", "gemini": "Gemini", "gradio": "Gradio",
    "streamlit": "Streamlit", "sqlalchemy": "SQLAlchemy",
    "prisma": "Prisma", "supabase": "Supabase", "firebase": "Firebase",
    "nginx": "Nginx", "wasm": "WebAssembly", "threejs": "Three.js",
    "pandas": "pandas", "numpy": "NumPy", "yolo": "YOLO",
    "langgraph": "LangGraph", "mcp": "MCP",
}

NOISE_WORDS = [
    "开源", "免费", "教程", "手把手", "从零", "我用", "做了", "一个", "这个",
    "视频", "项目", "源码", "分享", "推荐", "讲解", "实测", "保姆级", "超详细",
    "全网", "最强", "竟然", "居然", "教你", "带你", "如何", "怎么",
]


def _clean_repo_part(value: str) -> str:
    value = value.strip().strip(".,;:!?，。；：！？、")
    if value.lower().endswith(".git"):
        value = value[:-4]
    return value


def find_repo_mentions(text: str, source: str, start: float | None = None) -> list[RepoMention]:
    found: list[RepoMention] = []
    seen: set[tuple[str, str]] = set()
    for match in REPO_RE.finditer(text or ""):
        raw_host = match.group(1).lower().replace("www.", "")
        host = "github" if raw_host.startswith("github.") else "gitee"
        owner = _clean_repo_part(match.group(2))
        repo = _clean_repo_part(match.group(3))
        if not owner or not repo or repo in {"tree", "blob", "issues", "releases"}:
            continue
        key = (host, f"{owner}/{repo}".lower())
        if key in seen:
            continue
        seen.add(key)
        found.append(
            RepoMention(
                host=host,
                owner=owner,
                repo=repo,
                raw=match.group(0),
                source=source,
                start=start,
            )
        )
    return found


def find_urls(text: str) -> list[str]:
    urls: list[str] = []
    seen: set[str] = set()
    for match in URL_RE.finditer(text or ""):
        url = match.group(0).rstrip(".,;:!?，。；：！？、")
        if url.lower() in seen:
            continue
        seen.add(url.lower())
        urls.append(url)
    return urls


def _iter_text_sources(video: VideoEvidence):
    yield "title", video.title, None
    yield "description", video.description, None
    yield "tags", " ".join(video.tags), None
    yield "page_text", video.page_text, None
    for comment in video.comments:
        yield "comment", comment.text, None
    for seg in video.subtitles:
        yield "subtitle", seg.text, seg.start


def collect_repo_mentions(video: VideoEvidence) -> list[RepoMention]:
    mentions: list[RepoMention] = []
    for source, text, start in _iter_text_sources(video):
        mentions.extend(find_repo_mentions(text, source, start))
    # 去重，但保留第一次出现的位置与来源
    unique: list[RepoMention] = []
    seen: set[tuple[str, str]] = set()
    for mention in mentions:
        key = (mention.host, mention.full_name.lower())
        if key in seen:
            continue
        seen.add(key)
        unique.append(mention)
    return unique


def _title_tokens(title: str) -> list[str]:
    tokens: list[str] = []
    for match in QUOTED_RE.finditer(title):
        tokens.append(match.group(1).strip())
    for token in EN_TOKEN_RE.findall(title):
        low = token.lower().strip(".-_")
        if len(low) < 2 or low in EN_STOPWORDS:
            continue
        tokens.append(token)
    return tokens


def clean_title(title: str) -> str:
    value = re.sub(r"[【\[（(][^】\]）)]{0,30}[】\]）)]", " ", title)
    value = QUOTED_RE.sub(lambda m: f" {m.group(1)} ", value)
    for word in NOISE_WORDS:
        value = value.replace(word, " ")
    value = re.sub(r"[\U00010000-\U0010ffff]", " ", value)
    value = re.sub(r"[^\w\u4e00-\u9fff+#.]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value[:60]


def build_queries(video: VideoEvidence, mentions: list[RepoMention]) -> list[str]:
    if mentions:
        return [m.full_name for m in mentions[:3]]

    queries: list[str] = []
    for match in QUOTED_RE.finditer(video.title):
        value = match.group(1).strip()
        if value:
            queries.append(value)

    cleaned = clean_title(video.title)
    if cleaned:
        queries.append(cleaned)

    english: list[str] = []
    for token in _title_tokens(video.title) + _title_tokens(video.description[:300]):
        low = token.lower()
        if low in EN_STOPWORDS or len(low) < 2 or low in english:
            continue
        english.append(low)
    if len(english) >= 2:
        queries.append(" ".join(english[:4]))

    for tag in video.tags[:2]:
        if tag.strip():
            queries.append(tag.strip()[:40])

    unique: list[str] = []
    seen: set[str] = set()
    for query in queries:
        key = query.lower()
        if key in seen or len(query) < 2:
            continue
        seen.add(key)
        unique.append(query)
    return unique[:4]


def extract_terms(video: VideoEvidence) -> list[SignalTerm]:
    weights: dict[str, float] = defaultdict(float)
    sources: dict[str, set[str]] = defaultdict(set)

    def add(term: str, weight: float, source: str) -> None:
        term = term.strip()
        if not term:
            return
        weights[term] += weight
        sources[term].add(source)

    for token in EN_TOKEN_RE.findall(video.title):
        low = token.lower()
        if len(low) >= 2 and low not in EN_STOPWORDS:
            add(low, 2.0, "title")
    add(clean_title(video.title), 2.5, "title")

    for tag in video.tags:
        add(tag.lower(), 1.5, "tags")

    for token in EN_TOKEN_RE.findall(video.description):
        low = token.lower()
        if len(low) >= 3 and low not in EN_STOPWORDS:
            add(low, 0.8, "description")

    for seg in video.subtitles:
        for token in EN_TOKEN_RE.findall(seg.text):
            low = token.lower()
            if len(low) >= 3 and low not in EN_STOPWORDS:
                add(low, 0.4, "subtitle")

    for run in CJK_RUN_RE.findall(video.title):
        if 2 <= len(run) <= 12 and run not in CJK_STOPWORDS:
            add(run, 1.2, "title")

    all_text = " ".join(
        [video.title, video.description, " ".join(video.tags), video.transcript_text()]
    ).lower()
    tech_terms: list[str] = []
    for needle, canonical in TECH_TERMS.items():
        # 用字母边界而不是简单子串，避免 trust -> rust、scenarios -> ios 这类误报。
        pattern = r"(?<![A-Za-z])" + re.escape(needle) + r"(?![A-Za-z])"
        if re.search(pattern, all_text, re.IGNORECASE):
            add(canonical.lower(), 3.0, "tech")
            tech_terms.append(canonical)

    ranked = sorted(weights.items(), key=lambda item: (-item[1], item[0]))
    terms: list[SignalTerm] = []
    for term, weight in ranked[:80]:
        if len(term) < 2:
            continue
        terms.append(SignalTerm(term=term, weight=round(weight, 2), sources=sorted(sources[term])))
    return terms


def extract_signals(video: VideoEvidence) -> ExtractedSignals:
    mentions = collect_repo_mentions(video)
    urls: list[dict] = []
    seen_urls: set[str] = set()
    for source, text, start in _iter_text_sources(video):
        for url in find_urls(text):
            key = url.lower()
            if key in seen_urls:
                continue
            seen_urls.add(key)
            urls.append({"url": url, "source": source, "start": start})

    terms = extract_terms(video)
    queries = build_queries(video, mentions)
    warnings: list[str] = []
    if not video.subtitles:
        warnings.append("视频没有可用字幕，文本证据可能不完整；已安装 ASR 时会在分析阶段尝试转写。")
    if not mentions and not queries:
        warnings.append("没有从标题/简介/评论中提取到可用于检索的线索。")

    return ExtractedSignals(
        repo_mentions=mentions,
        urls=urls,
        terms=terms,
        tech_terms=sorted(set(t.term for t in terms if "tech" in t.sources)),
        queries=queries,
        warnings=warnings,
    )


def term_counter(text: str) -> Counter:
    counter: Counter = Counter()
    for token in EN_TOKEN_RE.findall(text or ""):
        low = token.lower()
        if len(low) >= 3 and low not in EN_STOPWORDS:
            counter[low] += 1
    return counter
