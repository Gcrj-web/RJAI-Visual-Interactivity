from __future__ import annotations

import html
import json
import threading
import traceback
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from .analyze import analyze_video
from .asr import describe as describe_asr
from .bilibili import evidence_from_payload, hydrate_evidence
from .llm import LLMClient
from .models import RepoCandidate
from .qa import answer_project_question
from .store import ProjectStore


JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
STORE = ProjectStore()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _update_job(job_id: str, **fields) -> None:
    with JOBS_LOCK:
        if job_id in JOBS:
            JOBS[job_id].update(fields)


def _public_candidate(candidate) -> dict:
    data = candidate.to_dict()
    data.pop("readme", None)
    return data


def _run_job(job_id: str, payload: dict, force_repo: tuple[str, str] | None = None) -> None:
    try:
        _update_job(job_id, status="running", step="解析页面数据")
        video = evidence_from_payload(payload)
        offline = bool(payload.get("offline"))
        if not offline:
            _update_job(job_id, step="补齐字幕与章节")
            video = hydrate_evidence(
                video,
                payload,
                cookie=str(payload.get("cookie") or ""),
                progress=lambda step: _update_job(job_id, step=step),
            )
            from .vision import enrich_video_vision

            video = enrich_video_vision(
                video,
                payload,
                progress=lambda step: _update_job(job_id, step=step),
            )
        _update_job(job_id, video_id=video.video_id, title=video.title)
        mock_candidates = [
            RepoCandidate(
                **{
                    key: value
                    for key, value in item.items()
                    if key in RepoCandidate.__dataclass_fields__
                }
            )
            for item in payload.get("mock_candidates") or []
            if isinstance(item, dict)
        ]
        result = analyze_video(
            video,
            progress=lambda step: _update_job(job_id, step=step),
            force_repo=force_repo,
            offline=offline,
            mock_candidates=mock_candidates,
        )
        directory = STORE.save(result, payload)
        _update_job(
            job_id,
            status="done",
            step="完成",
            finished_at=_now(),
            project_dir=str(directory),
            result={
                "video_id": result.video.video_id,
                "title": result.video.title,
                "url": result.video.url,
                "kind": result.kind,
                "brief_md": result.brief_md,
                "agent_prompt_md": result.agent_prompt_md,
                "selected": _public_candidate(result.selected) if result.selected else None,
                "candidates": [_public_candidate(c) for c in result.candidates[:6]],
                "warnings": result.warnings,
                "llm_used": result.llm_used,
            },
        )
    except Exception as exc:
        _update_job(
            job_id,
            status="error",
            step="失败",
            finished_at=_now(),
            error=str(exc),
            trace=traceback.format_exc()[-3000:],
        )


def start_job(payload: dict, force_repo: tuple[str, str] | None = None) -> str:
    job_id = uuid.uuid4().hex[:12]
    with JOBS_LOCK:
        JOBS[job_id] = {
            "id": job_id,
            "status": "queued",
            "step": "排队中",
            "created_at": _now(),
        }
        _prune_jobs_locked()
    threading.Thread(target=_run_job, args=(job_id, payload, force_repo), daemon=True).start()
    return job_id


def _prune_jobs_locked() -> None:
    if len(JOBS) <= 80:
        return
    finished = [
        (job_id, job)
        for job_id, job in JOBS.items()
        if job.get("status") in {"done", "error"}
    ]
    finished.sort(key=lambda item: item[1].get("created_at", ""))
    for job_id, _ in finished[: max(0, len(JOBS) - 60)]:
        JOBS.pop(job_id, None)


class Handler(BaseHTTPRequestHandler):
    server_version = "RJ/0.1"

    def log_message(self, fmt: str, *args) -> None:
        print(f"[rj] {fmt % args}")

    def _origin_allowed(self) -> bool:
        origin = self.headers.get("Origin", "")
        if not origin:
            return True
        allowed = (
            origin.startswith("chrome-extension://")
            or origin.startswith("extension://")
            or origin.startswith("https://www.bilibili.com")
            or origin.startswith("https://bilibili.com")
            or origin.startswith("https://www.douyin.com")
            or origin.startswith("https://douyin.com")
            or origin.startswith("http://127.0.0.1:")
            or origin.startswith("http://localhost:")
            or origin == "null"
        )
        if not allowed:
            self.log_message("rejected origin: %s", origin)
        return allowed

    def _cors_headers(self) -> None:
        origin = self.headers.get("Origin", "")
        if origin and self._origin_allowed():
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Access-Control-Allow-Private-Network", "true")

    def _send(self, status: int, body: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self._cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, data: dict | list) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self._send(status, body, "application/json; charset=utf-8")

    def _text(self, status: int, text: str, content_type: str = "text/plain; charset=utf-8") -> None:
        self._send(status, text.encode("utf-8"), content_type)

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            raise ValueError("请求体为空")
        if length > 8_000_000:
            raise ValueError("请求体过大")
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("请求体不是合法 JSON") from exc
        if not isinstance(data, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return data

    def do_OPTIONS(self) -> None:
        if not self._origin_allowed():
            self._json(403, {"error": "origin not allowed"})
            return
        self.send_response(204)
        self._cors_headers()
        self.end_headers()

    def do_GET(self) -> None:
        try:
            parsed = urlparse(self.path)
            parts = [p for p in parsed.path.split("/") if p]
            if parts == ["api", "health"]:
                from .vision import VisionConfig

                self._json(
                    200,
                    {
                        "ok": True,
                        "llm": LLMClient().describe(),
                        "asr": describe_asr(),
                        "vision": VisionConfig.from_env().describe(),
                        "store": str(STORE.root),
                        "time": _now(),
                    },
                )
                return
            if parts == ["api", "projects"]:
                self._json(200, {"projects": STORE.list()})
                return
            if len(parts) == 3 and parts[:2] == ["api", "jobs"]:
                with JOBS_LOCK:
                    job = JOBS.get(parts[2])
                    data = json.loads(json.dumps(job, ensure_ascii=False)) if job else None
                if not data:
                    self._json(404, {"error": "job not found"})
                    return
                self._json(200, data)
                return
            if len(parts) == 3 and parts[:2] == ["api", "projects"]:
                data = STORE.load(parts[2])
                if not data:
                    self._json(404, {"error": "project not found"})
                    return
                self._json(200, data)
                return
            if len(parts) == 4 and parts[:2] == ["api", "projects"] and parts[3] == "brief.md":
                text = STORE.read_brief(parts[2])
                if not text:
                    self._json(404, {"error": "brief not found"})
                    return
                self._text(200, text, "text/markdown; charset=utf-8")
                return
            if parts == []:
                self._index_page()
                return
            self._json(404, {"error": "not found"})
        except Exception as exc:
            self._json(500, {"error": str(exc)})

    def do_POST(self) -> None:
        if not self._origin_allowed():
            self._json(403, {"error": "origin not allowed"})
            return
        try:
            parsed = urlparse(self.path)
            parts = [p for p in parsed.path.split("/") if p]
            if parts == ["api", "ingest"]:
                payload = self._read_json()
                if not payload.get("title"):
                    self._json(400, {"error": "缺少 title"})
                    return
                job_id = start_job(payload)
                self._json(202, {"job_id": job_id})
                return
            if (
                len(parts) == 4
                and parts[:2] == ["api", "projects"]
                and parts[3] == "confirm"
            ):
                video_id = parts[2]
                body = self._read_json()
                full_name = str(body.get("full_name") or "").strip()
                host = str(body.get("host") or "github").strip().lower()
                if "/" not in full_name or host not in {"github", "gitee"}:
                    self._json(400, {"error": "需要 full_name（owner/repo）和 host"})
                    return
                # 优先复用已保存的视频证据（含字幕/章节），避免确认仓库时
                # 重新下载音频；旧项目没有 evidence 时才回退到页面 payload。
                analysis = STORE.load(video_id)
                payload = analysis.get("video") if analysis else None
                if not payload:
                    payload = STORE.load_payload(video_id)
                if not payload:
                    self._json(404, {"error": "project not found"})
                    return
                job_id = start_job(payload, force_repo=(host, full_name))
                self._json(202, {"job_id": job_id})
                return
            if (
                len(parts) == 4
                and parts[:2] == ["api", "projects"]
                and parts[3] == "ask"
            ):
                video_id = parts[2]
                body = self._read_json()
                question = str(body.get("question") or "").strip()
                if not question:
                    self._json(400, {"error": "问题为空"})
                    return
                try:
                    result = answer_project_question(STORE, video_id, question)
                except FileNotFoundError:
                    self._json(404, {"error": "项目不存在或尚未分析"})
                    return
                except ValueError as exc:
                    self._json(400, {"error": str(exc)})
                    return
                self._json(200, result)
                return
            self._json(404, {"error": "not found"})
        except ValueError as exc:
            self._json(400, {"error": str(exc)})
        except Exception as exc:
            self._json(500, {"error": str(exc)})

    def _index_page(self) -> None:
        rows = []
        for item in STORE.list():
            title = html.escape(str(item.get("title") or ""))
            repo = html.escape(str(item.get("selected_repo") or "未定位"))
            url = html.escape(str(item.get("url") or ""))
            vid = html.escape(str(item.get("video_id") or ""))
            rows.append(
                f"<tr><td><a href='{url}'>{title}</a></td><td>{repo}</td>"
                f"<td><a href='/api/projects/{vid}/brief.md'>brief.md</a></td></tr>"
            )
        body = f"""<!doctype html><html lang="zh"><meta charset="utf-8">
<title>RJ 项目情报</title>
<style>body{{font-family:system-ui,sans-serif;max-width:980px;margin:40px auto;padding:0 20px}}
table{{border-collapse:collapse;width:100%}}td,th{{border-bottom:1px solid #ddd;padding:10px;text-align:left}}
code{{background:#f3f3f3;padding:2px 5px;border-radius:4px}}</style>
<h1>RJ 项目情报</h1>
<p>本地服务运行中。扩展地址：<code>http://127.0.0.1:8765</code></p>
<table><tr><th>视频</th><th>仓库</th><th>简报</th></tr>{''.join(rows)}</table>
</html>"""
        self._text(200, body, "text/html; charset=utf-8")


class RjHTTPServer(ThreadingHTTPServer):
    # Windows 下 allow_reuse_address=True 会让两个进程同时绑定 8765，
    # 请求可能落到旧代码上。这里宁可启动失败，也不允许静默双开。
    allow_reuse_address = False


def serve(port: int = 8765) -> None:
    try:
        server = RjHTTPServer(("127.0.0.1", port), Handler)
    except OSError:
        print(
            f"本地服务启动失败：端口 {port} 已被占用。\n"
            "可能已经有一个 RJ 服务在运行。先在扩展弹窗点“重启服务”，"
            "或运行 .\\stop-server.ps1 后再启动。"
        )
        return
    print(f"RJ 本地服务已启动：http://127.0.0.1:{port}")
    print("在 Edge 中加载 extension/ 目录，然后打开 B 站视频页。")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    finally:
        server.server_close()
