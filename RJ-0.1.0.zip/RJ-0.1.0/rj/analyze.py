from __future__ import annotations

import os
import re
from typing import Callable

from .brief import (
    build_agent_prompt,
    build_fallback_brief,
    build_game_agent_prompt,
    build_game_brief,
    build_game_review_agent_prompt,
    build_game_review_brief,
    build_llm_messages,
    build_media_agent_prompt,
    build_media_brief,
    build_nonsoftware_agent_prompt,
    build_nonsoftware_brief,
    build_science_agent_prompt,
    build_science_brief,
    build_usage_agent_prompt,
    build_usage_brief,
)
from .classify import classify_video
from .codehost import CodeHostError, GiteeClient, GitHubClient, RateLimited
from .extract import extract_signals
from .llm import LLMClient, LLMError
from .models import AnalysisResult, RepoCandidate, VideoEvidence, format_seconds
from .score import score_candidates


Progress = Callable[[str], None]
REPO_URL_RE = re.compile(
    r"(?:https?://)?(?:www\.)?(github\.com|gitee\.com)/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)


def _step(progress: Progress | None, text: str) -> None:
    if progress:
        progress(text)


def _dedupe_candidates(candidates: list[RepoCandidate]) -> list[RepoCandidate]:
    seen: set[tuple[str, str]] = set()
    result: list[RepoCandidate] = []
    for candidate in candidates:
        key = (candidate.host, candidate.full_name.lower())
        if not candidate.full_name or key in seen:
            continue
        seen.add(key)
        result.append(candidate)
    return result


def _add_warning(warnings: list[str], message: str) -> None:
    if message and message not in warnings:
        warnings.append(message)


def localize_platform_text(text: str, video: VideoEvidence) -> str:
    """把模板里的 B 站标签换成当前平台的说法，不改动引用原文。"""
    if video.platform == "douyin":
        return (
            text.replace("B 站页面", "抖音页面")
            .replace("UP 主", "作者")
        )
    return text


def attach_visual_analysis(text: str, video: VideoEvidence) -> str:
    """把视觉模型结果并入简报；没有视觉结果时保持原文。"""
    data = getattr(video, "visual_analysis", None) or {}
    if not data or "## 画面证据（AI）" in text:
        return text

    lines = ["## 画面证据（AI）", ""]
    model = str(data.get("model") or "视觉模型")
    frames = data.get("frames") or []
    lines.append(
        f"> 使用 {model} 分析 {len(frames)} 个关键帧；只描述抽样画面，"
        "身份不确定处不硬猜。"
    )
    summary = str(data.get("summary") or "").strip()
    if summary:
        lines.append(f"- [画面总结] {summary}")
    for label, key in (
        ("可见人物/角色", "people"),
        ("可见物体/场景", "objects"),
        ("动作/事件", "actions"),
        ("屏幕文字", "screen_text"),
        ("情绪/氛围（画面推断）", "emotion"),
        ("不确定", "uncertainties"),
    ):
        values = data.get(key) or []
        if isinstance(values, str):
            values = [values]
        values = [str(value).strip() for value in values if str(value).strip()]
        if values:
            lines.append(f"- {label}：{'；'.join(values[:8])}")

    notes = data.get("scene_notes") or []
    if isinstance(notes, list) and notes:
        lines.append("")
        lines.append("关键帧：")
        for note in notes[:10]:
            if not isinstance(note, dict):
                continue
            observation = str(note.get("observation") or "").strip()
            if not observation:
                continue
            tag = {
                "visible": "画面",
                "inferred": "画面推断",
                "unknown": "未知",
            }.get(str(note.get("confidence") or "inferred"), "画面推断")
            lines.append(
                f"- [{format_seconds(note.get('time'))}] {observation}（{tag}）"
            )
    section = "\n".join(lines).strip()

    if data:
        text = text.replace(
            "当前没有接入视觉模型，以下只基于标题、简介、评论和字幕；"
            "不能可靠识别画面人物、表情或演出情绪。",
            "已使用视觉模型分析少量关键帧；以下结合文字和画面证据，"
            "画面结论会标注来源，仍可能漏掉关键帧之外的信息。",
        )
        text = text.replace(
            "但人物关系、画面内容和情绪仍需要关键帧或视觉模型确认。",
            "已结合少量关键帧补充画面内容；人物身份和关系仍以可见线索为限。",
        )
        text = text.replace(
            "- 没有视觉模型和关键帧 OCR，无法确认画面人物、构图、分镜和表情。",
            "- 视觉分析只基于少量关键帧，可能漏掉快速转场、短暂表情和画外信息。",
        )
        text = text.replace(
            "- [未知] 画面表情、演出和氛围需要视觉模型分析。",
            "- [画面] 见下方“画面证据（AI）”中的表情、动作和氛围观察。",
        )
        text = text.replace(
            "当前版本不做画面 OCR/BOM 识别",
            "已使用视觉模型分析少量关键帧，但不替代完整 BOM/OCR",
        )

    marker = "## 7. 证据索引"
    if marker in text:
        return text.replace(marker, f"{section}\n\n{marker}", 1)
    return text.rstrip() + "\n\n" + section + "\n"


def _explicit_repo_candidate(signals) -> RepoCandidate | None:
    """用视频文字里直接给出的仓库地址兜底，保证扩展始终有可访问的链接。"""
    mentions = signals.repo_mentions
    if not mentions:
        return None
    preferred = next(
        (
            mention
            for mention in mentions
            if mention.source in {"title", "description", "page_text", "tags"}
        ),
        mentions[0],
    )
    return RepoCandidate(
        host=preferred.host,
        full_name=preferred.full_name,
        html_url=f"https://{preferred.host}.com/{preferred.full_name}",
        source="explicit",
        reasons=["视频文字中直接给出的仓库地址；未读取 README"],
    )


def flag_unverified_repos(
    brief_md: str,
    candidates: list[RepoCandidate],
    warnings: list[str],
) -> None:
    """LLM 偶尔会在 Markdown 里编一个看起来很像的仓库地址，这里单独兜底。"""
    allowed = {(c.host.lower(), c.full_name.lower()) for c in candidates}
    seen: set[tuple[str, str]] = set()
    for match in REPO_URL_RE.finditer(brief_md or ""):
        host = match.group(1).lower().split(".")[0]
        full_name = f"{match.group(2)}/{match.group(3)}".lower()
        key = (host, full_name)
        if key in allowed or key in seen:
            continue
        seen.add(key)
        _add_warning(
            warnings,
            f"简报中出现未验证的仓库地址：{match.group(1)}/{match.group(2)}/{match.group(3)}",
        )


def analyze_video(
    video: VideoEvidence,
    progress: Progress | None = None,
    offline: bool = False,
    force_repo: tuple[str, str] | None = None,
    llm: LLMClient | None = None,
    github: GitHubClient | None = None,
    gitee: GiteeClient | None = None,
    mock_candidates: list[RepoCandidate] | None = None,
) -> AnalysisResult:
    warnings: list[str] = []
    for warning in video.warnings:
        _add_warning(warnings, warning)

    _step(progress, "提取视频线索")
    signals = extract_signals(video)
    for warning in signals.warnings:
        _add_warning(warnings, warning)

    if offline:
        _add_warning(warnings, "离线演示模式：没有访问 B 站或代码托管平台。")

    classification = classify_video(video, signals)
    kind = classification.kind
    if force_repo:
        # 用户手动确认了仓库，说明这就是一个软件项目。
        kind = "software_project"

    raw_candidates: list[RepoCandidate] = []
    candidates: list[RepoCandidate] = []
    selected: RepoCandidate | None = None
    brief_md = ""
    llm_used = False
    llm_reason = ""

    if kind == "software_project":
        github_client = None
        gitee_client = None
        if offline:
            raw_candidates.extend(mock_candidates or [])
        else:
            github_client = github or GitHubClient(
                token=os.environ.get("GITHUB_TOKEN") or None
            )
            gitee_client = gitee or GiteeClient()

            if force_repo:
                host, full_name = force_repo
                _step(progress, f"读取你确认的仓库 {full_name}")
                client = github_client if host == "github" else gitee_client
                try:
                    confirmed = client.get_repo(full_name)
                    confirmed.source = "manual"
                    raw_candidates.append(confirmed)
                except CodeHostError as exc:
                    _add_warning(warnings, f"读取确认仓库失败：{exc}")

            _step(progress, "检查视频里是否直接给出仓库地址")
            for mention in signals.repo_mentions:
                client = github_client if mention.host == "github" else gitee_client
                try:
                    candidate = client.get_repo(mention.full_name)
                    candidate.source = "explicit"
                    raw_candidates.append(candidate)
                except CodeHostError as exc:
                    _add_warning(warnings, f"读取仓库 {mention.full_name} 失败：{exc}")

            if not signals.repo_mentions:
                _step(progress, "检索 GitHub / Gitee")
                for index, query in enumerate(signals.queries[:3]):
                    try:
                        raw_candidates.extend(github_client.search(query, per_page=6))
                    except RateLimited as exc:
                        _add_warning(warnings, str(exc))
                        break
                    except CodeHostError as exc:
                        _add_warning(warnings, f"GitHub 检索 `{query}` 失败：{exc}")
                    if index < 2:
                        try:
                            raw_candidates.extend(gitee_client.search(query, per_page=6))
                        except CodeHostError as exc:
                            _add_warning(warnings, f"Gitee 检索 `{query}` 失败：{exc}")

        candidates = _dedupe_candidates(raw_candidates)
        _step(progress, "给候选仓库打分")
        candidates = score_candidates(candidates, signals, video)

        if not offline and candidates:
            _step(progress, "读取候选仓库的 README 与依赖")
            targets = candidates[:2]
            if force_repo:
                forced_name = force_repo[1].lower()
                for candidate in candidates:
                    if candidate.full_name.lower() == forced_name and candidate not in targets:
                        targets.append(candidate)
                        break
            enriched: list[RepoCandidate] = []
            for candidate in targets:
                client = github_client if candidate.host == "github" else gitee_client
                source = candidate.source
                try:
                    detail = client.enrich(candidate)
                    detail.source = source
                    enriched.append(detail)
                except CodeHostError as exc:
                    _add_warning(warnings, f"读取 {candidate.full_name} 的资料失败：{exc}")
                    enriched.append(candidate)
            rest = [c for c in candidates if c not in targets]
            candidates = score_candidates(
                _dedupe_candidates(enriched + rest), signals, video
            )

        if force_repo:
            forced_name = force_repo[1].lower()
            selected = next(
                (c for c in candidates if c.full_name.lower() == forced_name),
                None,
            )
            if selected is None:
                _add_warning(
                    warnings,
                    f"未能读取你确认的仓库 {force_repo[1]}，请检查地址或网络。",
                )
        elif candidates and candidates[0].score >= 35:
            selected = candidates[0]

        _step(progress, "生成复刻简报")
        if offline:
            llm_reason = "离线演示模式"
        elif llm is None or llm.available():
            client = llm or LLMClient()
            try:
                system, user = build_llm_messages(video, signals, candidates)
                brief_md = client.complete(system, user)
                llm_used = True
                flag_unverified_repos(brief_md, candidates, warnings)
            except LLMError as exc:
                llm_reason = str(exc)
                _add_warning(warnings, f"LLM 生成失败，已回退到本地规则：{exc}")
        else:
            llm_reason = "未配置 RJ_LLM_API_KEY"
    elif kind == "software_usage":
        _step(progress, "识别为软件使用教程，跳过源码检索")
        if offline:
            candidates = list(mock_candidates or [])
        else:
            github_client = github or GitHubClient(
                token=os.environ.get("GITHUB_TOKEN") or None
            )
            gitee_client = gitee or GiteeClient()
            for mention in signals.repo_mentions:
                client = github_client if mention.host == "github" else gitee_client
                try:
                    candidate = client.get_repo(mention.full_name)
                    candidate.source = "explicit"
                    candidates.append(candidate)
                except CodeHostError as exc:
                    _add_warning(
                        warnings,
                        f"读取仓库 {mention.full_name} 失败：{exc}",
                    )
        if candidates:
            selected = candidates[0]
            selected.score = 100.0
            selected.reasons = ["视频给出的软件仓库，用作身份确认"]
        llm_reason = "软件使用教程使用本地规则"
        brief_md = build_usage_brief(video, signals, selected)
    elif kind == "media_content":
        _step(progress, "识别为动漫/影视内容，跳过代码仓库检索")
        llm_reason = "媒体内容使用本地规则"
        brief_md = build_media_brief(video, signals, classification)
    elif kind == "game_guide":
        _step(progress, "识别为游戏攻略，跳过代码仓库检索")
        llm_reason = "游戏攻略使用本地规则"
        brief_md = build_game_brief(video, signals, classification)
    elif kind == "game_review":
        _step(progress, "识别为游戏测评/排行，跳过代码仓库检索")
        llm_reason = "游戏测评/排行使用本地规则"
        brief_md = build_game_review_brief(video, signals, classification)
    elif kind == "science_content":
        _step(progress, "识别为科普/健康内容，跳过代码仓库检索")
        llm_reason = "科普/健康内容使用本地规则"
        brief_md = build_science_brief(video, signals, classification)
    else:
        _step(progress, f"识别为{classification.label}，跳过代码仓库检索")
        llm_reason = "离线演示模式" if offline else "非软件项目使用本地规则"
        brief_md = build_nonsoftware_brief(video, signals, classification)

    if selected is None:
        mentioned = _explicit_repo_candidate(signals)
        if mentioned is not None:
            key = (mentioned.host.lower(), mentioned.full_name.lower())
            selected = next(
                (
                    candidate
                    for candidate in candidates
                    if (candidate.host.lower(), candidate.full_name.lower()) == key
                ),
                mentioned,
            )

    if not brief_md:
        brief_md = build_fallback_brief(video, signals, candidates, selected, llm_reason)

    _step(progress, "整理 Agent 任务包")
    if kind == "software_project":
        agent_prompt_md = build_agent_prompt(brief_md, video, selected)
    elif kind == "software_usage":
        agent_prompt_md = build_usage_agent_prompt(brief_md, video, selected)
    elif kind == "media_content":
        agent_prompt_md = build_media_agent_prompt(brief_md, video)
    elif kind == "game_guide":
        agent_prompt_md = build_game_agent_prompt(brief_md, video)
    elif kind == "game_review":
        agent_prompt_md = build_game_review_agent_prompt(brief_md, video)
    elif kind == "science_content":
        agent_prompt_md = build_science_agent_prompt(brief_md, video)
    else:
        agent_prompt_md = build_nonsoftware_agent_prompt(brief_md, video, classification)

    brief_md = localize_platform_text(brief_md, video)
    agent_prompt_md = localize_platform_text(agent_prompt_md, video)
    brief_md = attach_visual_analysis(brief_md, video)
    agent_prompt_md = attach_visual_analysis(agent_prompt_md, video)

    return AnalysisResult(
        video=video,
        signals=signals,
        candidates=candidates,
        selected=selected,
        brief_md=brief_md,
        agent_prompt_md=agent_prompt_md,
        kind=kind,
        llm_used=llm_used,
        warnings=warnings,
    )
