from __future__ import annotations

import re
from urllib.parse import urlparse

from .asr_norm import normalize_text
from .classify import VideoClassification
from .models import ExtractedSignals, RepoCandidate, VideoEvidence, format_seconds


SOURCE_LABELS = {
    "title": "标题",
    "description": "简介",
    "tags": "标签",
    "page_text": "页面文本",
    "comment": "评论",
    "subtitle": "字幕",
    "tech": "技术词",
}


def _display_host(host: str) -> str:
    if host == "github":
        return "github.com"
    if host == "gitee":
        return "gitee.com"
    return host


SYSTEM_PROMPT = """你是一名资深软件项目分析师，专门把中文技术视频转成"可执行的复刻简报"，交给编码 Agent（Codex / Claude Code / Cursor）使用。

硬性规则：
1. 只使用我给你的材料。不得编造仓库名、作者、版本号、文件路径、命令、依赖或硬件型号。
2. 每条关键事实后面标注证据来源：视频时间戳 (mm:ss)、简介、评论、仓库 README、代码托管平台元数据。
3. 把信息分成三类：[确认] 有直接证据；[推断] 有合理依据但未验证；[未知] 材料里没有。不要把推断写成确认。
4. 如果候选仓库不确定，明确写出"仓库未确认"，并给出验证方法。
5. 不要写空泛的鼓励语，不要复述视频标题。输出要能让一个完全不了解该项目的人直接开工。
6. 如果视频内容与仓库 README 冲突，以仓库为准并指出冲突。
7. 许可证只写材料中出现的；没有就写"未确认"。
8. 只输出 Markdown，不要解释你是如何分析的。
"""


OUTPUT_SPEC = """请严格按下面的结构输出，不要增删一级标题：

# 复刻简报：<项目名>

## 0. 一句话结论
这个项目是什么、是否值得复刻、最大的风险是什么。

## 1. 项目身份
用表格列出：项目名、仓库、作者、许可证、主要语言、最后更新、视频地址。每行带证据和 [确认]/[推断]/[未知]。

## 2. 视频里实际演示了什么
按时间顺序列 3-8 条，必须带 (mm:ss) 时间戳。区分"视频演示的效果"和"视频声称的信息"。

## 3. 技术栈与项目结构
只写 README、依赖清单或视频里明确出现的内容。列出语言、框架、关键依赖、入口文件、目录结构；没有就写 [未知]。

## 4. 复刻路径
分 3-5 个阶段。每个阶段包含：目标、要改/要建的文件、验证命令、验收标准、常见坑、回滚点。第一阶段必须是"跑通官方版本"。

## 5. 未知与风险
列出 [未知] 和 [风险]。重点：许可证、缺失的依赖/模型/数据、视频演示与仓库的差距、版本漂移、是否只是套壳/教程引流。

## 6. 需要你回答的问题
最多 6 个。只问那些会改变技术方案的问题（例如运行环境、已有硬件、复刻范围、预算）。能通过读仓库确认的不要问。

## 7. 给编码 Agent 的任务包
给出一段可以直接复制给 Codex/Claude Code 的提示词。要求它先读仓库、给出计划、分阶段实现、每阶段验收，不得编造接口。
"""


def _clip(text: str, limit: int) -> str:
    text = text or ""
    if len(text) <= limit:
        return text
    head = int(limit * 0.7)
    tail = limit - head
    return text[:head] + "\n\n……（中间省略）……\n\n" + text[-tail:]


def _clean_readme(text: str) -> str:
    text = re.sub(r"!\[[^\]]*\]\([^)]*\)", "", text or "")
    text = re.sub(r"<img[^>]*>", "", text, flags=re.I)
    text = re.sub(r"\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _sample_transcript(video: VideoEvidence, limit: int = 12000) -> str:
    segments = [seg for seg in video.subtitles if seg.text]
    if not segments:
        return "（无字幕）"
    lines = [f"[{format_seconds(seg.start)}] {seg.text}" for seg in segments]
    joined = "\n".join(lines)
    if len(joined) <= limit:
        return joined
    per_line = max(1, len(joined) // max(1, len(lines)))
    keep = max(20, limit // per_line)
    step = max(1, len(lines) // keep)
    sampled = lines[::step]
    if lines[-1] not in sampled:
        sampled.append(lines[-1])
    return _clip("\n".join(sampled), limit)


def _sources_for_mentions(signals: ExtractedSignals, limit: int = 8) -> str:
    if not signals.repo_mentions:
        return "（没有直接提取到仓库地址）"
    lines: list[str] = []
    for mention in signals.repo_mentions[:limit]:
        where = SOURCE_LABELS.get(mention.source, mention.source)
        if mention.start is not None:
            where += f" @ {format_seconds(mention.start)}"
        lines.append(f"- {_display_host(mention.host)}/{mention.full_name}（来源：{where}）")
    return "\n".join(lines)


HARDWARE_TOOL_TERMS = {
    "螺丝刀": "螺丝刀",
    "十字": "十字螺丝刀",
    "镊子": "镊子",
    "撬棒": "撬棒",
    "撬片": "撬片",
    "吸盘": "吸盘",
    "防静电": "防静电手环/垫",
    "毛刷": "毛刷",
    "气吹": "气吹",
    "热风枪": "热风枪",
    "电烙铁": "电烙铁",
}

HARDWARE_CONSUMABLE_TERMS = {
    "硅脂": "硅脂",
    "相变片": "相变片",
    "导热垫": "导热垫",
    "导热膏": "导热膏",
    "酒精": "酒精",
    "无尘布": "无尘布",
}

HARDWARE_OPERATION_TERMS = {
    "清灰": "清灰",
    "除尘": "除尘",
    "换硅脂": "更换硅脂",
    "相变片": "更换相变片",
    "换电池": "更换电池",
    "换屏": "更换屏幕",
    "换键盘": "更换键盘",
    "拆机": "拆机",
    "拆解": "拆解",
    "维修": "维修",
    "装机": "装机",
    "接线": "接线",
    "烧录": "烧录固件",
    "调试": "调试",
    "组装": "组装",
    "焊接": "焊接",
}

EMBEDDED_COMPONENT_TERMS = {
    "esp32": "ESP32 开发板",
    "stm32": "STM32 开发板",
    "arduino": "Arduino",
    "树莓派": "树莓派",
    "raspberry": "树莓派",
    "开发板": "开发板",
    "舵机": "舵机",
    "传感器": "传感器",
    "电机": "电机",
    "锂电池": "锂电池",
    "电池组": "电池组",
    "驱动板": "驱动板",
    "机械臂": "机械臂",
    "小车": "小车",
    "无人机": "无人机",
}


def _find_where(video: VideoEvidence, term: str) -> str:
    needle = term.lower()
    if needle in video.title.lower():
        return "标题"
    if needle in video.description.lower():
        return "简介"
    for tag in video.tags:
        if needle in tag.lower():
            return "标签"
    for seg in video.subtitles:
        if needle in seg.text.lower():
            return f"字幕 {format_seconds(seg.start)}"
    for comment in video.comments:
        if needle in comment.text.lower():
            return f"评论（{comment.author}）"
    return ""


def _found_terms(video: VideoEvidence, mapping: dict[str, str]) -> list[tuple[str, str]]:
    found: list[tuple[str, str]] = []
    seen: set[str] = set()
    for key, label in mapping.items():
        where = _find_where(video, key)
        if where and label not in seen:
            seen.add(label)
            found.append((label, where))
    return found


def _device_models(video: VideoEvidence) -> list[str]:
    text = f"{video.title} {video.description}"
    models = re.findall(r"(?<![A-Za-z0-9])(?:R|Y)\d{4}P", text, re.IGNORECASE)
    for name in ("拯救者", "天选", "暗影精灵", "MacBook", "iPhone", "iPad", "ThinkPad", "ROG"):
        if name.lower() in text.lower():
            models.append(name)
    unique: list[str] = []
    seen: set[str] = set()
    for model in models:
        key = model.lower()
        if key in seen:
            continue
        seen.add(key)
        unique.append(model)
    return unique


def _top_comments(
    video: VideoEvidence,
    limit: int = 3,
    include_author: bool = True,
) -> list:
    comments = []
    for comment in video.comments:
        text = comment.text.strip()
        if not text:
            continue
        if not include_author and video.author and comment.author == video.author:
            continue
        if text.count("http") >= 1 and len(text) < 120:
            continue
        if len(text) < 4 and comment.likes < 20:
            continue
        comments.append(comment)
    return sorted(comments, key=lambda comment: comment.likes, reverse=True)[:limit]


def _append_timeline(lines: list[str], video: VideoEvidence) -> None:
    if video.chapters:
        for chapter in video.chapters[:15]:
            lines.append(f"- [{format_seconds(chapter.start)}] {chapter.title}")
        return
    if video.subtitles:
        step = max(1, len(video.subtitles) // 15)
        for seg in video.subtitles[::step][:15]:
            lines.append(f"- [{format_seconds(seg.start)}] {_clip(seg.text, 100)}")
        return
    lines.append("- [未知] 没有字幕或章节，无法从文字证据还原时间线。")


def _append_evidence(
    lines: list[str],
    video: VideoEvidence,
    comments_limit: int = 3,
    include_author: bool = True,
) -> None:
    lines.append(f"- 视频：{video.url}")
    if video.description:
        lines.append("")
        lines.append("简介摘录：")
        lines.append("")
        lines.append("```text")
        lines.append(_clip(video.description, 1200))
        lines.append("```")
    comments = _top_comments(
        video,
        comments_limit,
        include_author=include_author,
    )
    if comments:
        lines.append("")
        lines.append("高赞评论（仅作观众反馈）：")
        for comment in comments:
            lines.append(
                f"- {comment.author}（{comment.likes} 赞）：{_clip(comment.text, 180)}"
            )
    if video.subtitles:
        lines.append("")
        label = (
            "ASR 字幕（专有名词可能有误）"
            if any(seg.source == "asr" for seg in video.subtitles)
            else "字幕"
        )
        lines.append(f"{label}段落：{len(video.subtitles)} 条")
        for seg in video.subtitles[:8]:
            lines.append(f"- [{format_seconds(seg.start)}] {_clip(seg.text, 140)}")
    else:
        lines.append("- 字幕：[未知] 没有获取到字幕。")


def _build_hardware_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> str:
    mixed = classification.kind == "hardware_software_mixed"
    profile = _hardware_profile(video)
    models = _device_models(video)
    components = _found_terms(video, EMBEDDED_COMPONENT_TERMS)
    if any(label != "开发板" and "开发板" in label for label, _ in components):
        components = [
            (label, where) for label, where in components if label != "开发板"
        ]
    operations = _found_terms(video, HARDWARE_OPERATION_TERMS)
    tools = _found_terms(video, HARDWARE_TOOL_TERMS)
    consumables = _found_terms(video, HARDWARE_CONSUMABLE_TERMS)
    device_label = "、".join(models) or (
        components[0][0] if components else "[未知]"
    )
    subject = "、".join(models) or (
        components[0][0] if components else "未明确型号"
    )
    operation = "、".join(label for label, _ in operations) or "维修/拆机"

    lines: list[str] = []
    briefing_title = "硬件 + 软件混合简报" if mixed else "硬件维修简报"
    lines.append(f"# {briefing_title}：{video.title or video.video_id}")
    lines.append("")
    if mixed:
        lines.append("> 视频类型：硬件 + 软件混合教程（既有设备/接线/工具，也有软件/固件/代码步骤）。")
    else:
        lines.append("> 视频类型：硬件维修/拆机教程（自动判断，未检索代码仓库）。")
    lines.append("> 当前版本不做画面 OCR/BOM 识别，以下只整理标题、简介、评论和字幕里的文字证据。")
    lines.append("> 它不能替代对应型号的官方维修手册。")
    lines.append("")
    lines.append("## 0. 一句话结论")
    if mixed:
        lines.append(
            f"这是一条同时涉及 **{subject}** 硬件和软件/固件操作的混合教程，"
            "不是纯手机 App 使用教程。"
        )
    else:
        lines.append(f"这是一条关于 **{subject}** 的 **{operation}** 教程，不是软件项目。")
    if video.subtitles:
        lines.append("有字幕，可以还原部分步骤；但仍缺少画面级的零件、螺丝和排线识别。")
    else:
        lines.append("没有字幕或章节，当前只能确认主题，无法还原完整拆卸顺序。")
    lines.append("")

    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append(
        f"| 类型判断 | {classification.label} | 命中：{'、'.join(classification.hardware_hits[:8]) or '弱信号'} | [推断] |"
    )
    lines.append("")

    lines.append("## 2. 能确认的主题")
    lines.append("")
    lines.append(f"- 设备/系列：{device_label}")
    lines.append(f"- 操作类型：{'、'.join(label for label, _ in operations) or '[未知]'}")
    if components:
        lines.append(f"- 硬件组件：{'、'.join(label for label, _ in components)}")
    lines.append(
        f"- 判断依据：硬件相对分 {classification.hardware_score}，"
        f"软件相对分 {classification.software_score}（标题/简介权重更高）"
    )
    if mixed:
        links = _usage_links(signals)
        lines.append("")
        lines.append("### 软件 / 固件线索")
        if links:
            for link in links:
                where = link["source"]
                if link.get("start") is not None:
                    where += f" @ {format_seconds(link['start'])}"
                lines.append(f"- {link['kind']}：{link['url']}（{where}）")
        elif signals.repo_mentions:
            for mention in signals.repo_mentions[:4]:
                lines.append(
                    f"- 仓库：{_display_host(mention.host)}/{mention.full_name}"
                )
        else:
            lines.append("- [未知] 视频文字里没有提取到软件仓库或固件下载链接。")
        lines.append("- 这条视频不是纯手机 App 使用教程；下面的问题会同时问到硬件和软件。")
    lines.append("")

    lines.append("## 3. 视频步骤 / 时间线")
    lines.append("")
    if any(seg.source == "asr" for seg in video.subtitles):
        lines.append("> 以下时间线来自本地 ASR，专有名词可能有误。")
        lines.append("")
    _append_timeline(lines, video)
    if not video.subtitles and not video.chapters:
        lines.append("")
        lines.append("> 不要根据通用经验补全拆卸顺序；不同型号的螺丝位置、排线卡扣和电池固定方式可能不同。")
    lines.append("")

    lines.append("## 4. 工具与耗材")
    lines.append("")
    if tools:
        for label, where in tools[:10]:
            lines.append(f"- 工具：{label}（{where}）")
    else:
        lines.append("- 工具：[未知] 视频文字里没有明确列出。")
    if consumables:
        for label, where in consumables[:10]:
            lines.append(f"- 耗材：{label}（{where}）")
    else:
        lines.append("- 耗材：[未知] 视频文字里没有明确列出。")
    if components:
        for label, where in components[:10]:
            lines.append(f"- 硬件组件：{label}（{where}）")
    lines.append("")

    lines.append("## 5. 安全与风险")
    lines.append("")
    lines.append("> 以下是通用安全建议，不是视频原文。")
    lines.append("")
    if profile == "embedded":
        lines.append("- 接线和供电前确认电压、极性和引脚定义，避免反接或短路。")
        lines.append("- 舵机/电机等执行器建议单独供电，避免开发板供电不足或复位。")
        lines.append("- 烧录/下载固件时不要带电插拔；先断开执行器电源再改接线。")
        lines.append("- 首次上电先空载/低功率测试，确认无异常发热、异味或堵转。")
        lines.append("- 锂电池需要保护板，避免过充、短路和穿刺。")
    elif profile == "phone":
        lines.append("- 拆机前备份数据并断开电池；不同机型的排线位置不同。")
        lines.append("- 电池鼓包、破损或发热时停止操作，不要穿刺或用金属工具撬。")
        lines.append("- 在保修期内自行拆机会影响保修，先确认售后政策。")
    else:
        lines.append("- 拆机前断电，并按机型维修手册先断开电池排线。")
        lines.append("- 做好防静电；拆下的螺丝按位置分类，避免长短螺丝装错。")
        lines.append("- 排线卡扣先观察再拆，不要直接拉线。")
        lines.append("- 电池鼓包、破损或发热时停止操作，不要穿刺、弯折或用金属工具撬。")
        lines.append("- 相变片/导热垫的尺寸和厚度必须以该型号要求或实测为准，不能凭视频截图猜。")
        lines.append("- 在保修期内自行拆机会影响保修，先确认售后政策。")
        lines.append("- 装机后先检查风扇、温度、充电和电池识别，再长时间高负载运行。")
    lines.append("")

    lines.append("## 6. 需要你确认的问题")
    lines.append("")
    for index, question in enumerate(
        build_hardware_questions(video, signals, classification), start=1
    ):
        lines.append(f"{index}. {question}")
    lines.append("")

    lines.append("## 7. 证据索引")
    lines.append("")
    _append_evidence(lines, video)
    lines.append("")

    lines.append("## 8. 当前工具的边界")
    lines.append("")
    if mixed:
        lines.append("- 这是硬件 + 软件混合教程：硬件接线/烧录动作需要画面或原理图确认，当前没有 OCR/BOM。")
        lines.append("- 软件/固件步骤来自字幕；不会自动执行编译或烧录。")
    else:
        lines.append("- 这是文字证据简报，不是拆机手册；没有画面 OCR、螺丝计数和 BOM 识别。")
        lines.append("- 没有检索代码仓库是对的：这类视频不是软件项目。")
    lines.append("- 如果要做成可执行的维修/组装助手，下一步需要关键帧 OCR、零件识别和分型号步骤库。")
    for warning in video.warnings[:6]:
        lines.append(f"- [提示] {warning}")
    lines.append("")
    return "\n".join(lines)


def _transcript_highlights(
    video: VideoEvidence,
    limit: int = 8,
    keywords: tuple[str, ...] = (),
    anchors: int = 0,
) -> list:
    segments = [seg for seg in video.subtitles if seg.text.strip()]
    if not segments:
        return []
    markers = (
        "建议", "推荐", "注意", "但是", "所以", "因为", "如果", "可以",
        "需要", "不要", "重点", "结论", "总结", "首先", "最后",
    )
    chosen = []
    if video.chapters:
        for index, chapter in enumerate(video.chapters):
            end = (
                video.chapters[index + 1].start
                if index + 1 < len(video.chapters)
                else float("inf")
            )
            window = [
                seg for seg in segments if chapter.start <= seg.start < end
            ]
            if not window:
                continue
            window.sort(
                key=lambda seg: (
                    0 if any(marker in seg.text for marker in markers) else 1,
                    0 if any(char.isdigit() for char in seg.text) else 1,
                    -len(seg.text),
                )
            )
            chosen.append(window[0])
    else:
        if keywords:
            def score(seg) -> int:
                value = 0
                for keyword in keywords:
                    if keyword in seg.text:
                        value += 3
                if any(char.isdigit() for char in seg.text):
                    value += 3
                if any(marker in seg.text for marker in markers):
                    value += 2
                if len(seg.text) >= 10:
                    value += 1
                return value

            chosen = list(segments[:anchors]) if anchors > 0 else []
            seen_starts = {round(seg.start, 1) for seg in chosen}
            for seg in sorted(
                segments,
                key=lambda item: (-score(item), item.start),
            ):
                if len(chosen) >= limit:
                    break
                if round(seg.start, 1) in seen_starts:
                    continue
                chosen.append(seg)
                seen_starts.add(round(seg.start, 1))
            chosen.sort(key=lambda seg: seg.start)
        else:
            step = max(1, len(segments) // limit)
            chosen = segments[::step][:limit]
    unique = []
    seen = set()
    for seg in chosen:
        key = (round(seg.start, 1), seg.text[:40])
        if key in seen:
            continue
        seen.add(key)
        unique.append(seg)
    return unique[:limit]


def _build_general_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    heading: str = "视频内容简报",
    intro: str = "",
    conclusion: str = "",
    highlight_keywords: tuple[str, ...] = (),
    highlight_limit: int = 8,
    highlight_anchors: int = 0,
) -> str:
    lines: list[str] = []
    lines.append(f"# {heading}：{video.title or video.video_id}")
    lines.append("")
    lines.append(
        intro
        or "> 视频类型：通用内容。没有发现软件项目或硬件维修的强信号，因此没有检索代码仓库。"
    )
    lines.append("")
    lines.append("## 0. 一句话结论")
    lines.append(
        conclusion
        or "这是一条通用内容视频；当前只能基于标题、简介、评论和字幕做内容整理。"
    )
    lines.append("")
    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(f"| UP 主 | {video.author or '未知'} | B 站页面 | {'[确认]' if video.author else '[未知]'} |")
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append("")
    lines.append("## 2. 主要内容")
    lines.append("")
    if video.description:
        lines.append("- 简介：" + _clip(video.description.replace("\n", " "), 500))
    if signals.tech_terms:
        lines.append(f"- 识别到的关键词：{'、'.join(signals.tech_terms[:15])}")
    highlights = _transcript_highlights(
        video,
        limit=highlight_limit,
        keywords=highlight_keywords,
        anchors=highlight_anchors,
    )
    if highlights:
        lines.append("")
        lines.append("字幕要点（博主原话节选）：")
        for seg in highlights:
            lines.append(
                f"- [{format_seconds(seg.start)}] {_clip(seg.text, 180)}"
            )
    if not video.description and not video.comments and not video.subtitles:
        lines.append("- [未知] 页面没有提供足够的文字材料。")
    lines.append("")
    lines.append("## 3. 时间线")
    lines.append("")
    _append_timeline(lines, video)
    lines.append("")
    lines.append("## 4. 观众反馈（高赞节选，仅作旁证）")
    lines.append("")
    top_comments = _top_comments(video, 3, include_author=False)
    if top_comments:
        for comment in top_comments:
            lines.append(
                f"- {comment.author}（{comment.likes} 赞）："
                f"{_clip(comment.text, 160)}"
            )
    else:
        lines.append("- 没有可用的高赞评论。")
    lines.append("")
    lines.append("## 5. 未知与限制")
    lines.append("")
    lines.append("- [未知] 没有对画面做 OCR/视觉分析，无法确认字幕之外的内容。")
    lines.append("- [未知] 这类视频不是软件项目，不生成代码复刻路径。")
    if heading.startswith("硬件资讯"):
        lines.append(
            "- ASR 可能把价格、型号和百分比识别错；关键数字请以视频画面或电商页面为准。"
        )
    for warning in video.warnings[:6]:
        lines.append(f"- [提示] {warning}")
    lines.append("")
    lines.append("## 6. 证据索引")
    lines.append("")
    _append_evidence(lines, video)
    lines.append("")
    return "\n".join(lines)


def build_nonsoftware_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> str:
    if classification.kind in {"hardware_tutorial", "hardware_software_mixed"}:
        return _build_hardware_brief(video, signals, classification)
    if classification.kind == "hardware_topic":
        return _build_general_brief(
            video,
            signals,
            heading="硬件资讯/评测简报",
            intro=(
                "> 视频类型：硬件资讯/评测/价格讨论。"
                "没有发现拆机、清灰或维修步骤，因此不生成维修手册或软件复刻路径。"
            ),
            conclusion=(
                "这是一条硬件资讯/评测视频；以下整理博主提到的价格、型号、时间线和观点，"
                "不生成维修或复刻步骤。"
            ),
            highlight_keywords=(
                "价格", "涨价", "降价", "元", "万", "首发", "国补",
                "优惠", "预算", "价位", "涨了", "跌", "%",
            ),
            highlight_limit=10,
            highlight_anchors=5,
        )
    return _build_general_brief(video, signals)


EMOTION_HINTS = (
    "哭", "泪", "笑", "愤怒", "生气", "悲伤", "难过", "热血", "燃",
    "温柔", "孤独", "治愈", "绝望", "害怕", "震惊", "感动", "喜欢",
    "爱", "不舍", "心疼", "😭", "😢", "🥹", "😍", "😡",
)


def build_media_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> str:
    lines: list[str] = []
    lines.append(f"# 动漫/影视内容简报：{video.title or video.video_id}")
    lines.append("")
    lines.append(
        "> 视频类型：动漫/影视/音乐剪辑。当前没有接入视觉模型，"
        "以下只基于标题、简介、评论和字幕；不能可靠识别画面人物、表情或演出情绪。"
    )
    lines.append("")
    lines.append("## 0. 一句话结论")
    lines.append(
        "这是一条动漫/影视内容视频；当前能从文字和评论确认主题，"
        "但人物关系、画面内容和情绪仍需要关键帧或视觉模型确认。"
    )
    lines.append("")

    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append("| 类型 | 动漫/影视内容 | 标题/简介/评论关键词 | [推断] |")
    lines.append("")

    lines.append("## 2. 作品与人物线索")
    lines.append("")
    if classification.media_hits:
        lines.append(
            f"- 媒体/角色关键词：{'、'.join(classification.media_hits[:15])}（可能来自评论玩梗，需核对）"
        )
    if video.description:
        lines.append("- 简介：" + _clip(video.description.replace("\n", " "), 500))
    if not video.description and not video.subtitles and not video.chapters:
        lines.append("- [未知] 页面没有提供足够的作品或人物信息。")
    lines.append("")

    lines.append("## 3. 剧情 / 时间线")
    lines.append("")
    _append_timeline(lines, video)
    if not video.subtitles and not video.chapters:
        lines.append("")
        lines.append(
            "> 动漫剪辑常常只有音乐、歌词或字幕特效；没有字幕/ASR 时无法还原时间线。"
        )
    lines.append("")

    lines.append("## 4. 情绪与氛围线索")
    lines.append("")
    emotion_lines: list[str] = []
    for seg in video.subtitles:
        if any(hint in seg.text for hint in EMOTION_HINTS):
            emotion_lines.append(
                f"- [{format_seconds(seg.start)}] {_clip(seg.text, 160)}（字幕）"
            )
    if emotion_lines:
        lines.extend(list(dict.fromkeys(emotion_lines))[:8])
        lines.append("")
        lines.append("> 以上只是文字/评论里的情绪词，不代表画面人物的真实情绪。")
    else:
        lines.append("- [未知] 没有从字幕或评论中提取到明确的情绪词。")
        lines.append("- [未知] 画面表情、演出和氛围需要视觉模型分析。")
    lines.append("")

    lines.append("## 5. 未知与限制")
    lines.append("")
    lines.append("- 没有视觉模型和关键帧 OCR，无法确认画面人物、构图、分镜和表情。")
    lines.append(
        "- ASR 对日文、音乐、歌词和多人重叠说话可能识别为空；"
        "当前会在中文识别为空后自动检测语言重试。"
    )
    lines.append("- 评论区可能在玩梗或争论，不能把评论当成剧情事实。")
    lines.append("- 这类视频不是软件项目，不生成代码复刻路径。")
    for warning in video.warnings[:4]:
        lines.append(f"- [提示] {warning}")
    lines.append("")

    lines.append("## 6. 观众反馈（高赞节选，仅作旁证）")
    lines.append("")
    top_comments = _top_comments(video, 3, include_author=False)
    if top_comments:
        for comment in top_comments:
            lines.append(
                f"- {comment.author}（{comment.likes} 赞）："
                f"{_clip(comment.text, 160)}"
            )
    else:
        lines.append("- 没有可用的高赞评论。")
    lines.append("")
    lines.append("> 评论只作为观众反馈，不作为视频内容或角色事实。")
    lines.append("")

    lines.append("## 7. 证据索引")
    lines.append("")
    _append_evidence(lines, video, comments_limit=3, include_author=False)
    lines.append("")
    return "\n".join(lines)


def build_media_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
) -> str:
    return f"""你是我动漫/影视内容分析助手。请严格按下面的证据工作。

## 视频
- 标题：{video.title}
- 地址：{video.url}

## 任务
1. 区分“视频文字/评论线索”和“从画面推断的内容”。
2. 没有视觉证据时，不要判断角色表情、人物关系或情绪。
3. 如果用户要分析人物情感，先列出需要截图/关键帧的时间点，再基于画面回答。
4. 不要编造角色名、作品名、剧情、台词或声优；不确定就写 [未知]。
5. 评论区的玩梗和争论不能当作事实。

## 简报
{brief_md}
"""


GAME_ADVICE_TERMS = (
    "建议", "必抽", "不抽", "优先", "推荐", "强度", "技能", "够",
    "不够", "抽", "保底", "半周年", "商店", "资源", "避坑", "值得",
    "不要", "总结", "版本", "规划", "角色",
)
GAME_RESOURCE_TERMS = (
    "抽", "保底", "半周年", "商店", "资源", "够", "不够", "钻",
    "石", "币", "氪", "预算", "规划",
)
GAME_AD_TERMS = (
    "加速器", "biubiu", "口令", "免费加速", "周边好礼", "广告", "赞助",
    "下载卡顿", "更新卡顿", "推广",
)
GAME_DETAIL_TERMS = (
    "伤害", "属性", "冷却", "SP", "生命", "倍率", "范围", "连锁",
    "魔法力", "爆发", "增益", "消耗", "回合", "概率",
)
GAME_FILLER = {
    "然后", "然后呢", "接下来", "不过", "不过的话", "所以", "所以的话",
    "因为", "因为的话", "但是", "当然", "当然呢", "首先", "那首先",
    "的话", "好的", "嗯", "啊", "呃",
}
GAME_LOW_VALUE_PREFIXES = (
    "我们才能", "具体的话", "所以说", "然后我们就", "接下来我们",
)


def _is_game_ad(text: str) -> bool:
    low = (text or "").lower()
    return any(term in low for term in GAME_AD_TERMS)


def _is_low_value_game_text(text: str) -> bool:
    value = text.strip("，。！？、；： ")
    if value.startswith(GAME_LOW_VALUE_PREFIXES):
        return True
    if value.endswith("的话") and len(value) <= 14:
        return True
    return False


def _quote_key(text: str) -> str:
    value = re.sub(r"[，。！？、；：\s]", "", text or "")
    for particle in ("呢", "的", "了", "啊", "吧"):
        value = value.replace(particle, "")
    return value[:40]


def _game_content_segments(video: VideoEvidence) -> list:
    return [
        seg
        for seg in video.subtitles
        if seg.text.strip()
        and not _is_game_ad(seg.text)
        and not _is_low_value_game_text(seg.text)
        and not (
            len(seg.text.strip()) < 30
            and seg.text.strip().startswith(("哈喽", "哈啰", "大家好"))
        )
        and seg.text.strip("，。！？、；： ") not in GAME_FILLER
    ]


def _chapter_ranges(video: VideoEvidence) -> list[tuple[str, float, float]]:
    if video.chapters:
        return [
            (
                chapter.title,
                chapter.start,
                video.chapters[index + 1].start
                if index + 1 < len(video.chapters)
                else float("inf"),
            )
            for index, chapter in enumerate(video.chapters)
        ]
    return [("视频", 0.0, float("inf"))]


def _game_quote_score(seg, chapter_title: str = "") -> int:
    text = seg.text
    score = 0
    for term in GAME_ADVICE_TERMS:
        if term in text:
            score += 2
    for term in GAME_DETAIL_TERMS:
        if term in text:
            score += 3
    if any(char.isdigit() for char in text):
        score += 4
    if chapter_title and chapter_title in text:
        score += 2
    if len(text) >= 10:
        score += 1
    if "?" in text or "？" in text:
        score += 1
    return score


def _game_quotes(
    video: VideoEvidence,
    per_chapter: int = 5,
    max_total: int = 40,
) -> list[tuple[str, object]]:
    segments = _game_content_segments(video)
    quotes: list[tuple[str, object]] = []
    for title, start, end in _chapter_ranges(video):
        window = [seg for seg in segments if start <= seg.start < end]
        if not window:
            continue
        selected = []
        ranked = sorted(
            window,
            key=lambda seg: (-_game_quote_score(seg, title), seg.start),
        )
        for seg in ranked:
            if len(selected) >= per_chapter:
                break
            if any(abs(seg.start - item.start) < 0.2 for item in selected):
                continue
            selected.append(seg)
        selected.sort(key=lambda seg: seg.start)
        for seg in selected:
            quotes.append((title, seg))

    unique: list[tuple[str, object]] = []
    seen: set[tuple[str, str]] = set()
    for chapter_title, seg in quotes:
        key = (chapter_title, _quote_key(seg.text))
        if key in seen:
            continue
        seen.add(key)
        unique.append((chapter_title, seg))
    return unique[:max_total]


def _game_resource_points(video: VideoEvidence, limit: int = 12) -> list:
    rows = []
    for seg in _game_content_segments(video):
        if not any(term in seg.text for term in GAME_RESOURCE_TERMS):
            continue
        rows.append(seg)
    rows.sort(
        key=lambda seg: (
            -_game_quote_score(seg),
            seg.start,
        )
    )
    unique = []
    seen = set()
    for seg in rows:
        key = _quote_key(seg.text)
        if key in seen:
            continue
        seen.add(key)
        unique.append(seg)
    return sorted(unique[:limit], key=lambda seg: seg.start)


def build_game_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> str:
    lines: list[str] = []
    lines.append(f"# 游戏攻略简报：{video.title or video.video_id}")
    lines.append("")
    lines.append(
        "> 视频类型：游戏攻略/抽卡规划。以下优先整理博主在章节和字幕里的观点，"
        "评论只保留高赞节选作为旁证。"
    )
    lines.append("")
    lines.append("## 0. 一句话结论")
    chapter_titles = [
        chapter.title
        for chapter in video.chapters
        if chapter.title and chapter.title != "引言"
    ][:8]
    if chapter_titles:
        focus = "、".join(chapter_titles)
    else:
        focus = "角色技能、抽卡规划和版本建议"
    lines.append(
        f"这是一条围绕 **{focus}** 展开的游戏攻略；"
        "具体数值、概率和版本信息应以游戏内或官方公告为准。"
    )
    lines.append("")

    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append("| 类型 | 游戏攻略/抽卡规划 | 标题/章节/标签关键词 | [推断] |")
    if video.tags:
        lines.append(
            f"| 标签 | {'、'.join(video.tags[:10])} | B 站页面 | [确认] |"
        )
    if video.chapters:
        lines.append(f"| 章节数 | {len(video.chapters)} | B 站页面 | [确认] |")
    lines.append("")

    lines.append("## 2. 博主观点（按章节/时间线）")
    lines.append("")
    quotes = _game_quotes(video)
    if quotes:
        current_chapter = ""
        chapter_start = 0.0
        for chapter_title, seg in quotes:
            if chapter_title != current_chapter:
                chapter_start = next(
                    (
                        chapter.start
                        for chapter in video.chapters
                        if chapter.title == chapter_title
                    ),
                    0.0,
                )
                lines.append(
                    f"### [{format_seconds(chapter_start)}] {chapter_title}"
                )
                current_chapter = chapter_title
            lines.append(
                f"- [{format_seconds(seg.start)}] {_clip(seg.text, 180)}"
            )
    else:
        lines.append(
            "[未知] 没有可用字幕/ASR，无法提取博主的原话；"
            "章节标题只能说明视频结构，不能替代具体观点。"
        )
    lines.append("")
    lines.append(
        "> 以上是博主的字幕/ASR 原话节选，已过滤加速器等口播广告；"
        "不是对博主观点的二次推断。"
    )
    lines.append("")

    lines.append("## 3. 抽卡 / 资源规划要点")
    lines.append("")
    resource_quotes = _game_resource_points(video)
    if resource_quotes:
        for seg in resource_quotes:
            lines.append(f"- [{format_seconds(seg.start)}] {_clip(seg.text, 180)}")
    else:
        lines.append("[未知] 没有从字幕中提取到明确的抽卡数量或资源规划。")
    lines.append("")
    lines.append(
        "> 抽数、概率、技能倍率和版本日期必须以游戏内文本或官方公告为准；"
        "ASR 可能把数字和专有名词识别错。"
    )
    lines.append("")

    lines.append("## 4. 观众反馈（高赞节选，仅作旁证）")
    lines.append("")
    top_comments = _top_comments(video, 3, include_author=False)
    if top_comments:
        for comment in top_comments:
            lines.append(
                f"- {comment.author}（{comment.likes} 赞）："
                f"{_clip(comment.text, 160)}"
            )
    else:
        lines.append("- 没有可用的高赞评论。")
    lines.append("")
    lines.append("> 评论只代表观众反应，不作为角色强度、抽卡数量或版本事实。")
    lines.append("")

    lines.append("## 5. 未知与限制")
    lines.append("")
    lines.append("- 没有视觉模型，无法核对游戏画面、角色立绘、技能演示和实际数值。")
    lines.append("- 字幕/ASR 可能出现角色名、技能名或数字错误，引用时请以游戏内文本为准。")
    lines.append("- 已按关键词过滤视频中的加速器口播广告；仍可能有漏网片段。")
    lines.append("- 评论区可能包含玩梗、晒抽和争论，已只保留高赞旁证。")
    lines.append("- 这类视频不是软件项目，不生成代码复刻路径。")
    for warning in video.warnings[:4]:
        lines.append(f"- [提示] {warning}")
    lines.append("")

    lines.append("## 6. 证据索引")
    lines.append("")
    _append_evidence(lines, video, comments_limit=3, include_author=False)
    lines.append("")
    return "\n".join(lines)


def build_game_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
) -> str:
    return f"""你是我游戏攻略内容整理助手。请严格按下面的证据工作。

## 视频
- 标题：{video.title}
- 地址：{video.url}

## 任务
1. 优先整理博主在章节和字幕里的原话，不要用评论区替代视频内容。
2. 区分“视频原话”“官方/游戏内事实”“推断”和“未知”。
3. 不编造角色技能、数值、概率、版本日期或抽卡建议；不确定就写 [未知]。
4. 评论区只作为观众反馈，不作为事实依据。
5. 如果证据不足，明确列出缺少哪些字幕或官方资料，不要反问我“想分析什么”。

## 简报
{brief_md}
"""


GAME_REVIEW_FILLER_TERMS = (
    "录制", "视频", "分钟", "关注", "三连", "拜拜", "到此结束",
    "发在评论", "不要吵架", "求个", "求求", "友善讨论", "和谐讨论",
    "以你为准", "我讲的都是错的", "你讲的才是对的", "不要骂我",
    "剪辑", "背景音", "不包含任何客观评价", "完全主观",
    "全程由我主观", "主观来评价", "你觉得喜欢你就行",
)
GAME_REVIEW_META_PREFIXES = (
    "大家好", "这里是", "本期视频", "那么这期", "话不多说",
)
GAME_REVIEW_RANKING_TERMS = (
    "排到", "排名", "给到", "档位", "人上人", "拉完", "中间",
    "npc", "t0", "t1", "t2", "夯", "拉",
)
GAME_REVIEW_EVAL_TERMS = (
    "一般", "不错", "很好", "垃圾", "喜欢", "不喜欢", "开放",
    "可玩", "发挥", "皮肤", "xp", "评价",
    "缺点", "优点", "进步", "保守", "救不了", "平衡",
    "萌点", "背德感", "自然", "痛", "爽",
)
GAME_REVIEW_POSITIVE_TERMS = (
    "不错", "很好", "喜欢", "进步", "萌点", "推荐",
    "已经做得很不错", "高",
)
GAME_REVIEW_NEGATIVE_TERMS = (
    "一般", "垃圾", "拉完", "不喜欢", "救不了", "保守", "退步",
    "缺点", "没有完全发挥", "低", "不是很喜欢", "不是很敢",
    "痛", "不爽", "不满意", "不多", "没有体现", "不太", "没有",
)
GAME_REVIEW_EXPLICIT_TERMS = (
    "胸", "屁股", "内衣", "胸罩", "内裤", "裤", "腿", "上药",
    "s属性", "m属性", "sm", "色色", "摸", "脱", "裸露", "私密",
)


def _review_hints(video: VideoEvidence) -> str:
    return " ".join(
        [video.title, video.description]
        + list(video.tags)
        + [chapter.title for chapter in video.chapters]
    )


def _review_text(video: VideoEvidence, seg) -> str:
    text = (seg.text or "").strip()
    if re.search(r"[\u3040-\u30ff]", text):
        return text
    return normalize_text(text, _review_hints(video))


def _review_clean_quote(text: str) -> str:
    value = re.sub(
        r"^(?:(?:所以呢|所以|那么|好吧|唉|呃|嗯|恩|这个|那个|然后呢?|就是)"
        r"[，,。\s]*)+",
        "",
        (text or "").strip(),
    )
    value = re.sub(r"[啊呃嗯吧]+$", "", value).strip()
    for marker in (
        "剧情大概讲", "大概讲的是", "然后我们就", "故事讲的是",
        "是在找", "讲的是", "然后让店长", "然后呢",
    ):
        if marker not in value:
            continue
        head = value.split(marker, 1)[0].strip("，。； ")
        if head and any(
            term in head
            for term in ("一般", "不错", "喜欢", "不喜欢", "垃圾", "开放", "可玩", "发挥", "评价", "低", "高")
        ):
            value = head
        else:
            value = ""
        break
    value = re.sub(r"(?<![，。；！？])(所以|但是|因为)", r"；\1", value)
    value = re.sub(r"(位置)(人上人)", r"\1；\2", value)
    value = value.lstrip("；，。 ")
    return value


def _review_is_filler(text: str) -> bool:
    value = (text or "").strip()
    if len(value) < 4 and _review_rank_score(value) == 0:
        return True
    if any(term in value for term in GAME_REVIEW_FILLER_TERMS):
        return True
    if value.startswith(GAME_REVIEW_META_PREFIXES):
        return True
    low = value.lower()
    if any(term in low for term in GAME_REVIEW_EXPLICIT_TERMS):
        return True
    return False


def _review_chapters(video: VideoEvidence) -> list[tuple[str, float, float]]:
    skip = ("引言", "结尾", "开场", "本期三个角色", "本期四个角色")
    ranges = [
        (title, start, end)
        for title, start, end in _chapter_ranges(video)
        if not any(term in title for term in skip)
    ]
    return ranges or [("视频", 0.0, float("inf"))]


def _review_rank_score(text: str) -> int:
    low = text.lower()
    score = sum(5 for term in GAME_REVIEW_RANKING_TERMS if term in low)
    if any(term in low for term in ("人上人", "拉完", "中间", "npc", "t0", "t1")):
        score += 5
    return score


def _review_tendency(texts: list[str]) -> str:
    joined = " ".join(texts).lower()
    positive = sum(1 for term in GAME_REVIEW_POSITIVE_TERMS if term in joined)
    negative = sum(1 for term in GAME_REVIEW_NEGATIVE_TERMS if term in joined)
    if "拉完" in joined:
        negative += 3
    if "人上人" in joined:
        positive += 2
    if "中间" in joined or "npc" in joined:
        positive += 1
    if positive == 0 and negative == 0:
        return "未知"
    if negative >= positive * 4:
        return "偏负面"
    if positive >= negative * 4:
        return "偏正面"
    return "混合"


def _review_tier_phrase(text: str) -> str:
    low = (text or "").lower()
    if "中间" in low and "npc" in low:
        return "中间NPC"
    found: list[str] = []
    if "不上不下" in low:
        found.append("不上不下")
    if "人上人" in low:
        found.append("人上人")
    if "拉完" in low:
        found.append("拉完")
    if "中间" in low:
        found.append("中间")
    for level in ("t0", "t1", "t2", "t3"):
        if level in low:
            found.append(level.upper())
    if "不上不下" in found and "中间" in found:
        found.remove("不上不下")
    return " / ".join(dict.fromkeys(found))


def _review_items(video: VideoEvidence) -> list[dict]:
    items: list[dict] = []
    for subject, start, end in _review_chapters(video):
        cleaned: list[tuple[object, str]] = []
        for seg in video.subtitles:
            if not (start <= seg.start < end):
                continue
            text = _review_clean_quote(_review_text(video, seg))
            if not text or _review_is_filler(text):
                continue
            cleaned.append((seg, text))
        if not cleaned:
            continue

        ranking = []
        for seg, text in cleaned:
            rank_score = _review_rank_score(text)
            if rank_score > 0:
                ranking.append((rank_score, seg, text))
        ranking.sort(key=lambda item: item[1].start)
        ranking = ranking[-2:]

        scored = []
        for seg, text in cleaned:
            score = 0
            eval_hits = 0
            low = text.lower()
            for term in GAME_REVIEW_EVAL_TERMS:
                if term in low:
                    score += 3
                    eval_hits += 1
            if subject and subject in text:
                score += 2
            if len(text) >= 10:
                score += 1
            if eval_hits > 0:
                scored.append((score, seg, text))
        scored.sort(key=lambda item: (-item[0], item[1].start))
        evaluation = list(scored[:4])
        for rank_item in ranking:
            if not any(
                abs(rank_item[1].start - seg.start) < 0.2
                for _, seg, _ in evaluation
            ):
                evaluation.append(rank_item)
        evaluation.sort(key=lambda item: item[1].start)
        deduped = []
        seen_eval: set[str] = set()
        for item in evaluation:
            key = _quote_key(item[2])
            if key in seen_eval:
                continue
            seen_eval.add(key)
            deduped.append(item)
        evaluation = [
            item
            for item in deduped
            if not any(
                item[2] != other[2] and item[2] in other[2]
                for other in deduped
            )
        ]
        evaluation = evaluation[:6]

        rank_text = (
            "；".join(_clip(text, 90) for _, _, text in ranking)
            if ranking
            else "未明确给出档位"
        )
        tier = _review_tier_phrase(rank_text) if ranking else ""
        items.append(
            {
                "subject": subject,
                "start": start,
                "ranking": ranking,
                "evaluation": evaluation,
                "rank_text": rank_text,
                "tier": tier or "未明确给出档位",
                "tendency": _review_tendency(
                    [text for _, _, text in evaluation]
                ),
            }
        )
    return items


def _review_advice(video: VideoEvidence) -> list:
    terms = ("抽", "推荐", "图鉴", "值得", "抽取", "建议", "适用")
    rows = []
    for seg in video.subtitles:
        text = _review_clean_quote(_review_text(video, seg))
        if not text or _review_is_filler(text):
            continue
        if any(term in text for term in terms):
            rows.append(seg)
    return rows[:6]


def build_game_review_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> str:
    lines: list[str] = []
    items = _review_items(video)
    lines.append(f"# 游戏测评/排行简报：{video.title or video.video_id}")
    lines.append("")
    lines.append(
        "> 视频类型：游戏测评/主观排行。以下优先整理博主的档位结论、"
        "逐项评价和理由；评论只保留高赞节选作为旁证。"
    )
    lines.append("")
    lines.append("## 0. 一句话结论")
    rank_parts = [
        f"{item['subject']}：{item['tier']}"
        for item in items
        if item["tier"] != "未明确给出档位"
    ]
    if rank_parts:
        lines.append(
            "这是一条主观测评/排行视频。字幕中可确认的档位是："
            + "；".join(rank_parts)
            + "。这是博主的主观评价，不是客观强度榜。"
        )
        lowest = [
            item["subject"] for item in items if "拉完" in item["tier"]
        ]
        middle = [
            item["subject"]
            for item in items
            if "中间" in item["tier"] or "人上人" in item["tier"]
        ]
        if lowest:
            summary = f"整体上，{'、'.join(lowest)}被放在最低档"
            if middle:
                summary += f"，{'、'.join(middle)}位于中间档"
            lines.append(summary + "。")
        review_text = " ".join(
            text
            for item in items
            for _, _, text in item["evaluation"]
        )
        dimensions = []
        if "开放" in review_text or "可玩" in review_text:
            dimensions.append("互动内容开放度/可玩点")
        if "皮肤" in review_text or "发挥" in review_text:
            dimensions.append("皮肤与角色特点发挥")
        if "喜欢" in review_text or "xp" in review_text.lower():
            dimensions.append("个人审美/角色偏好")
        if "师生" in review_text or "剧情" in review_text:
            dimensions.append("剧情设定")
        if dimensions:
            lines.append("评价维度主要集中在：" + "、".join(dimensions) + "。")
    else:
        lines.append(
            "视频标题声称是排行，但字幕没有提取到完整名次；"
            "以下按章节整理博主的评价和理由。"
        )
    lines.append("")

    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append("| 类型 | 游戏测评/主观排行 | 标题/章节/标签关键词 | [推断] |")
    if video.tags:
        lines.append(
            f"| 标签 | {'、'.join(video.tags[:10])} | B 站页面 | [确认] |"
        )
    if video.chapters:
        lines.append(f"| 章节数 | {len(video.chapters)} | B 站页面 | [确认] |")
    lines.append("")

    lines.append("## 2. 排行 / 档位结论")
    lines.append("")
    if items:
        lines.append("| 对象 | 时间 | 档位/结论 | 博主原话依据 | 倾向（推断） |")
        lines.append("| --- | --- | --- | --- | --- |")
        for item in items:
            rank_start = item["ranking"][0][1].start if item["ranking"] else None
            where = format_seconds(rank_start) if rank_start is not None else "-"
            lines.append(
                f"| {item['subject']} | {where} | {item['tier']} | "
                f"{_clip(item['rank_text'], 150)} | {item['tendency']} |"
            )
        lines.append("")
        lines.append(
            "> 档位列是字幕原话的压缩，不是插件重新排名；"
            "没有明确档位的对象会写“未明确给出档位”。"
        )
    else:
        lines.append("[未知] 没有可用字幕或章节，无法提取档位结论。")
    lines.append("")

    lines.append("## 3. 逐项评价（按章节）")
    lines.append("")
    if items:
        for item in items:
            lines.append(
                f"### [{format_seconds(item['start'])}] {item['subject']}"
            )
            if item["evaluation"]:
                for _, seg, text in item["evaluation"]:
                    lines.append(
                        f"- [{format_seconds(seg.start)}] {_clip(text, 180)}"
                    )
            else:
                lines.append("- [未知] 本章没有提取到可用的评价句。")
            lines.append("")
        lines.append(
            "> 已过滤录制吐槽、求关注和露骨互动细节；"
            "以上只保留与评价、档位和理由相关的原话。"
        )
    else:
        lines.append("[未知] 没有可用字幕，无法逐项评价。")
    lines.append("")

    lines.append("## 4. 抽取 / 适用建议（仅视频原话）")
    lines.append("")
    advice = _review_advice(video)
    if advice:
        for seg in advice:
            text = _review_clean_quote(_review_text(video, seg))
            lines.append(f"- [{format_seconds(seg.start)}] {_clip(text, 180)}")
        lines.append("")
        lines.append(
            "> 以上是视频里出现的抽取/适用表述；主观喜好不等于客观强度。"
        )
    else:
        lines.append(
            "- [未知] 视频主要是主观评价，没有给出明确的抽卡或资源规划。"
        )
    lines.append("")

    lines.append("## 5. 观众反馈（高赞节选，仅作旁证）")
    lines.append("")
    top_comments = _top_comments(video, 3, include_author=False)
    if top_comments:
        for comment in top_comments:
            lines.append(
                f"- {comment.author}（{comment.likes} 赞）："
                f"{_clip(comment.text, 160)}"
            )
    else:
        lines.append("- 没有可用的高赞评论。")
    lines.append("")
    lines.append("> 评论只代表观众反应，不作为角色强度或档位事实。")
    lines.append("")

    lines.append("## 6. 未知与限制")
    lines.append("")
    lines.append("- 这是博主的主观排行，不是官方或客观强度榜。")
    lines.append("- 没有视觉模型，无法核对立绘、互动画面和实际演出；需要时请提供关键帧。")
    lines.append("- 字幕/ASR 可能把角色名、档位名和数字识别错，引用时请以视频画面为准。")
    lines.append("- 摘要已过滤露骨互动细节，只保留评价、档位和理由。")
    lines.append("- 这类视频不是软件项目，不生成代码复刻路径。")
    for warning in video.warnings[:4]:
        lines.append(f"- [提示] {warning}")
    lines.append("")

    lines.append("## 7. 证据索引")
    lines.append("")
    _append_evidence(lines, video, comments_limit=3, include_author=False)
    lines.append("")
    return "\n".join(lines)


def build_game_review_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
) -> str:
    return f"""你是我游戏测评/排行内容整理助手。请严格按下面的证据工作。

## 视频
- 标题：{video.title}
- 地址：{video.url}

## 任务
1. 优先提取博主的排名/档位、逐项评价、优缺点和适用人群。
2. 把主观评价标注为“博主观点”，不要写成客观强度事实。
3. 不编造未出现的名次、数值、角色、剧情或声优；不确定就写 [未知]。
4. 没有视觉证据时，不判断立绘、表情或画面演出；需要时列出关键帧时间点。
5. 评论只作为观众反馈，不作为档位或强度依据。
6. 用中性语言概括，不输出露骨互动细节。
7. 不要反问“想分析什么”；证据不足时直接列出缺失项。

## 简报
{brief_md}
"""


SCIENCE_HEALTH_TERMS = (
    "医学", "医学生", "医生", "临床", "健康", "减肥", "减脂", "瘦身",
    "减重", "营养", "药物", "药品", "otc", "处方", "剂量", "副作用",
    "禁忌", "疾病", "治疗", "手术", "保健品", "奥利司他", "脂肪",
    "代谢", "血糖", "血压", "免疫力",
)
SCIENCE_CLAIM_TERMS = (
    "唯一", "批准", "上市", "临床", "研究", "论文", "指南", "证据",
    "otc", "处方", "药物", "药品", "减肥", "减脂", "瘦", "斤",
    "体重", "脂肪", "原理", "阻断", "排出", "副作用", "反弹",
    "掉了", "瘦了",
    "禁忌", "剂量", "治疗", "手术", "保健品", "奥利司他",
)
SCIENCE_PROMO_TERMS = (
    "链接", "优惠", "回购", "评论区", "下单", "购买", "带货",
    "佣金",
)
SCIENCE_FILLER_TERMS = (
    "大家好", "本期视频", "关注", "三连", "点赞", "拜拜",
    "不要骂我", "求个", "平台也不允许", "看看到底", "打算",
    "准备就绪",
)
SCIENCE_METHODS = {
    "饮食": "饮食控制",
    "运动": "运动",
    "节食": "节食",
    "代餐": "代餐",
    "药物": "药物/补充剂",
    "药品": "药物/补充剂",
    "otc": "药物/补充剂",
    "奥利司他": "药物/补充剂",
    "手术": "手术",
    "热量": "热量管理",
    "作息": "作息",
    "睡眠": "睡眠",
}


def _science_text(video: VideoEvidence, seg) -> str:
    return _review_text(video, seg)


def _science_is_promo(text: str) -> bool:
    low = (text or "").lower()
    return any(term in low for term in SCIENCE_PROMO_TERMS)


def _science_is_filler(text: str) -> bool:
    value = (text or "").strip()
    if len(value) < 4:
        return True
    if any(term in value for term in SCIENCE_FILLER_TERMS):
        return True
    return False


def _science_claim_type(text: str) -> tuple[str, str]:
    value = text or ""
    low = value.lower()
    if any(term in low for term in ("唯一", "批准", "上市", "临床", "指南", "研究", "论文", "证据")):
        return "官方/指南待核实", "[待核实]"
    if any(term in low for term in ("我", "个人", "掉了", "瘦了", "斤", "体重", "感觉")):
        return "个人体验", "[个案，不能外推]"
    if any(term in low for term in ("原理", "因为", "所以", "阻断", "排出", "机制")):
        return "机制解释", "[待核实]"
    if any(term in low for term in ("otc", "处方", "药店", "医院")):
        return "用药信息", "[需看说明书/医嘱]"
    return "视频主张", "[视频原话]"


def _science_claims(video: VideoEvidence, limit: int = 12) -> list:
    rows = []
    for seg in video.subtitles:
        text = _review_clean_quote(_science_text(video, seg))
        if not text or _science_is_filler(text) or _science_is_promo(text):
            continue
        low = text.lower()
        hits = sum(1 for term in SCIENCE_CLAIM_TERMS if term in low)
        if hits <= 0:
            continue
        score = hits * 3
        if any(char.isdigit() for char in text):
            score += 2
        if any(term in low for term in SCIENCE_HEALTH_TERMS):
            score += 1
        rows.append((score, seg, text))
    rows.sort(key=lambda item: (-item[0], item[1].start))
    selected = rows[:limit]
    selected.sort(key=lambda item: item[1].start)
    return selected


def _science_methods(video: VideoEvidence) -> list[dict]:
    result = []
    seen: set[str] = set()
    for seg in video.subtitles:
        text = _review_clean_quote(_science_text(video, seg))
        if not text or _science_is_filler(text):
            continue
        low = text.lower()
        for term, label in SCIENCE_METHODS.items():
            if term not in low or label in seen:
                continue
            seen.add(label)
            result.append(
                {
                    "label": label,
                    "time": seg.start,
                    "text": text,
                }
            )
    return result[:8]


def _science_promo(video: VideoEvidence, limit: int = 8) -> list:
    rows = []
    for seg in video.subtitles:
        text = _review_clean_quote(_science_text(video, seg))
        if text and _science_is_promo(text):
            rows.append((seg, text))
    strong = ("链接", "优惠", "评论区", "下单", "购买", "带货", "佣金")
    rows.sort(
        key=lambda item: (
            0 if any(term in item[1] for term in strong) else 1,
            item[0].start,
        )
    )
    return rows[:limit]


def build_science_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> str:
    full_text = " ".join(
        [video.title, video.description, " ".join(video.tags)]
        + [seg.text for seg in video.subtitles]
    )
    health = any(term.lower() in full_text.lower() for term in SCIENCE_HEALTH_TERMS)
    heading = "科普/健康简报" if health else "科普/知识简报"
    claims = _science_claims(video)
    methods = _science_methods(video)
    promo = _science_promo(video)
    topics = "、".join(classification.science_hits[:6]) or "视频主题"
    core = ""
    for index, (_, core_seg, text) in enumerate(claims):
        if "唯一" not in text and "批准" not in text and "上市" not in text:
            continue
        core = text
        for candidate in video.subtitles:
            if not (core_seg.start < candidate.start <= core_seg.start + 12):
                continue
            next_text = _review_clean_quote(_science_text(video, candidate))
            if "奥利司他" in next_text or "就只有" in next_text:
                core += "；" + next_text
                break
        break

    lines: list[str] = []
    lines.append(f"# {heading}：{video.title or video.video_id}")
    lines.append("")
    lines.append(
        "> 视频类型：科普/个人经验/健康话题。"
        "以下整理博主的主张、方法、证据类型和需要核实的地方；这不是医疗建议。"
    )
    lines.append("")
    lines.append("## 0. 一句话结论")
    if core:
        lines.append(
            f"这是一条关于 **{topics}** 的科普/个人经验视频。"
            f"博主的核心主张是：{_clip(core, 120)}。"
            "其中批准范围、个人效果和安全性需要按官方说明书、指南或医生意见核实。"
        )
    else:
        lines.append(
            f"这是一条关于 **{topics}** 的科普/个人经验视频；"
            "以下按时间线整理博主主张、方法和需要核实的地方。"
        )
    if promo:
        lines.append("视频还包含购买链接或优惠引导，已在第 4 节单独标出。")
    lines.append("")

    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append(f"| 类型 | {'科普/健康' if health else '科普/知识'} | 标题/标签/字幕关键词 | [推断] |")
    if video.tags:
        lines.append(
            f"| 标签 | {'、'.join(video.tags[:10])} | B 站页面 | [确认] |"
        )
    lines.append("")

    lines.append("## 2. 博主的主要主张（按时间线）")
    lines.append("")
    if claims:
        lines.append("| 时间 | 博主原话/主张 | 类型 | 状态 |")
        lines.append("| --- | --- | --- | --- |")
        for _, seg, text in claims:
            claim_type, status = _science_claim_type(text)
            lines.append(
                f"| {format_seconds(seg.start)} | {_clip(text, 160)} | "
                f"{claim_type} | {status} |"
            )
        lines.append("")
        lines.append(
            "> 类型和状态是插件按措辞做的初步分层；"
            "“官方/指南待核实”不等于视频说错了，只表示需要查原始资料。"
        )
    else:
        lines.append("[未知] 没有从字幕中提取到明确的主张。")
    lines.append("")

    lines.append("## 3. 方法与概念")
    lines.append("")
    if methods:
        lines.append("| 方法/概念 | 视频里的说法 | 时间 |")
        lines.append("| --- | --- | --- |")
        for row in methods:
            lines.append(
                f"| {row['label']} | {_clip(row['text'], 150)} | "
                f"{format_seconds(row['time'])} |"
            )
    else:
        lines.append("- [未知] 没有提取到明确的减肥/健康方法。")
    lines.append("")

    lines.append("## 4. 商业推广提示")
    lines.append("")
    if promo:
        for seg, text in promo:
            lines.append(
                f"- [{format_seconds(seg.start)}] {_clip(text, 160)}"
            )
        lines.append("")
        lines.append(
            "> 视频出现了购买链接、优惠或回购引导。商业推广不等于医学证据；"
            "购买药品前先确认来源、说明书和医生/药师意见。"
        )
    else:
        lines.append("- 没有从字幕中提取到明显的购买链接或优惠引导。")
    lines.append("")

    lines.append("## 5. 安全与核验")
    lines.append("")
    if health:
        lines.append("> 以下不是医疗建议，也不能替代医生、药师或官方说明书。")
        lines.append("")
        lines.append("- 药物有适应症、禁忌、副作用和相互作用，不要仅凭视频自行用药。")
        lines.append("- 短期体重变化可能来自水分、饮食和测量误差，不能证明长期效果。")
        lines.append("- “OTC”不等于“无风险”；孕妇/哺乳期、肝胆疾病、肾功能异常等人群尤其需要先咨询医生。")
        lines.append("- 视频中的个人减重数字是个案，不能直接外推到其他人。")
        lines.append("- 购买链接和优惠属于商业推广，不是临床证据。")
        lines.append("")
        lines.append("优先核实：")
        lines.append("")
        lines.append("1. “唯一批准上市的口服减肥产品”是否准确，注意“口服/OTC/处方”的限定。")
        lines.append("2. 视频里的减重数字是否只覆盖短期，是否同时改变了饮食、运动或水分。")
        lines.append("3. 副作用、停药反弹和药物相互作用是否在说明书里有明确说明。")
    else:
        lines.append("> 以下是一般事实核验提示，不是专业结论。")
        lines.append("")
        lines.append("- 把视频主张和教材、指南、原始研究区分开。")
        lines.append("- 单一视频和单一个案不能替代系统证据。")
        lines.append("- 涉及数字、研究结论和机构名称时，优先查原始来源。")
    lines.append("")

    lines.append("## 6. 观众反馈（高赞节选，仅作旁证）")
    lines.append("")
    top_comments = _top_comments(video, 3, include_author=False)
    if top_comments:
        for comment in top_comments:
            lines.append(
                f"- {comment.author}（{comment.likes} 赞）："
                f"{_clip(comment.text, 160)}"
            )
    else:
        lines.append("- 没有可用的高赞评论。")
    lines.append("")
    lines.append("> 评论只代表观众反应，不作为医学事实或产品效果依据。")
    lines.append("")

    lines.append("## 7. 未知与限制")
    lines.append("")
    lines.append("- 没有视觉模型，无法核对药品包装、OTC 标识、溯源码或学生证件的画面。")
    lines.append("- 没有联网核对官方说明书、批准范围、价格和临床指南。")
    lines.append("- 视频是个人经验/科普表达，不是临床试验或系统综述。")
    lines.append("- 这类视频不是软件项目，不生成代码复刻路径。")
    for warning in video.warnings[:4]:
        lines.append(f"- [提示] {warning}")
    lines.append("")

    lines.append("## 8. 证据索引")
    lines.append("")
    _append_evidence(lines, video, comments_limit=3, include_author=False)
    lines.append("")
    return "\n".join(lines)


def build_science_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
) -> str:
    return f"""你是我科普/健康内容整理助手。请严格按下面的证据工作。

## 视频
- 标题：{video.title}
- 地址：{video.url}

## 任务
1. 区分“博主主张”“个人体验”“官方/指南事实”“推断”和“未知”。
2. 不给出诊断、剂量、用药或治疗建议；这不是医疗建议，涉及药物或疾病时提醒咨询医生/药师。
3. 标出购买链接、优惠、回购引导等商业推广，商业推广不能当作医学证据。
4. 不编造研究、指南、批准范围或临床数据；不确定就写 [待核实]。
5. 没有视觉证据时，不判断药品包装、证件、表情或画面。
6. 不生成代码复刻路径，也不反问“想分析什么”；证据不足时直接列缺失项。

## 简报
{brief_md}
"""


STEP_MARKERS = (
    "第一步", "第二步", "第三步", "第四步", "第五步", "首先", "然后", "接着",
    "接下来", "最后", "方法一", "方法二", "方法三", "第一种", "第二种",
    "第三种", "现在", "下面", "点击", "打开", "下载", "安装", "导入",
    "选择", "搜索", "进入", "返回", "设置", "开始", "输入", "粘贴", "填写",
)


def _clean_step_text(text: str) -> str:
    value = re.sub(r"\s+", " ", text or "").strip()
    value = re.sub(
        r"^(?:(?:那么|然后|接下来|首先|好的|OK|嗯|啊|呃|也是|就是)[，,。\s]*)+",
        "",
        value,
        flags=re.IGNORECASE,
    )
    return value


def _step_title(text: str) -> str:
    clean = _clean_step_text(text)
    if not clean:
        return "步骤"
    clauses = [
        clause.strip()
        for clause in re.split(r"[。！？!?；;，,\s]", clean)
        if clause.strip()
    ]
    fillers = {
        "如你所见", "那么", "然后", "接下来", "首先", "好的", "OK",
        "嗯", "啊", "呃", "现在", "下面",
    }
    for clause in clauses:
        if clause in fillers or len(clause) < 4:
            continue
        return _clip(clause, 40)
    return _clip(clean, 40)


def extract_steps(video: VideoEvidence, max_steps: int = 15) -> list[dict]:
    if video.chapters:
        return [
            {"start": chapter.start, "text": "", "title": chapter.title}
            for chapter in video.chapters[:max_steps]
        ]
    segments = [seg for seg in video.subtitles if seg.text.strip()]
    if not segments:
        return []
    asr = any(seg.source == "asr" for seg in segments)
    gap_limit = 3 if asr else 6
    char_limit = 80 if asr else 180
    if asr:
        max_steps = max(max_steps, 18)

    groups: list[tuple[float, str]] = []
    current = []
    current_start = segments[0].start
    last_end = segments[0].start
    for seg in segments:
        text = seg.text.strip()
        gap = seg.start - last_end
        is_marker = any(
            re.match(rf"^[，,。；;：:\s]*{re.escape(marker)}", text)
            for marker in STEP_MARKERS
        )
        current_len = sum(len(item.text) for item in current)
        if current and (is_marker or gap > gap_limit or current_len > char_limit):
            groups.append((current_start, " ".join(item.text for item in current)))
            current = []
            current_start = seg.start
        current.append(seg)
        last_end = max(last_end, seg.end or seg.start)
    if current:
        groups.append((current_start, " ".join(item.text for item in current)))

    merged: list[tuple[float, str]] = []
    for start, text in groups:
        clean = _clean_step_text(text)
        if not clean:
            continue
        if merged and len(clean) < 4:
            previous_start, previous_text = merged[-1]
            merged[-1] = (previous_start, f"{previous_text} {clean}".strip())
        else:
            merged.append((start, clean))

    if len(merged) > max_steps:
        step = len(merged) / max_steps
        sampled = [merged[int(index * step)] for index in range(max_steps - 1)]
        sampled.append(merged[-1])
        merged = sampled

    return [
        {"start": start, "text": text, "title": _step_title(text)}
        for start, text in merged
    ]


def _usage_links(signals: ExtractedSignals) -> list[dict]:
    rows: list[dict] = []
    seen: set[str] = set()
    for item in signals.urls:
        url = str(item.get("url") or "").strip()
        if not url or "/mall-" in url:
            continue
        key = url.lower()
        if key in seen:
            continue
        seen.add(key)
        host = urlparse(url).netloc.lower()
        if "github.com" in host:
            kind = "官方仓库 / GitHub"
        elif "pan.quark.cn" in host:
            kind = "网盘镜像（第三方）"
        elif "b23.tv" in host or "bilibili.com" in host:
            kind = "B 站补充链接"
        else:
            kind = "其他链接"
        rows.append(
            {
                "kind": kind,
                "url": url,
                "source": SOURCE_LABELS.get(
                    str(item.get("source") or ""), str(item.get("source") or "")
                ),
                "start": item.get("start"),
            }
        )

    for mention in signals.repo_mentions:
        url = f"https://{_display_host(mention.host)}/{mention.full_name}"
        if url.lower() in seen:
            continue
        seen.add(url.lower())
        rows.append(
            {
                "kind": "官方仓库 / GitHub",
                "url": url,
                "source": SOURCE_LABELS.get(mention.source, mention.source),
                "start": mention.start,
            }
        )
    return rows[:10]


def _usage_cautions(video: VideoEvidence) -> list[str]:
    markers = (
        "注意", "失败", "如果", "可能", "需要", "建议", "不要", "否则",
        "问题", "报错", "无法", "记得", "小心",
    )
    rows: list[str] = []
    for seg in video.subtitles:
        text = seg.text.strip()
        if any(marker in text for marker in markers):
            rows.append(f"- [{format_seconds(seg.start)}] {_clip(text, 160)}")
    for comment in _top_comments(video, 5):
        text = comment.text.strip()
        if not text or (text.count("http") >= 1 and len(text) < 120):
            continue
        if any(marker in text for marker in markers):
            rows.append(f"- 评论（{comment.author}）：{_clip(comment.text, 160)}")
    return list(dict.fromkeys(rows))[:8]


def _usage_platform(video: VideoEvidence, selected: RepoCandidate | None) -> str:
    text = " ".join(
        [
            video.title,
            video.description,
            " ".join(comment.text for comment in video.comments[:10]),
        ]
    ).lower()
    if any(value in text for value in ("安卓", "android", "apk", "手机", "iphone", "ios", "苹果")):
        if any(value in text for value in ("ios", "iphone", "苹果")):
            return "手机应用（iOS/Android，需确认）"
        return "手机应用（Android）"
    if selected and selected.language.lower() in {"kotlin", "java"}:
        return "手机应用（Android，推断）"
    if any(value in text for value in ("windows", "macos", "linux", "桌面", "电脑")):
        return "桌面软件"
    if any(value in text for value in ("网页", "web", "浏览器", "网站")):
        return "Web 应用"
    return "[未知]"


def _hardware_profile(video: VideoEvidence) -> str:
    text = " ".join(
        [
            video.title,
            video.description,
            video.transcript_text(),
            " ".join(comment.text for comment in video.comments[:10]),
        ]
    ).lower()
    if any(
        value in text
        for value in (
            "esp32", "stm32", "arduino", "树莓派", "raspberry", "开发板",
            "烧录", "固件", "gpio", "舵机", "传感器", "接线", "引脚",
        )
    ):
        return "embedded"
    if any(value in text for value in ("手机", "iphone", "安卓", "换屏", "尾插", "充电口")):
        return "phone"
    if any(
        value in text
        for value in ("笔记本", "拯救者", "r9000p", "y9000p", "清灰", "相变片", "硅脂", "散热")
    ):
        return "laptop"
    return "general"


def build_hardware_questions(
    video: VideoEvidence,
    signals: ExtractedSignals,
    classification: VideoClassification,
) -> list[str]:
    profile = _hardware_profile(video)
    if profile == "embedded":
        questions = [
            "你的主控/开发板具体型号是什么（ESP32-S3、STM32F103 等）？",
            "你准备用哪套工具链（Arduino IDE、PlatformIO、Keil、ESP-IDF）？",
            "你手里有哪些外设？舵机/传感器/电源的具体型号和供电要求是什么？",
            "接线、烧录和供电方案是否已经确认？",
            "你是要复刻整套硬件，还是只改固件/代码？",
        ]
    elif profile == "phone":
        questions = [
            "你的手机具体型号和系统版本是什么？",
            "你要换的是屏幕、电池、尾插还是其他部件？",
            "你是否已经备份数据？手机是否在保修期内？",
            "你手里有哪些工具和备件？",
            "你只需要维修，还是要刷机/改固件？",
        ]
    elif profile == "laptop":
        questions = [
            "你的具体型号和年份是什么（例如 R9000P 2025 还是 2026）？",
            "机器是否还在保修期内？",
            "你准备换的相变片/硅脂尺寸和厚度是多少？",
            "你手里有哪些工具（螺丝刀、撬片、镊子、防静电手环）？",
            "你只需要清灰/换相变片，还是要做完整拆机？",
        ]
    else:
        questions = [
            "你的设备具体型号是什么？",
            "你手里有哪些工具和备件？",
            "你要完成的是拆装、维修、接线还是烧录？",
            "设备的供电方案和风险点确认了吗？",
            "你是要复刻整套设备，还是只做其中一步？",
        ]
    if classification.kind == "hardware_software_mixed":
        questions.extend(
            [
                "你是直接使用作者发布的固件/软件，还是自己编译？",
                "你现在卡在硬件接线、烧录，还是软件配置？",
                "你的开发板/设备版本和视频里一致吗？",
            ]
        )
        if signals.repo_mentions:
            questions.append("仓库里的固件版本和视频演示的版本一致吗？")
    return list(dict.fromkeys(questions))[:8]


def build_usage_questions(
    video: VideoEvidence,
    selected: RepoCandidate | None,
) -> list[str]:
    platform = _usage_platform(video, selected)
    text = " ".join(
        [video.title, video.description, " ".join(comment.text for comment in video.comments)]
    )
    questions: list[str] = []
    if "手机" in platform or "Android" in platform or "iOS" in platform:
        questions.extend(
            [
                "你用的是安卓还是 iOS？手机系统版本是多少？",
                "你是想直接安装作者发布的安装包，还是从源码自己编译？",
            ]
        )
    else:
        questions.extend(
            [
                "你用的是 Windows、macOS 还是 Linux？",
                "你是想直接安装作者发布的版本，还是从源码自己构建？",
            ]
        )
    if "书源" in text:
        questions.append("你希望书源用网络导入还是本地文件导入？")
        questions.append("你现在卡在哪一步：下载、安装、导入书源，还是搜索书籍？")
    else:
        questions.append("你现在卡在哪一步：下载、安装、配置，还是实际使用？")
    questions.append("视频里的网盘 / GitHub 链接还能打开吗？")
    questions.append("你使用的软件版本和视频里一致吗？")
    return questions[:6]


def _usage_app_name(video: VideoEvidence, selected: RepoCandidate | None) -> str:
    match = re.search(
        r"([\u4e00-\u9fffA-Za-z0-9]{2,16}?)(?:0基础|零基础|小白|新手|教程)",
        video.title,
    )
    if match:
        return match.group(1)
    if selected:
        return selected.full_name.split("/")[-1]
    return "这个软件"


def build_usage_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    selected: RepoCandidate | None,
) -> str:
    steps = extract_steps(video)
    links = _usage_links(signals)
    cautions = _usage_cautions(video)
    platform = _usage_platform(video, selected)
    app_name = _usage_app_name(video, selected)

    lines: list[str] = []
    lines.append(f"# 软件使用简报：{video.title or video.video_id}")
    lines.append("")
    lines.append("> 视频类型：软件使用 / 安装教程，不是从源码构建项目的开发教程。")
    lines.append("> 步骤来自视频字幕或章节；时间是视频时间戳，不是操作耗时。")
    if any(seg.source == "asr" for seg in video.subtitles):
        lines.append("> 当前步骤来自本地 ASR，专有名词可能有同音字错误，请以视频画面为准。")
    lines.append("")
    lines.append("## 0. 一句话结论")
    lines.append(
        f"这是一条关于 **{app_name}** 的使用教程。按博主给出的步骤操作即可，"
        "不需要先搭建开发环境。"
    )
    lines.append("")
    lines.append("## 1. 视频信息")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    lines.append(f"| 时长 | {format_seconds(video.duration)} | B 站页面 | [确认] |")
    lines.append(f"| 适用平台 | {platform} | 标题/评论/仓库语言 | [推断] |")
    if selected:
        lines.append(
            f"| 软件仓库 | [{selected.full_name}]({selected.html_url}) | "
            f"{'视频文本直接给出' if selected.source == 'explicit' else '用户确认'} | [确认] |"
        )
        lines.append(
            f"| 许可证 | {selected.license or '未确认'} | 仓库元数据 | "
            f"{'[确认]' if selected.license else '[未知]'} |"
        )
    else:
        lines.append("| 软件仓库 | 未定位 | 视频文本 | [未知] |")
    lines.append("")

    lines.append("## 2. 这个视频在教什么")
    lines.append("")
    if video.description:
        lines.append("- 简介：" + _clip(video.description.replace("\n", " "), 400))
    full_text = " ".join([video.title, video.description, video.transcript_text()])
    if any(value in full_text for value in ("小白", "零基础", "新手", "入门")):
        lines.append("- 适用人群：从标题和字幕看，是面向零基础/小白用户的使用教程。")
    if "书源" in full_text:
        lines.append("- 核心操作：下载软件、安装、导入书源、搜索书籍。")
    else:
        lines.append("- 核心操作：按视频演示完成下载、安装和配置。")
    lines.append("")

    lines.append("## 3. 博主的步骤（按时间线）")
    lines.append("")
    if steps:
        lines.append("| # | 时间 | 步骤 | 视频原话 |")
        lines.append("| --- | --- | --- | --- |")
        for index, step in enumerate(steps[:16], start=1):
            original = _clip(step["text"], 120) if step["text"] else "（章节标题）"
            lines.append(
                f"| {index} | {format_seconds(step['start'])} | "
                f"{step['title']} | {original} |"
            )
        lines.append("")
        lines.append("> 这是按字幕切分出的步骤，不是凭空补全的通用流程。")
    else:
        lines.append("[未知] 没有字幕或章节，无法还原博主的操作顺序。")
    lines.append("")

    lines.append("## 4. 下载与参考链接")
    lines.append("")
    if links:
        lines.append("| 类型 | 链接 | 来源 |")
        lines.append("| --- | --- | --- |")
        for link in links:
            where = link["source"]
            if link.get("start") is not None:
                where += f" @ {format_seconds(link['start'])}"
            lines.append(f"| {link['kind']} | {link['url']} | {where} |")
        lines.append("")
        lines.append("> 网盘和第三方链接可能过期；优先使用官方仓库/发布页，安装前确认来源可信。")
    else:
        lines.append("视频文字里没有提取到可用的下载链接。")
    lines.append("")

    lines.append("## 5. 视频里提到的注意事项")
    lines.append("")
    if cautions:
        lines.extend(cautions)
    else:
        lines.append("- 视频文字里没有明确提到失败场景或注意事项。")
    lines.append("")

    lines.append("## 6. 通用操作提示")
    lines.append("")
    lines.append("> 以下是通用提示，不是视频原文。")
    if "手机" in platform or "Android" in platform:
        lines.append("- Android 安装第三方 APK 时，系统可能要求允许“未知来源”；确认 APK 来自可信渠道再允许。")
        lines.append("- 不要在不清楚来源的 App 里输入账号密码；先检查应用权限。")
    lines.append("- 先确认软件版本与视频一致，再按步骤操作；版本不同，菜单名称可能变化。")
    if "书源" in full_text or "导入" in full_text:
        lines.append("- 网络导入失败时，优先尝试本地文件导入；仍然失败就检查链接是否过期。")
    lines.append("- 如果视频只是演示安装和使用，不要按源码项目的“构建/编译/部署”流程操作。")
    lines.append("")

    lines.append("## 7. 需要你回答的问题")
    lines.append("")
    for index, question in enumerate(build_usage_questions(video, selected), start=1):
        lines.append(f"{index}. {question}")
    lines.append("")

    lines.append("## 8. 证据索引")
    lines.append("")
    _append_evidence(lines, video)
    lines.append("")
    lines.append("## 9. 这不是源码复刻")
    lines.append("")
    lines.append(
        "如果你要的是从源码构建、二次开发或修改这个软件，请明确告诉我；"
        "当前视频是使用教程，所以不生成开发环境、编译和部署步骤。"
    )
    lines.append("")
    return "\n".join(lines)


def build_usage_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
    selected: RepoCandidate | None,
) -> str:
    repo = selected.html_url if selected else "（视频未给出仓库）"
    return f"""你是我整理软件使用教程的助手。请严格按下面的证据工作。

## 视频
- 标题：{video.title}
- 地址：{video.url}
- 软件/仓库：{repo}

## 任务
1. 把视频步骤整理成按时间排序的 checklist，保留“方法一/方法二”这类分支。
2. 每一步标注视频时间戳，并区分视频原文与通用提示。
3. 列出下载来源、版本要求、导入方式和已知失败情况。
4. 不要生成源码构建、克隆仓库或部署步骤，除非视频明确在教开发。
5. 不得编造菜单名、按钮名、链接或版本号；证据不足时先提问。

## 硬性规则
- 只使用下方简报和证据，不要用常识补全按钮位置或下载地址。
- 如果步骤缺失，明确写“视频没有展示”，不要猜。
- 输出 Markdown，不要输出分析过程。

## 简报
{brief_md}
"""


def build_llm_messages(
    video: VideoEvidence,
    signals: ExtractedSignals,
    candidates: list[RepoCandidate],
) -> tuple[str, str]:
    candidate_blocks: list[str] = []
    for index, candidate in enumerate(candidates[:4], start=1):
        readme = _clean_readme(candidate.readme)
        readme_limit = 5000 if index == 1 else 2600
        deps = "、".join(candidate.dependencies[:15]) or "（未读取到）"
        manifests = "、".join(candidate.manifests) or "（未读取到）"
        candidate_blocks.append(
            f"""### 候选 {index}：{candidate.full_name}
- 地址：{candidate.html_url}
- 匹配分：{candidate.score}（{'；'.join(candidate.reasons) or '无'}）
- Stars：{candidate.stars}；语言：{candidate.language or '未知'}；许可证：{candidate.license or '未确认'}
- 最后更新：{candidate.updated_at or '未知'}
- 描述：{candidate.description or '（无）'}
- 依赖清单文件：{manifests}
- 关键依赖：{deps}
- README 摘录：
{_clip(readme, readme_limit) or '（未读取到 README）'}"""
        )

    comments = (
        "\n".join(
            f"- [{c.likes} 赞]{'（置顶）' if c.pinned else ''} {c.author}：{_clip(c.text, 220)}"
            for c in video.comments[:12]
        )
        or "（无评论）"
    )
    tags = "、".join(video.tags[:20]) or "（无）"
    keywords = (
        "、".join(f"{term.term}({term.weight})" for term in signals.terms[:25]) or "（无）"
    )

    user = f"""## 视频元数据
- 平台：{video.platform}
- 标题：{video.title}
- 视频 ID：{video.video_id}
- 地址：{video.url}
- UP 主：{video.author}
- 时长：{format_seconds(video.duration)}
- 标签：{tags}

## 视频简介
{_clip(video.description, 5000) or '（无简介）'}

## 从简介/评论/字幕中提取到的仓库线索
{_sources_for_mentions(signals)}

## 关键词线索
{keywords}

## 字幕（带时间戳）
{_sample_transcript(video)}

## 热门评论
{comments}

## 候选仓库（按匹配分排序，可能全部是错的）
{chr(10).join(candidate_blocks) or '（没有检索到候选仓库）'}

## 额外提示
- 如果候选仓库与视频明显不符，请直接说"仓库未确认"，不要硬选。
- 如果视频只是展示别人的项目或转述，请指出原始来源可能不是 UP 主。
- 如果材料不足以支撑某个复刻步骤，把它放进"未知与风险"，不要编造。

{OUTPUT_SPEC}
"""
    return SYSTEM_PROMPT, user


def _confidence(candidate: RepoCandidate | None) -> str:
    if not candidate:
        return "未确认"
    if candidate.score >= 70:
        return "高"
    if candidate.score >= 45:
        return "中"
    return "低"


def _status(candidate: RepoCandidate | None) -> str:
    if not candidate:
        return "[未知]"
    return "[确认]" if candidate.score >= 70 else "[推断]"


def _toolchain_hint(selected: RepoCandidate | None) -> str:
    language = (selected.language if selected else "").lower()
    if language in {"kotlin", "java"}:
        return "Android Studio / JDK / SDK 版本不匹配、Gradle 同步失败、设备未授权"
    if language == "python":
        return "Python 版本、依赖或 GPU 环境不匹配"
    if language in {"javascript", "typescript"}:
        return "Node.js 或包管理器版本不匹配"
    return "工具链版本或系统依赖不匹配"


COMMAND_HINTS = (
    "pip install", "python -m", "python ", "uvicorn", "streamlit", "npm install",
    "npm run", "yarn", "pnpm", "cargo ", "go run", "go build", "docker ",
    "./gradlew", "gradle ", "mvn ", "dotnet ", "ollama pull", "ollama run",
    "make ", "cmake ", "conda ",
)


def _readme_commands(readme: str, limit: int = 900) -> str:
    blocks = re.findall(r"```[A-Za-z0-9_+-]*\n(.*?)```", readme or "", re.S)
    lines: list[str] = []
    for block in blocks:
        for raw in block.splitlines():
            line = raw.strip().lstrip("$> ").strip()
            if not line or line.startswith("#"):
                continue
            if any(hint in line.lower() for hint in COMMAND_HINTS):
                lines.append(line)
    if not lines:
        for raw in (readme or "").splitlines():
            line = raw.strip().lstrip("$> ").strip()
            if any(hint in line.lower() for hint in COMMAND_HINTS):
                lines.append(line)
    unique: list[str] = []
    for line in lines:
        if line not in unique:
            unique.append(line)
    return _clip("\n".join(unique[:20]), limit)


def _append_reproduction_path(lines: list[str], selected: RepoCandidate | None) -> None:
    repo_hint = selected.html_url if selected else "<待确认的仓库地址>"
    lines.append("### 阶段 1：跑通官方版本")
    lines.append("")
    language = (selected.language if selected else "").lower()
    if language in {"kotlin", "java"}:
        lines.append(
            f"- 目标：克隆 `{repo_hint}`，用 Android Studio 打开，"
            "按 README 配置 JDK/SDK 并编译安装 debug 包。"
        )
    else:
        lines.append(f"- 目标：克隆 `{repo_hint}`，按 README 跑通作者提供的示例。")
    lines.append("- 要改/要建的文件：暂时不改代码，只记录 README 里的安装命令、环境变量和启动方式。")
    lines.append("- 验证命令：以 README 为准；没有 README 时先读依赖清单和入口文件。")
    lines.append("- 验收标准：示例能启动，控制台无未处理异常，核心界面或 API 有响应。")
    lines.append(f"- 常见坑：{_toolchain_hint(selected)}。")
    lines.append("- 回滚点：只做只读操作，不修改仓库。")
    lines.append("")
    lines.append("### 阶段 2：最小可运行版本")
    lines.append("")
    lines.append("- 目标：只保留一条最短主流程（输入 → 核心处理 → 输出），去掉示例数据和可选功能。")
    lines.append("- 要改/要建的文件：入口文件、配置文件、一个最小验证脚本。")
    lines.append("- 验证命令：为这条主流程写一个可重复执行的命令或测试。")
    lines.append("- 验收标准：在干净环境中按文档能复现；失败时有明确报错。")
    lines.append("- 常见坑：把作者的环境当成通用环境；忽略默认配置里的本地路径。")
    lines.append("- 回滚点：保留原始分支或 tag，改动前先提交一次本地快照。")
    lines.append("")
    lines.append("### 阶段 3：按你的需求改造")
    lines.append("")
    lines.append("- 目标：把你真正需要的功能替换进去，而不是照搬作者的完整产品。")
    lines.append("- 要改/要建的文件：先让编码 Agent 读源码后列出，禁止凭空猜路径。")
    lines.append("- 验证命令：每个改动配一条回归命令。")
    lines.append("- 验收标准：原有示例仍能跑通，新功能有独立验收用例。")
    lines.append("- 常见坑：过早重构；同时改多个层；没有基线就优化。")
    lines.append("- 回滚点：每个阶段一个 commit 或目录快照。")
    lines.append("")


def build_software_questions(
    video: VideoEvidence,
    selected: RepoCandidate | None,
) -> list[str]:
    language = (selected.language if selected else "").lower()
    topics = " ".join(selected.topics if selected else []).lower()
    text = f"{video.title} {video.description} {topics}".lower()
    if language in {"kotlin", "java"} or "android" in topics or "安卓" in text:
        return [
            "你的 Android Studio、JDK 和 Android SDK 版本是什么？",
            "你要在真机还是模拟器上运行？设备的 Android 版本是多少？",
            "你想复刻完整 App，还是只复刻某个功能？",
            "你能接受直接使用原仓库代码吗？许可证要求是什么？",
            "你希望在多长时间内看到第一个可运行版本？",
        ]
    if language in {"javascript", "typescript"} or any(
        value in text for value in ("node", "前端", "网页", "react", "vue")
    ):
        return [
            "你的 Node.js 和包管理器版本是什么？",
            "你想复刻完整项目，还是只复刻一个核心页面或功能？",
            "你能接受直接使用原仓库代码吗？许可证要求是什么？",
            "项目需要后端服务或付费 API 吗？",
            "你希望在多长时间内看到第一个可运行版本？",
        ]
    if language == "python" or "python" in text:
        return [
            "你的操作系统、Python 版本和是否有 GPU？",
            "你想复刻完整项目，还是只复刻视频里的一个核心功能？",
            "你能接受直接使用原仓库代码吗？许可证要求是什么？",
            "这个项目需要调用付费 API 或下载大模型权重吗？预算上限是多少？",
            "你希望在多长时间内看到第一个可运行版本？",
        ]
    return [
        "你的操作系统和主要工具链版本是什么？",
        "你想复刻完整项目，还是只复刻一个核心功能？",
        "你能接受直接使用原仓库代码吗？许可证要求是什么？",
        "项目有外部服务、付费 API 或模型权重依赖吗？",
        "你希望在多长时间内看到第一个可运行版本？",
    ]


def build_fallback_brief(
    video: VideoEvidence,
    signals: ExtractedSignals,
    candidates: list[RepoCandidate],
    selected: RepoCandidate | None,
    reason: str = "",
) -> str:
    lines: list[str] = []
    lines.append(f"# 复刻简报：{video.title or video.video_id}")
    lines.append("")
    if reason:
        lines.append(f"> 本地规则生成（未启用 LLM：{reason}）。")
    else:
        lines.append("> 本地规则生成。")
    lines.append("> 下面的事实来自视频页面和代码托管平台元数据，标注为推断的内容需要进一步验证。")
    lines.append("")

    lines.append("## 0. 一句话结论")
    if selected:
        lines.append(
            f"已定位到候选仓库 `{selected.full_name}`（匹配度：{_confidence(selected)}），"
            f"建议先读 README 并跑通官方版本，再决定复刻范围。"
        )
    else:
        lines.append(
            "还没有定位到可信的仓库。当前材料只能确认视频主题，"
            "需要先补全项目名、仓库地址或作者主页，才能生成可靠的复刻路径。"
        )
    lines.append("")

    lines.append("## 1. 项目身份")
    lines.append("")
    lines.append("| 项目 | 值 | 证据 | 状态 |")
    lines.append("| --- | --- | --- | --- |")
    lines.append(f"| 视频 | [{video.title}]({video.url}) | B 站页面 | [确认] |")
    lines.append(
        f"| UP 主 | {video.author or '未知'} | B 站页面 | "
        f"{'[确认]' if video.author else '[未知]'} |"
    )
    if selected:
        lines.append(
            f"| 仓库 | [{selected.full_name}]({selected.html_url}) | "
            f"{'视频文本直接给出' if selected.source == 'explicit' else '候选检索'} | "
            f"{_status(selected)} |"
        )
        lines.append(
            f"| 许可证 | {selected.license or '未确认'} | 仓库元数据 | "
            f"{'[确认]' if selected.license else '[未知]'} |"
        )
        lines.append(
            f"| 主要语言 | {selected.language or '未确认'} | 仓库元数据 | "
            f"{'[确认]' if selected.language else '[未知]'} |"
        )
        lines.append(
            f"| 最后更新 | {selected.updated_at or '未确认'} | 仓库元数据 | "
            f"{'[确认]' if selected.updated_at else '[未知]'} |"
        )
    else:
        lines.append("| 仓库 | 未定位 | 检索结果 | [未知] |")
    lines.append("")

    lines.append("## 2. 视频里给出的线索")
    lines.append("")
    if signals.repo_mentions:
        for mention in signals.repo_mentions[:8]:
            where = SOURCE_LABELS.get(mention.source, mention.source)
            if mention.start is not None:
                where += f" @ {format_seconds(mention.start)}"
            lines.append(
                f"- 仓库地址 `{_display_host(mention.host)}/{mention.full_name}`（来源：{where}）"
            )
    else:
        lines.append("- 没有在标题、简介、评论或字幕中提取到直接的仓库地址。")
    if signals.tech_terms:
        lines.append(f"- 识别到的技术词：{'、'.join(signals.tech_terms[:20])}")
    if video.chapters:
        lines.append("")
        lines.append("视频章节：")
        for chapter in video.chapters[:12]:
            lines.append(f"- [{format_seconds(chapter.start)}] {chapter.title}")
    elif video.subtitles:
        lines.append("")
        lines.append("字幕时间线（抽样）：")
        step = max(1, len(video.subtitles) // 10)
        for seg in video.subtitles[::step][:10]:
            lines.append(f"- [{format_seconds(seg.start)}] {_clip(seg.text, 80)}")
    if video.description:
        lines.append("")
        lines.append("简介原文摘录：")
        lines.append("")
        lines.append("```text")
        lines.append(_clip(video.description, 1200))
        lines.append("```")
    lines.append("")

    lines.append("## 3. 候选仓库")
    lines.append("")
    visible = [candidate for candidate in candidates if candidate.score >= 30][:4]
    if visible:
        lines.append("| # | 仓库 | 分数 | Stars | 语言 | 许可证 | 匹配原因 |")
        lines.append("| --- | --- | --- | --- | --- | --- | --- |")
        for index, candidate in enumerate(visible, start=1):
            lines.append(
                f"| {index} | [{candidate.full_name}]({candidate.html_url}) | "
                f"{candidate.score} | {candidate.stars} | {candidate.language or '-'} | "
                f"{candidate.license or '-'} | {'；'.join(candidate.reasons[:3])} |"
            )
        lines.append("")
        lines.append("> 分数只是线索匹配度，不等于项目正确性。请先打开仓库确认演示效果是否一致。")
    else:
        if candidates:
            lines.append(
                f"没有足够可信的候选仓库（最高分 {candidates[0].score}，低于显示门槛 30）。"
            )
            lines.append("")
            lines.append("低分候选没有列出来，避免用无关仓库干扰后续步骤。")
        else:
            lines.append("没有检索到候选仓库。")
        if signals.queries:
            lines.append("")
            lines.append("已尝试的检索词：" + "、".join(f"`{q}`" for q in signals.queries))
    lines.append("")

    lines.append("## 4. 技术栈与项目结构")
    lines.append("")
    if selected:
        lines.append(f"- 主要语言：{selected.language or '[未知]'}")
        lines.append(f"- 依赖清单：{'、'.join(selected.manifests) or '[未知]'}")
        lines.append(f"- 关键依赖：{'、'.join(selected.dependencies[:15]) or '[未知]'}")
        if selected.topics:
            lines.append(f"- 仓库 topics：{'、'.join(selected.topics[:15])}")
        lines.append("- 目录结构和入口文件需要读仓库源码确认，当前没有拉取完整文件树。")
    else:
        lines.append("- [未知] 仓库未确认，无法给出技术栈。")
    if selected:
        commands = _readme_commands(selected.readme)
        if commands:
            lines.append("")
            lines.append("### 从 README 提取的安装 / 运行线索")
            lines.append("")
            lines.append("```text")
            lines.append(commands)
            lines.append("```")
            lines.append("")
            lines.append("> 以上命令直接摘自 README，未在本机执行；请以仓库当前版本为准。")
    lines.append("")

    lines.append("## 5. 复刻路径")
    lines.append("")
    material_insufficient = not selected and not video.subtitles and not signals.repo_mentions
    if material_insufficient:
        lines.append("当前材料不足，暂不生成阶段化复刻路径。先补齐下面任意一项：")
        lines.append("")
        lines.append("1. 视频简介/置顶评论里的仓库地址；")
        lines.append("2. 可用的字幕或 ASR 文本；")
        lines.append("3. 你手动确认的 `owner/repo`（在扩展的“候选仓库”里填写）。")
        lines.append("")
    else:
        _append_reproduction_path(lines, selected)

    lines.append("## 6. 未知与风险")
    lines.append("")
    if not video.subtitles:
        lines.append("- [未知] 没有字幕，无法确认视频口播里是否提到仓库、版本或关键步骤。")
    if not selected:
        lines.append("- [未知] 仓库未确认，后续技术栈和复刻步骤都不可靠。")
    elif selected.score < 70:
        lines.append("- [推断] 仓库是按线索匹配出来的，尚未人工确认演示效果是否一致。")
    if selected and not selected.license:
        lines.append("- [未知] 许可证未确认；在复制代码前必须核对 LICENSE 文件。")
    if selected and selected.stars == 0:
        lines.append("- [风险] 仓库没有 stars，可能是新项目、私有项目镜像或误匹配。")
    lines.append("- [风险] 视频演示不等于仓库完整能力；教程可能省略环境配置、模型权重或付费服务。")
    lines.append("- [风险] 视频发布后仓库可能已变更；复刻时应 pin 到具体 commit/tag。")
    for warning in video.warnings[:5]:
        lines.append(f"- [提示] {warning}")
    lines.append("")

    lines.append("## 7. 需要你回答的问题")
    lines.append("")
    questions = build_software_questions(video, selected)
    if selected and selected.dependencies:
        questions.insert(
            2,
            f"依赖清单里出现了 {'、'.join(selected.dependencies[:4])}，这些是你想保留的技术栈吗？",
        )
    for index, question in enumerate(questions[:6], start=1):
        lines.append(f"{index}. {question}")
    lines.append("")

    lines.append("## 8. 证据索引")
    lines.append("")
    lines.append(f"- 视频：{video.url}")
    if video.description:
        lines.append(f"- 简介长度：{len(video.description)} 字")
    if video.comments:
        lines.append(f"- 评论样本：{len(video.comments)} 条")
        for comment in video.comments[:4]:
            lines.append(
                f"  - {comment.author}（{comment.likes} 赞）：{_clip(comment.text, 120)}"
            )
    if video.subtitles:
        lines.append(f"- 字幕段落：{len(video.subtitles)} 条")
        for seg in video.subtitles[:6]:
            lines.append(f"  - [{format_seconds(seg.start)}] {seg.text}")
    lines.append("")
    lines.append("## 9. 给编码 Agent 的任务包")
    lines.append("")
    lines.append("已单独写入同目录的 `agent_prompt.md`。")
    lines.append(
        "核心约束：先读仓库再动手、一次只做一个阶段、每阶段给出验收标准、"
        "不得编造接口/版本号/文件路径，遇到 [未知] 先提问。"
    )
    lines.append("")

    return "\n".join(lines)


def build_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
    selected: RepoCandidate | None,
) -> str:
    repo = selected.html_url if selected else "（仓库未确认，请先向用户确认）"
    repo_name = selected.full_name if selected else "（未确认）"
    return f"""你是我复刻开源项目的编码助手。请严格按下面的项目情报工作。

## 项目
- 名称：{video.title}
- 权威仓库：{repo}
- 仓库全名：{repo_name}
- 视频来源：{video.url}

## 目标
在不臆造接口、依赖和文件路径的前提下，复刻出一个可运行的最小版本，再逐步接近视频演示的效果。

## 工作方式
1. 先读 README、依赖清单、入口文件和目录结构，输出一份你确认过的项目结构。
2. 列出"材料里没有、但会改变方案"的问题，最多 5 个；能通过读代码确认的不要问我。
3. 给出分阶段计划，每阶段包含：改动文件、验证命令、验收标准、回滚点。
4. 一次只做一个阶段，做完停下来等我确认。
5. 不要编造 API、版本号、模型名或硬件型号；不确定就标注 [未知] 并提问。
6. 不要执行破坏性命令，不要自动提交 git，不要修改与当前阶段无关的文件。
7. 如果仓库与视频描述不一致，以仓库为准，并告诉我差异。

## 已知约束
- 我的运行环境：<待填>
- 我只需要复刻：<待填>
- 预算/时间：<待填>
- 许可证要求：<待填>

## 项目情报
{brief_md}

如果上面的情报里有 [未知] 或 [推断]，不要自行补全；先问我，或去仓库里验证后再动手。
"""


def build_nonsoftware_agent_prompt(
    brief_md: str,
    video: VideoEvidence,
    classification: VideoClassification,
) -> str:
    if classification.kind == "hardware_software_mixed":
        role = "硬件 + 软件混合教程整理助手"
        task = """1. 分开整理硬件部分（型号、组件、工具、接线、供电）和软件部分（仓库、固件、烧录、配置）。
2. 把步骤按时间线排成 checklist，标注哪些是硬件动作、哪些是软件动作。
3. 明确区分视频原文、推断和通用安全建议。
4. 不得编造引脚、电压、型号、烧录地址或命令；证据不足先提问。"""
    elif classification.kind == "hardware_tutorial":
        role = "硬件维修教程整理助手"
        task = """1. 从证据中提取设备型号、操作类型、工具、耗材和步骤。
2. 把能确认的步骤整理成按时间排序的 checklist，并标注每条证据的来源。
3. 明确区分“视频原文/字幕”与“通用维修建议”。
4. 列出视频没有展示、没有说清楚或需要拆机实测的信息。
5. 不得编造扭矩、尺寸、型号、螺丝位置、排线顺序或零件编号。证据不足时先提问。"""
    elif classification.kind == "hardware_topic":
        role = "硬件资讯/评测内容整理助手"
        task = """1. 整理视频中的价格、型号、时间线、数据和博主观点。
2. 区分视频原文、推算和未知；不要把评论玩梗当成价格事实。
3. 不要生成拆机、维修或代码复刻步骤，除非视频明确演示了这些内容。
4. 发现明显的数字识别错误时标注 [待核对]，不要自行改写成确定结论。"""
    else:
        role = "视频内容整理助手"
        task = """1. 只根据证据整理视频的主要内容和时间线。
2. 区分事实、推断和未知。
3. 不要生成代码复刻步骤，也不要去猜仓库。
4. 信息不足时先列出需要补充的材料。"""

    return f"""你是我{role}。请严格按下面的证据工作。

## 视频
- 标题：{video.title}
- 地址：{video.url}
- 类型：{classification.label}

## 任务
{task}

## 硬性规则
- 只使用下方简报和证据，不要补充没有出现的型号、尺寸、扭矩、命令或仓库。
- 每条关键结论标注来源：标题、简介、评论、字幕时间戳。
- 如果材料不足，先列出缺失项，不要用常识硬补。
- 输出 Markdown，不要输出分析过程。

## 简报
{brief_md}
"""
